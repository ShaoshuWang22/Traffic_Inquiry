from pathlib import Path

path = Path(r"c:\Users\29858\Desktop\triffic\triffic.cpp")
lines = path.read_text(encoding='utf-8').splitlines()
out = []
for line in lines:
    s = line.rstrip()
    stripped = s.strip()
    if not stripped:
        out.append(s)
        continue
    if stripped.startswith('//') or stripped.startswith('/*') or stripped.startswith('*') or stripped.startswith('*/') or stripped.startswith('#'):
        out.append(s)
        continue
    if '//' in s:
        out.append(s)
        continue
    if stripped.startswith(('if ', 'if(')):
        comment = '// 如果条件成立，就执行下面的内容'
    elif stripped.startswith('else'):
        comment = '// 否则执行这里的内容'
    elif stripped.startswith(('for ', 'for(')):
        comment = '// 这个循环用来重复处理数据'
    elif stripped.startswith(('while ', 'while(')):
        comment = '// 只要条件成立，就一直循环执行'
    elif stripped.startswith(('switch ', 'switch(')):
        comment = '// 根据不同情况选择对应分支'
    elif stripped.startswith('case '):
        comment = '// 这是其中一种分支情况'
    elif stripped.startswith('return '):
        comment = '// 把结果返回给调用方'
    elif stripped in ('break;', 'continue;'):
        comment = '// 结束当前循环或跳过这一次'
    elif stripped.startswith(('}', '};')):
        comment = '// 结束当前代码块'
    elif '=' in stripped and '==' not in stripped:
        comment = '// 给变量赋值'
    elif stripped.endswith(';'):
        comment = '// 执行一条简单语句'
    else:
        comment = '// 完成一项基础操作'
    out.append(s + '  ' + comment)

path.write_text('\n'.join(out) + '\n', encoding='utf-8')
print('annotated')
