//=============================================================================
// 项目名称：交通咨询系统（智能乘车调度与路径规划系统）
// 开发环境：MinGW-w64 (GCC) + EasyX 图形库
// 核心技术：有向图邻接表 + SPFA 最短路径算法 + 全排列枚举
// 运行方式：编译后生成单文件 exe，双击即可运行，无需安装任何依赖
//=============================================================================

// === 编译器兼容处理 ===
// 问题：MSVC 的 execution_character_set pragma 在 GCC 下会报警告
// 解决：用 #ifdef 条件编译，只在 MSVC 下生效，GCC 完全看不到
#ifdef _MSC_VER
#pragma execution_character_set("utf-8")
#endif
#define _CRT_SECURE_NO_WARNINGS  // 关闭 MSVC 的 scanf/strcpy 安全警告

// === 头文件说明 ===
// graphics.h  : EasyX 图形库，提供 initgraph/line/circle/outtextxy 等绘图函数
// conio.h     : 控制台输入输出（本项目中未直接使用，EasyX 依赖）
// stdio.h     : 标准输入输出（_stprintf_s, _stscanf_s 等格式化函数）
// stdlib.h    : malloc/free/rand 等
// string.h    : 内存和字符串操作
// math.h      : atan2/cos/sin 等数学函数（箭头方向计算用）
// vector      : C++ STL 动态数组，存储路径结果
// string      : C++ string 类
// algorithm   : sort/next_permutation/reverse/find 等算法
// random      : 随机数生成（随机途经点功能）
// queue       : C++ STL 队列，SPFA 算法用
// tchar.h     : Windows 通用字符类型（自动适配 char/wchar_t）
// windows.h   : Win32 API（窗口管理、DPI、消息处理）
#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <vector>
#include <string>
#include <algorithm>
#include <random>
#include <queue>
#include <tchar.h>
#include <windows.h>

// 参与人员：董
// === UCRT MinGW 兼容补丁 ===
// 问题背景：新版 MinGW-w64 使用 UCRT（Universal C Runtime），不再提供 MSVCRT 的 __iob_func 符号
//           EasyX 库在编译时可能依赖了旧的 MSVCRT，导致链接时找不到 __iob_func 而报错
// 解决思路：自己实现一个假的 __iob_func，返回标准输入/输出/错误流的指针数组
// 关键技术：利用 GCC 的 diagnostic push/pop 忽略 -Wattributes 警告（函数属性不匹配）
// EasyX 库可能依赖旧版 MSVCRT 的 __iob_func 符号，
// 新版 MinGW-w64 (UCRT) 已移除该符号，此处提供兼容定义。
// 若链接时报 undefined reference to __iob_func 则需要此补丁。
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#ifdef __cplusplus
extern "C" {
#endif
    FILE* __cdecl __iob_func(void) {
        static FILE* mock_iob[3] = { stdin, stdout, stderr };
        return (FILE*)mock_iob;
    }
    void* __imp___iob_func = (void*)__iob_func;
#ifdef __cplusplus
}
#endif
#pragma GCC diagnostic pop
// --- UCRT MinGW 兼容补丁结束 ---

using namespace std;

// === 系统常量定义 ===
// 为什么 MAX_VERTEX=50？全国主要城市约30个，50留有足够扩展空间
// 为什么 INF=1e9？用作"无穷大"的初始值，比任何真实路径值都大
// 三种交通模式：FLIGHT=飞机（快但贵）、TRAIN=火车（慢但便宜）、MIXED=智能混合
#define MAX_VERTEX 50       // 图中最大城市数量
#define INF 1e9             // 表示无穷大（无路径可到达）
#define TYPE_FLIGHT 1       // 交通类型：航空（飞机）
#define TYPE_TRAIN  2       // 交通类型：铁路（火车）
#define TYPE_MIXED  3       // 交通类型：混合（飞机+火车智能组合）
#define MAP_AREA_WIDTH (SCREEN_WIDTH - SIDEBAR_WIDTH)  // 地图区域宽度（已废弃，用 MAP_AREA_MAX）

// 参与人员：陈 王
//=============================================================================
// 第一部分：核心数据结构定义
// 设计思路：采用"有向图 + 邻接表"架构
//   城市(VNode) = 图的顶点，存储名称、坐标
//   交通线路(ArcNode) = 图的边，连接两个城市，存储里程和类型
//   班次(Schedule) = 挂在边上的链表，存储具体的航班/车次信息
// 为什么用邻接表而不是邻接矩阵？
//   1. 城市间连线稀疏（30个城市，不到100条边），邻接表更省内存
//   2. 邻接表天然支持一个城市到另一个城市有多条线路（如北京→天津有飞机也有火车）
//   3. 边的班次链表可以动态增删，方便运行时编辑数据
//=============================================================================
typedef struct Schedule {
    TCHAR no[20];         // 班次号
    int dep_time;        // 出发时间（分钟）
    int arr_time;        // 到达时间
    double cost;         // 费用
    struct Schedule* next;   // 链表指针，指向下一个班次（头插法，最新的在前面）
} Schedule;

// ArcNode：交通线路（图的"边"）
// 例如：北京→天津 是一条边，这条边上挂了一个 Schedule 链表
//       Schedule 链表里可能有 CA101(飞机)、C201(火车) 等多个班次
typedef struct ArcNode {
    int adjvex;              // 这条边指向哪个城市？（存储的是 G.vertices[] 的下标）
    int distance;            // 两城市间的里程（公里）
    int type;                // 交通类型：TYPE_FLIGHT(1)=飞机 或 TYPE_TRAIN(2)=火车
    Schedule* sch_list;      // 挂在这条边上的班次链表（头指针）
    struct ArcNode* nextarc; // 指向下一条边（同一城市发出的另一条线路）
} ArcNode;

// VNode：城市节点（图的"顶点"）
// 每个城市是一个 VNode，存储在 G.vertices[] 数组中
typedef struct VNode {
    TCHAR name[30];          // 城市中文名称，如"北京"、"上海"（最多29个字符+结束符）
    TCHAR code[10];          // 三字代码，如"BJS"、"SHA"（用于机场/火车站标识）
    int x, y;                // 在地图窗口上的像素坐标（城市圆圈的中心点）
    ArcNode* firstarc;       // 从这个城市发出的第一条边（邻接表的表头指针）
} VNode, AdjList[MAX_VERTEX];  // AdjList 是一个包含 MAX_VERTEX 个 VNode 的数组

// Graph：整个交通网络图
// G 是全局唯一的图实例，所有操作都围绕它进行
typedef struct {
    AdjList vertices;   // 城市数组（顶点表），最多 MAX_VERTEX 个城市
    int vexnum;         // 当前实际城市数量（从0开始计数）
} Graph;

// PathState：SPFA 算法中每个城市的状态记录
// 为什么需要这个结构？算法在搜索过程中需要记录"到达某个城市的最佳状态"
typedef struct {
    double best_value;   // 到达该城市的当前最优值（时间优先=最早到达分钟数，费用优先=最低累计票价）
    int pre_vex;         // 前驱城市下标（用于最后回溯出完整路径，类似"我从哪个城市过来的"）
    Schedule* chosen_sch;// 从前驱城市到本城市选中的班次（哪个航班/车次）
    int chosen_type;     // 选中班次的类型（TYPE_FLIGHT 或 TYPE_TRAIN）
    int arrival_time;    // 到达本城市的绝对时间（从第0天的00:00开始计算的累计分钟数）
} PathState;

//=============================================================================
// 第二部分：全局变量
//=============================================================================

Graph G;                    // 【核心】全局唯一的交通网络图，所有操作都围绕它
int SCREEN_WIDTH = 1480;    // 窗口客户区宽度（像素），初始化后会被实际值覆盖
int SCREEN_HEIGHT = 900;    // 窗口客户区高度（像素）
int SIDEBAR_WIDTH = 300;    // 右侧控制面板的固定宽度
int MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;  // 地图区域的最大X坐标（=窗口宽-侧边栏宽）

// === 右键菜单状态变量 ===
// 设计思路：菜单不是 Windows 原生控件，而是纯手工用 EasyX 绘制的
//          所以需要自己管理菜单的显示/隐藏、位置、选中项等状态
bool  g_ctx_menu_visible = false;    // 右键菜单是否正在显示
int   g_ctx_menu_x = 0, g_ctx_menu_y = 0;  // 菜单左上角的屏幕坐标
int   g_ctx_menu_target = -1;  // 右键点击的目标：-1=地图空白处, >=0=某个城市节点的下标
int   g_ctx_menu_count = 0;    // 当前菜单有多少个选项（空白处2个，节点上2个）
int   g_ctx_menu_hover = -1;   // 鼠标悬停在第几个菜单项上（-1=无悬停），用于高亮效果

// 参与人员：陈 王
//=============================================================================
// 第三部分：基础工具函数
//=============================================================================

// === 时间转换函数 ===
// 功能：把 "HH:MM" 格式的字符串转换为从当天 00:00 开始的分钟数
// 为什么用分钟而不是小时？因为班次可能跨天（如23:50出发，次日02:00到达），
//   分钟数便于做加减运算和比较（出发510分钟，到达120+1440=1560分钟）
// 示例：TimeToMin("08:30") 返回 8*60+30 = 510
int TimeToMin(const TCHAR* time_str) {  // 这个函数把时间字符串转换成分钟数，方便后面计算
    int h = 0, m = 0;  // 先把小时和分钟分别存起来
    if (_stscanf_s(time_str, _T("%d:%d"), &h, &m) == 2) {  // 如果成功读取到两个数字，就开始换算
        return h * 60 + m;  // 把小时换算成分钟再加上分钟
    }
    return 0;  // 如果输入格式不对，就返回 0
}

// === 前置声明：告诉编译器 DeleteVertexByName 函数在后面定义，现在先用 ===
void DeleteVertexByName(const TCHAR* name);

// 参与人员：董 陈
// === 内存释放函数 ===
// 为什么需要这两个函数？程序用 malloc 动态分配了 Schedule 和 ArcNode，
//   C语言没有垃圾回收，必须手动释放，否则会造成内存泄漏（程序越用越卡）
// 设计模式：递归释放链表，先释放子链表（班次），再释放父节点（边）

// 释放一个班次链表（Schedule 链表）
// 参数：head - 链表头指针
// 逻辑：从头到尾遍历，逐个 free 掉每个 Schedule 节点
void FreeScheduleList(Schedule* head) {  // 释放一个班次链表
    while (head) {  // 只要链表还有节点，就继续处理
        Schedule* next = head->next;  // 先保存下一个节点的位置
        free(head);  // 释放当前节点
        head = next;  // 继续往下处理
    }
}

// 参与人员：董 陈
// 释放一个边链表（ArcNode 链表），同时释放每条边上挂载的班次链表
// 参数：head - 边链表头指针
// 关键：必须先释放 sch_list（班次），再释放 ArcNode 本身
//      如果反过来，ArcNode 被 free 后就无法访问它的 sch_list 了（野指针）
void FreeArcList(ArcNode* head) {  // 释放一条边链表，并顺带清掉它挂着的班次
    while (head) {  // 只要这条边链表还有内容，就继续释放
        ArcNode* next = head->nextarc;  // 先保存下一条边的位置
        FreeScheduleList(head->sch_list);  // 先释放这条边上挂着的班次链表
        free(head);  // 再释放当前边节点
        head = next;  // 继续处理下一条边
    }
}

// 参与人员：董 陈
// 删除节点的快捷入口：根据下标删除，内部调用 DeleteVertexByName
// 这是一个适配器函数，让调用方可以用下标（而非名称）来删除城市
void DeleteNode(int node_idx)  // 根据下标删除一个城市
{
    if (node_idx < 0 || node_idx >= G.vexnum) return;  // 如果下标越界，就直接结束
    DeleteVertexByName(G.vertices[node_idx].name);  // 调用按名称删除的函数
}

// 参与人员：王
// === 时间反向转换函数 ===
// 功能：把绝对分钟数转回人类可读的时间字符串（TimeToMin 的反向操作）
// 为什么需要？算法内部全用分钟数计算，但展示给用户时要显示"第2天 08:30"这样的格式
// 参数：total_min - 绝对分钟数（从第0天00:00开始），out_str - 输出缓冲区，size - 缓冲区大小
// 示例：MinToTimeStr(1560, buf) → buf = "第2天 02:00"
void MinToTimeStr(int total_min, TCHAR* out_str, size_t size) {  // 把分钟数转换成容易看懂的日期时间字符串
    int days = total_min / 1440;  // 先算出经过了几天
    int rem = total_min % 1440;  // 剩下的分钟数
    int h = rem / 60;  // 算出小时
    int m = rem % 60;  // 算出分钟
    if (days == 0) {  // 如果没有跨天，就显示当天
        _stprintf_s(out_str, size, _T("当天 %02d:%02d"), h, m);
    }
    else {  // 如果跨了天，就显示第几天
        _stprintf_s(out_str, size, _T("第%d天 %02d:%02d"), days + 1, h, m);
    }
}

// 参与人员：陈 王
// === 城市查找函数 ===
// 功能：根据城市名称在图中查找对应的下标
// 算法：线性遍历 G.vertices[] 数组，逐个比较城市名称（_tcscmp）
// 返回值：找到返回下标(0~vexnum-1)，未找到返回 -1
// 时间复杂度：O(n)，n=城市数量。因为城市数量少（≤50），线性查找足够快
int LocateVex(const TCHAR* name) {    // 查找城市名称对应的下标
    for (int i = 0; i < G.vexnum; i++) {     // 依次检查每个城市，看看是不是想要找的那个
        if (_tcscmp(G.vertices[i].name, name) == 0) return i;  // 如果找到了，就返回它的编号
           }
    return -1;  // 如果没找到，就返回 -1
}

// 参与人员：陈 王
// === 添加城市节点 ===
// 功能：向图中添加一个新城市（如果已存在则直接返回下标，不重复添加）
// 流程：1.检查城市是否已存在（LocateVex），存在则返回已有下标
//       2.检查是否达到数量上限（MAX_VERTEX=50）
//       3.将城市信息写入 G.vertices[vexnum]，vexnum 自增
//       4.返回新城市的下标
// 注意：边的添加由 AddArc() 负责，这里只管"顶点"本身
int AddVertex(const TCHAR* name, const TCHAR* code, int x, int y) {  // 添加一个城市节点，并返回它的编号
    if (G.vexnum >= MAX_VERTEX) return -1;  // 如果城市数量已经满了，就返回失败

    int idx = LocateVex(name);  // 先检查这个城市是不是已经存在了
    if (idx != -1) return idx;  // 如果已经存在，就直接返回它原来的编号
    _tcscpy_s(G.vertices[G.vexnum].name, 30, name);  // 把城市名字写进数组
    _tcscpy_s(G.vertices[G.vexnum].code, 10, code);  // 把城市代码写进数组
    G.vertices[G.vexnum].x = x;  // 记录城市在地图上的横坐标
    G.vertices[G.vexnum].y = y;  // 记录城市在地图上的纵坐标
    G.vertices[G.vexnum].firstarc = NULL;  // 初始化它还没有任何连线
    G.vexnum++;  // 城市数量加 1
    return G.vexnum - 1;  // 返回新城市的编号
}

// 参与人员：陈 王
// === 添加交通线路（图的"边"）===
// 功能：在城市 u 和城市 v 之间建立一条交通线路
// 参数：u,v - 起点和终点城市下标，distance - 里程（公里），type - 交通类型
// 关键逻辑：先检查是否已存在同类型边（去重），存在则直接返回已有的 ArcNode
//          不存在才 malloc 新 ArcNode，用头插法插入邻接表
// 返回值：ArcNode* 指针，方便调用方紧接着 AddSchedule 往这条边上添加班次
ArcNode* AddArc(int u, int v, int distance, int type) {  // 在两个城市之间添加一条交通线路
    ArcNode* p = G.vertices[u].firstarc;  // 从起点城市的第一条边开始查找
    while (p != NULL) {  // 依次检查每一条边
        if (p->adjvex == v && p->type == type) return p;  // 如果已经存在同样的线路，就直接返回
        p = p->nextarc;  // 看下一条边
    }
    ArcNode* arc = (ArcNode*)malloc(sizeof(ArcNode));  // 新建一条边
    if (!arc) return NULL;  // 如果内存申请失败，就返回空
    arc->adjvex = v;  // 记录终点城市编号
    arc->distance = distance;  // 记录两地距离
    arc->type = type;  // 记录交通类型
    arc->sch_list = NULL;  // 先把班次链表置空
    arc->nextarc = G.vertices[u].firstarc;  // 插到链表头部
    G.vertices[u].firstarc = arc;  // 更新起点城市的第一条边
    return arc;  // 返回新建的边
}

// 参与人员：陈 王
// === 添加班次（挂在边上的 Schedule 节点）===
// 功能：给一条交通线路添加一个具体的航班/车次
// 参数：arc - 要添加班次的边（由 AddArc 返回），no - 班次号（如"CA101"）
//       dep - 出发时间（分钟数），arr - 到达时间（分钟数），cost - 票价（元）
// 链表策略：头插法——新班次插入链表头部，O(1) 时间复杂度
// 跨天处理：如果 arr < dep（如23:00出发→次日02:00到达），调用方应在外部给 arr+=1440
void AddSchedule(ArcNode* arc, const TCHAR* no, int dep, int arr, double cost) {  // 给某条线路添加一个班次
    if (!arc) return;  // 如果边不存在，就不用继续
    Schedule* sch = (Schedule*)malloc(sizeof(Schedule));  // 申请一个班次节点
    if (!sch) return;  // 如果内存申请失败，就直接退出
    _tcscpy_s(sch->no, 20, no);  // 保存班次号
    sch->dep_time = dep;  // 保存出发时间
    sch->arr_time = arr;  // 保存到达时间
    sch->cost = cost;  // 保存票价
    sch->next = arc->sch_list;  // 插到班次链表头部
    arc->sch_list = sch;  // 更新这条边的班次链表头
}

// 参与人员：董 陈
//=============================================================================
// 第四部分：城市删除（级联抹除）
//=============================================================================
// 这是整个程序最复杂的操作之一！删除一个城市需要三步走得非常小心：
//   第1步：释放被删城市自己的出边（它发出的所有线路和班次）
//   第2步：遍历全体城市，删除所有指向被删城市的入边（含班次释放）
//   第3步：如果删的不是最后一个城市，把最后一个城市移到空位，
//          并修复所有原本指向最后城市的边，让它们指向新位置
// 为什么这么麻烦？因为城市用顺序表存储（G.vertices[]数组），
// 删中间城市会产生"空洞"，需要用末尾城市填坑，同时更新所有边的指向
// ----------------- 删除城市节点（含级联抹除）-----------------
void DeleteVertexByName(const TCHAR* name) {  // 根据城市名称删除这个节点，并清理相关线路
    int idx = LocateVex(name);  // 先在图中查找这个城市的编号
    if (idx == -1) {  // 如果没找到，就提示用户
        MessageBox(GetHWnd(), _T("未找到该城市！"), _T("错误"), MB_OK | MB_ICONERROR);  // 弹出错误提示
        return;  // 直接结束函数
    }

    int last_idx = G.vexnum - 1;  // 记录删除前最后一个节点的编号

    // 1. 释放被删节点自身的出边（含所有班次）
    FreeArcList(G.vertices[idx].firstarc);  // 先把这个城市发出的所有线路和班次清掉
    G.vertices[idx].firstarc = NULL;  // 把它的第一条边指针清空

    // 2. 删除所有其他节点指向 idx 的边，并修正 > idx 的索引
    for (int i = 0; i < G.vexnum; i++) {  // 遍历所有城市，检查谁还连着这个城市
        ArcNode** p = &G.vertices[i].firstarc;  // 指向当前城市的边链表头
        while (*p != NULL) {  // 只要还有边，就继续处理
            if ((*p)->adjvex == idx) {  // 如果这条边指向要删的城市
                ArcNode* temp = *p;  // 先保存这条边
                *p = (*p)->nextarc;  // 从链表中把它摘掉
                FreeScheduleList(temp->sch_list);  // 先释放它身上的班次链表
                free(temp);                         // 再释放这条边本身
            } else {
                if ((*p)->adjvex > idx) (*p)->adjvex--;  // 如果边指向的编号比删掉的编号大，就往前移动一位
                p = &((*p)->nextarc);  // 继续看下一条边
            }
        }
    }

    // 3. 移动末尾节点到被删位置（如果不是删最后一个）
    if (idx < last_idx) {  // 如果被删的不是最后一个城市，就把最后一个城市顶上来
        G.vertices[idx] = G.vertices[last_idx];  // 把最后一个城市搬到被删的位置
        // 修正：所有指向 last_idx 的边现在应指向 idx
        for (int i = 0; i < G.vexnum; i++) {  // 再遍历一遍，把所有指向最后一个城市的边改成指向新位置
            for (ArcNode* arc = G.vertices[i].firstarc; arc; arc = arc->nextarc) {  // 从每个城市的边链表里找
                if (arc->adjvex == last_idx) {  // 如果某条边原来指向最后一个城市
                    arc->adjvex = idx;  // 改成指向被顶上来的城市
                }
            }
        }
    }

    G.vexnum--;  // 城市数量减 1
    
    MessageBox(GetHWnd(), _T("节点删除成功，相关链路已清理。"), _T("提示"), MB_OK | MB_ICONINFORMATION);  // 删除完成后给出提示
}

// 参与人员：吴 王
//=============================================================================
// 第五部分：全国交通网络测试数据
//=============================================================================
// 这个函数构建了整个系统的初始数据！包含31个城市和近百条航空/铁路线路
// 城市分布覆盖：华北、东北、华东、华中、华南、西南、西北七大区域
// 数据组织方式：先建城市（AddVertex），再建线路（AddArc），再挂班次（AddSchedule）
// 每条线路至少有一个班次，主要干线有2个班次（上午/下午各一班）
// 票价和时间的设定参考了现实中的大致比例（飞机贵但快、火车便宜但慢）
// ----------------- 全国交通网络测试数据 -----------------
void InjectTestData() {  // 初始化全国交通网络测试数据
    G.vexnum = 0;  // 初始化城市数量为0，后续 AddVertex 会自增

        // ================= 城市节点：重新排布版 =================
    int ur  = AddVertex(_T("乌鲁木齐"), _T("URC"), 90, 120); // 新疆乌鲁木齐，三字码 URC，地图坐标 (90,120)
    int xn  = AddVertex(_T("西宁"), _T("XNN"), 230, 250);
    int lz  = AddVertex(_T("兰州"), _T("LHW"), 290, 230);
    int yc  = AddVertex(_T("银川"), _T("INC"), 340, 170);
    int hh  = AddVertex(_T("呼和浩特"), _T("HET"), 470, 110);

    int bj  = AddVertex(_T("北京"), _T("BJS"), 600, 170);
    int tj  = AddVertex(_T("天津"), _T("TSN"), 660, 200);
    int sjz = AddVertex(_T("石家庄"), _T("SJW"), 560, 245);
    int ty  = AddVertex(_T("太原"), _T("TYN"), 500, 230);

    int hrb = AddVertex(_T("哈尔滨"), _T("HRB"), 790, 55);
    int cc  = AddVertex(_T("长春"), _T("CGQ"), 760, 105);
    int sy  = AddVertex(_T("沈阳"), _T("SHE"), 730, 165);
    int dl  = AddVertex(_T("大连"), _T("DLC"), 760, 235);

    int xa  = AddVertex(_T("西安"), _T("SIA"), 430, 310);
    int zz  = AddVertex(_T("郑州"), _T("CGO"), 555, 325);
    int jn  = AddVertex(_T("济南"), _T("TNA"), 665, 285);
    int qd  = AddVertex(_T("青岛"), _T("TAO"), 755, 300);

    int hf  = AddVertex(_T("合肥"), _T("HFE"), 640, 390);
    int nj  = AddVertex(_T("南京"), _T("NKG"), 710, 380);
    int sh  = AddVertex(_T("上海"), _T("SHA"), 805, 400);
    int hz  = AddVertex(_T("杭州"), _T("HGH"), 755, 455);

    int wh  = AddVertex(_T("武汉"), _T("WUH"), 560, 430);
    int nc  = AddVertex(_T("南昌"), _T("KHN"), 625, 500);
    int cs  = AddVertex(_T("长沙"), _T("CSX"), 545, 520);

    int cd  = AddVertex(_T("成都"), _T("CTU"), 360, 430);
    int cq  = AddVertex(_T("重庆"), _T("CKG"), 420, 480);
    int gy  = AddVertex(_T("贵阳"), _T("KWE"), 430, 560);
    int km  = AddVertex(_T("昆明"), _T("KMG"), 330, 610);

    int gz  = AddVertex(_T("广州"), _T("CAN"), 590, 615);
    int sz  = AddVertex(_T("深圳"), _T("SZX"), 655, 655);
    int nn  = AddVertex(_T("南宁"), _T("NNG"), 470, 650);
    int hk  = AddVertex(_T("海口"), _T("HAK"), 585, 720);

    // ================= 华北线路 =================

    // 北京 -> 天津
    ArcNode* bj_tj_f = AddArc(bj, tj, 130, TYPE_FLIGHT);  // 添加北京到天津的航班线路，里程130公里，类型为飞机
    AddSchedule(bj_tj_f, _T("CA101"), TimeToMin(_T("08:00")), TimeToMin(_T("08:50")), 360);  // 添加航班 CA101，08:00出发，08:50到达，票价360元
    AddSchedule(bj_tj_f, _T("CA103"), TimeToMin(_T("16:00")), TimeToMin(_T("16:50")), 320);  // 添加航班 CA103，16:00出发，16:50到达，票价320元

    ArcNode* bj_tj_t = AddArc(bj, tj, 130, TYPE_TRAIN);
    AddSchedule(bj_tj_t, _T("C201"), TimeToMin(_T("07:00")), TimeToMin(_T("07:35")), 55);
    AddSchedule(bj_tj_t, _T("C205"), TimeToMin(_T("14:00")), TimeToMin(_T("14:35")), 55);

    // 天津 -> 北京
    ArcNode* tj_bj_f = AddArc(tj, bj, 130, TYPE_FLIGHT);
    AddSchedule(tj_bj_f, _T("CA102"), TimeToMin(_T("09:30")), TimeToMin(_T("10:20")), 360);
    AddSchedule(tj_bj_f, _T("CA104"), TimeToMin(_T("18:00")), TimeToMin(_T("18:50")), 320);

    ArcNode* tj_bj_t = AddArc(tj, bj, 130, TYPE_TRAIN);
    AddSchedule(tj_bj_t, _T("C202"), TimeToMin(_T("08:00")), TimeToMin(_T("08:35")), 55);
    AddSchedule(tj_bj_t, _T("C206"), TimeToMin(_T("15:00")), TimeToMin(_T("15:35")), 55);

    // 北京 -> 石家庄
    ArcNode* bj_sjz_f = AddArc(bj, sjz, 290, TYPE_FLIGHT);
    AddSchedule(bj_sjz_f, _T("CA111"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 420);

    ArcNode* bj_sjz_t = AddArc(bj, sjz, 290, TYPE_TRAIN);
    AddSchedule(bj_sjz_t, _T("G671"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 128);
    AddSchedule(bj_sjz_t, _T("G673"), TimeToMin(_T("15:00")), TimeToMin(_T("16:20")), 128);

    // 石家庄 -> 北京
    ArcNode* sjz_bj_f = AddArc(sjz, bj, 290, TYPE_FLIGHT);
    AddSchedule(sjz_bj_f, _T("CA112"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* sjz_bj_t = AddArc(sjz, bj, 290, TYPE_TRAIN);
    AddSchedule(sjz_bj_t, _T("G672"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 128);
    AddSchedule(sjz_bj_t, _T("G674"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 128);

    // 石家庄 -> 太原
    ArcNode* sjz_ty_f = AddArc(sjz, ty, 230, TYPE_FLIGHT);
    AddSchedule(sjz_ty_f, _T("NS301"), TimeToMin(_T("10:30")), TimeToMin(_T("11:20")), 380);

    ArcNode* sjz_ty_t = AddArc(sjz, ty, 230, TYPE_TRAIN);
    AddSchedule(sjz_ty_t, _T("D1601"), TimeToMin(_T("09:00")), TimeToMin(_T("10:25")), 85);
    AddSchedule(sjz_ty_t, _T("D1603"), TimeToMin(_T("16:00")), TimeToMin(_T("17:25")), 85);

    // 太原 -> 石家庄
    ArcNode* ty_sjz_f = AddArc(ty, sjz, 230, TYPE_FLIGHT);
    AddSchedule(ty_sjz_f, _T("NS302"), TimeToMin(_T("12:30")), TimeToMin(_T("13:20")), 380);

    ArcNode* ty_sjz_t = AddArc(ty, sjz, 230, TYPE_TRAIN);
    AddSchedule(ty_sjz_t, _T("D1602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:25")), 85);
    AddSchedule(ty_sjz_t, _T("D1604"), TimeToMin(_T("18:00")), TimeToMin(_T("19:25")), 85);

    // 太原 -> 呼和浩特
    ArcNode* ty_hh_f = AddArc(ty, hh, 430, TYPE_FLIGHT);
    AddSchedule(ty_hh_f, _T("HU401"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 520);

    ArcNode* ty_hh_t = AddArc(ty, hh, 430, TYPE_TRAIN);
    AddSchedule(ty_hh_t, _T("K1111"), TimeToMin(_T("19:00")), TimeToMin(_T("23:50")), 120);

    // 呼和浩特 -> 太原
    ArcNode* hh_ty_f = AddArc(hh, ty, 430, TYPE_FLIGHT);
    AddSchedule(hh_ty_f, _T("HU402"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 520);

    ArcNode* hh_ty_t = AddArc(hh, ty, 430, TYPE_TRAIN);
    AddSchedule(hh_ty_t, _T("K1112"), TimeToMin(_T("20:00")), TimeToMin(_T("20:00")) + 290, 120);

    // ================= 东北线路 =================

    // 北京 -> 沈阳
    ArcNode* bj_sy_f = AddArc(bj, sy, 700, TYPE_FLIGHT);
    AddSchedule(bj_sy_f, _T("CA1601"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 650);
    AddSchedule(bj_sy_f, _T("CA1603"), TimeToMin(_T("17:00")), TimeToMin(_T("18:30")), 600);

    ArcNode* bj_sy_t = AddArc(bj, sy, 700, TYPE_TRAIN);
    AddSchedule(bj_sy_t, _T("G901"), TimeToMin(_T("07:40")), TimeToMin(_T("11:20")), 295);
    AddSchedule(bj_sy_t, _T("G905"), TimeToMin(_T("14:00")), TimeToMin(_T("17:40")), 295);

    // 沈阳 -> 北京
    ArcNode* sy_bj_f = AddArc(sy, bj, 700, TYPE_FLIGHT);
    AddSchedule(sy_bj_f, _T("CA1602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:30")), 650);
    AddSchedule(sy_bj_f, _T("CA1604"), TimeToMin(_T("19:00")), TimeToMin(_T("20:30")), 600);

    ArcNode* sy_bj_t = AddArc(sy, bj, 700, TYPE_TRAIN);
    AddSchedule(sy_bj_t, _T("G902"), TimeToMin(_T("08:00")), TimeToMin(_T("11:40")), 295);
    AddSchedule(sy_bj_t, _T("G906"), TimeToMin(_T("15:00")), TimeToMin(_T("18:40")), 295);

    // 沈阳 -> 大连
    ArcNode* sy_dl_f = AddArc(sy, dl, 380, TYPE_FLIGHT);
    AddSchedule(sy_dl_f, _T("CZ6411"), TimeToMin(_T("10:00")), TimeToMin(_T("11:00")), 420);

    ArcNode* sy_dl_t = AddArc(sy, dl, 380, TYPE_TRAIN);
    AddSchedule(sy_dl_t, _T("G8001"), TimeToMin(_T("08:00")), TimeToMin(_T("10:00")), 175);
    AddSchedule(sy_dl_t, _T("G8005"), TimeToMin(_T("14:00")), TimeToMin(_T("16:00")), 175);

    // 大连 -> 沈阳
    ArcNode* dl_sy_f = AddArc(dl, sy, 380, TYPE_FLIGHT);
    AddSchedule(dl_sy_f, _T("CZ6412"), TimeToMin(_T("12:00")), TimeToMin(_T("13:00")), 420);

    ArcNode* dl_sy_t = AddArc(dl, sy, 380, TYPE_TRAIN);
    AddSchedule(dl_sy_t, _T("G8002"), TimeToMin(_T("09:00")), TimeToMin(_T("11:00")), 175);
    AddSchedule(dl_sy_t, _T("G8006"), TimeToMin(_T("15:00")), TimeToMin(_T("17:00")), 175);

    // 沈阳 -> 长春
    ArcNode* sy_cc_f = AddArc(sy, cc, 310, TYPE_FLIGHT);
    AddSchedule(sy_cc_f, _T("CZ6511"), TimeToMin(_T("09:20")), TimeToMin(_T("10:10")), 400);

    ArcNode* sy_cc_t = AddArc(sy, cc, 310, TYPE_TRAIN);
    AddSchedule(sy_cc_t, _T("G8011"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 145);
    AddSchedule(sy_cc_t, _T("G8013"), TimeToMin(_T("16:30")), TimeToMin(_T("18:00")), 145);

    // 长春 -> 沈阳
    ArcNode* cc_sy_f = AddArc(cc, sy, 310, TYPE_FLIGHT);
    AddSchedule(cc_sy_f, _T("CZ6512"), TimeToMin(_T("11:00")), TimeToMin(_T("11:50")), 400);

    ArcNode* cc_sy_t = AddArc(cc, sy, 310, TYPE_TRAIN);
    AddSchedule(cc_sy_t, _T("G8012"), TimeToMin(_T("10:30")), TimeToMin(_T("12:00")), 145);
    AddSchedule(cc_sy_t, _T("G8014"), TimeToMin(_T("18:30")), TimeToMin(_T("20:00")), 145);

    // 长春 -> 哈尔滨
    ArcNode* cc_hrb_f = AddArc(cc, hrb, 250, TYPE_FLIGHT);
    AddSchedule(cc_hrb_f, _T("CZ6611"), TimeToMin(_T("08:50")), TimeToMin(_T("09:40")), 380);

    ArcNode* cc_hrb_t = AddArc(cc, hrb, 250, TYPE_TRAIN);
    AddSchedule(cc_hrb_t, _T("G1201"), TimeToMin(_T("09:00")), TimeToMin(_T("10:20")), 110);
    AddSchedule(cc_hrb_t, _T("G1203"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 110);

    // 哈尔滨 -> 长春
    ArcNode* hrb_cc_f = AddArc(hrb, cc, 250, TYPE_FLIGHT);
    AddSchedule(hrb_cc_f, _T("CZ6612"), TimeToMin(_T("10:30")), TimeToMin(_T("11:20")), 380);

    ArcNode* hrb_cc_t = AddArc(hrb, cc, 250, TYPE_TRAIN);
    AddSchedule(hrb_cc_t, _T("G1202"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 110);
    AddSchedule(hrb_cc_t, _T("G1204"), TimeToMin(_T("19:00")), TimeToMin(_T("20:20")), 110);
        // ================= 华东线路 =================

    // 北京 -> 济南
    ArcNode* bj_jn_f = AddArc(bj, jn, 420, TYPE_FLIGHT);
    AddSchedule(bj_jn_f, _T("CA201"), TimeToMin(_T("08:20")), TimeToMin(_T("09:30")), 520);
    AddSchedule(bj_jn_f, _T("CA203"), TimeToMin(_T("16:20")), TimeToMin(_T("17:30")), 480);

    ArcNode* bj_jn_t = AddArc(bj, jn, 420, TYPE_TRAIN);
    AddSchedule(bj_jn_t, _T("G101"), TimeToMin(_T("07:00")), TimeToMin(_T("08:40")), 185);
    AddSchedule(bj_jn_t, _T("G103"), TimeToMin(_T("14:00")), TimeToMin(_T("15:40")), 185);

    // 济南 -> 北京
    ArcNode* jn_bj_f = AddArc(jn, bj, 420, TYPE_FLIGHT);
    AddSchedule(jn_bj_f, _T("CA202"), TimeToMin(_T("10:20")), TimeToMin(_T("11:30")), 520);

    ArcNode* jn_bj_t = AddArc(jn, bj, 420, TYPE_TRAIN);
    AddSchedule(jn_bj_t, _T("G102"), TimeToMin(_T("09:20")), TimeToMin(_T("11:00")), 185);
    AddSchedule(jn_bj_t, _T("G104"), TimeToMin(_T("17:20")), TimeToMin(_T("19:00")), 185);

    // 济南 -> 青岛
    ArcNode* jn_qd_f = AddArc(jn, qd, 360, TYPE_FLIGHT);
    AddSchedule(jn_qd_f, _T("SC801"), TimeToMin(_T("09:00")), TimeToMin(_T("09:50")), 390);

    ArcNode* jn_qd_t = AddArc(jn, qd, 360, TYPE_TRAIN);
    AddSchedule(jn_qd_t, _T("G221"), TimeToMin(_T("08:30")), TimeToMin(_T("10:10")), 121);
    AddSchedule(jn_qd_t, _T("G223"), TimeToMin(_T("15:30")), TimeToMin(_T("17:10")), 121);

    // 青岛 -> 济南
    ArcNode* qd_jn_f = AddArc(qd, jn, 360, TYPE_FLIGHT);
    AddSchedule(qd_jn_f, _T("SC802"), TimeToMin(_T("11:00")), TimeToMin(_T("11:50")), 390);

    ArcNode* qd_jn_t = AddArc(qd, jn, 360, TYPE_TRAIN);
    AddSchedule(qd_jn_t, _T("G222"), TimeToMin(_T("11:00")), TimeToMin(_T("12:40")), 121);
    AddSchedule(qd_jn_t, _T("G224"), TimeToMin(_T("18:00")), TimeToMin(_T("19:40")), 121);

    // 南京 -> 上海
    ArcNode* nj_sh_f = AddArc(nj, sh, 300, TYPE_FLIGHT);
    AddSchedule(nj_sh_f, _T("MU2801"), TimeToMin(_T("09:30")), TimeToMin(_T("10:30")), 420);

    ArcNode* nj_sh_t = AddArc(nj, sh, 300, TYPE_TRAIN);
    AddSchedule(nj_sh_t, _T("G7001"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 135);
    AddSchedule(nj_sh_t, _T("G7003"), TimeToMin(_T("14:00")), TimeToMin(_T("15:20")), 135);

    // 上海 -> 南京
    ArcNode* sh_nj_f = AddArc(sh, nj, 300, TYPE_FLIGHT);
    AddSchedule(sh_nj_f, _T("MU2802"), TimeToMin(_T("11:30")), TimeToMin(_T("12:30")), 420);

    ArcNode* sh_nj_t = AddArc(sh, nj, 300, TYPE_TRAIN);
    AddSchedule(sh_nj_t, _T("G7002"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 135);
    AddSchedule(sh_nj_t, _T("G7004"), TimeToMin(_T("16:00")), TimeToMin(_T("17:20")), 135);

    // 上海 -> 杭州
    ArcNode* sh_hz_f = AddArc(sh, hz, 180, TYPE_FLIGHT);
    AddSchedule(sh_hz_f, _T("FM911"), TimeToMin(_T("09:20")), TimeToMin(_T("10:00")), 360);

    ArcNode* sh_hz_t = AddArc(sh, hz, 180, TYPE_TRAIN);
    AddSchedule(sh_hz_t, _T("G7311"), TimeToMin(_T("08:00")), TimeToMin(_T("09:00")), 73);
    AddSchedule(sh_hz_t, _T("G7313"), TimeToMin(_T("15:00")), TimeToMin(_T("16:00")), 73);

    // 杭州 -> 上海
    ArcNode* hz_sh_f = AddArc(hz, sh, 180, TYPE_FLIGHT);
    AddSchedule(hz_sh_f, _T("FM912"), TimeToMin(_T("11:20")), TimeToMin(_T("12:00")), 360);

    ArcNode* hz_sh_t = AddArc(hz, sh, 180, TYPE_TRAIN);
    AddSchedule(hz_sh_t, _T("G7312"), TimeToMin(_T("10:00")), TimeToMin(_T("11:00")), 73);
    AddSchedule(hz_sh_t, _T("G7314"), TimeToMin(_T("17:00")), TimeToMin(_T("18:00")), 73);

    // 南京 -> 合肥
    ArcNode* nj_hf_t = AddArc(nj, hf, 180, TYPE_TRAIN);
    AddSchedule(nj_hf_t, _T("G7251"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 86);

    ArcNode* hf_nj_t = AddArc(hf, nj, 180, TYPE_TRAIN);
    AddSchedule(hf_nj_t, _T("G7252"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 86);

    // ================= 华中线路 =================

    // 郑州 -> 武汉
    ArcNode* zz_wh_f = AddArc(zz, wh, 520, TYPE_FLIGHT);
    AddSchedule(zz_wh_f, _T("CZ8801"), TimeToMin(_T("09:00")), TimeToMin(_T("10:10")), 500);

    ArcNode* zz_wh_t = AddArc(zz, wh, 520, TYPE_TRAIN);
    AddSchedule(zz_wh_t, _T("G551"), TimeToMin(_T("08:00")), TimeToMin(_T("10:00")), 244);
    AddSchedule(zz_wh_t, _T("G553"), TimeToMin(_T("15:00")), TimeToMin(_T("17:00")), 244);

    // 武汉 -> 郑州
    ArcNode* wh_zz_f = AddArc(wh, zz, 520, TYPE_FLIGHT);
    AddSchedule(wh_zz_f, _T("CZ8802"), TimeToMin(_T("11:00")), TimeToMin(_T("12:10")), 500);

    ArcNode* wh_zz_t = AddArc(wh, zz, 520, TYPE_TRAIN);
    AddSchedule(wh_zz_t, _T("G552"), TimeToMin(_T("10:30")), TimeToMin(_T("12:30")), 244);
    AddSchedule(wh_zz_t, _T("G554"), TimeToMin(_T("18:00")), TimeToMin(_T("20:00")), 244);

    // 武汉 -> 长沙
    ArcNode* wh_cs_f = AddArc(wh, cs, 350, TYPE_FLIGHT);
    AddSchedule(wh_cs_f, _T("CZ8811"), TimeToMin(_T("08:30")), TimeToMin(_T("09:30")), 420);

    ArcNode* wh_cs_t = AddArc(wh, cs, 350, TYPE_TRAIN);
    AddSchedule(wh_cs_t, _T("G601"), TimeToMin(_T("09:00")), TimeToMin(_T("10:30")), 164);
    AddSchedule(wh_cs_t, _T("G603"), TimeToMin(_T("16:00")), TimeToMin(_T("17:30")), 164);

    // 长沙 -> 武汉
    ArcNode* cs_wh_f = AddArc(cs, wh, 350, TYPE_FLIGHT);
    AddSchedule(cs_wh_f, _T("CZ8812"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* cs_wh_t = AddArc(cs, wh, 350, TYPE_TRAIN);
    AddSchedule(cs_wh_t, _T("G602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:30")), 164);
    AddSchedule(cs_wh_t, _T("G604"), TimeToMin(_T("18:00")), TimeToMin(_T("19:30")), 164);

    // 武汉 -> 南昌
    ArcNode* wh_nc_t = AddArc(wh, nc, 340, TYPE_TRAIN);
    AddSchedule(wh_nc_t, _T("D321"), TimeToMin(_T("09:00")), TimeToMin(_T("11:00")), 150);

    // 南昌 -> 武汉
    ArcNode* nc_wh_t = AddArc(nc, wh, 340, TYPE_TRAIN);
    AddSchedule(nc_wh_t, _T("D322"), TimeToMin(_T("13:00")), TimeToMin(_T("15:00")), 150);

    // 武汉 -> 上海
    ArcNode* wh_sh_f = AddArc(wh, sh, 820, TYPE_FLIGHT);
    AddSchedule(wh_sh_f, _T("MU5101"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 690);

    ArcNode* wh_sh_t = AddArc(wh, sh, 820, TYPE_TRAIN);
    AddSchedule(wh_sh_t, _T("G1722"), TimeToMin(_T("08:00")), TimeToMin(_T("12:30")), 370);

    // 上海 -> 武汉
    ArcNode* sh_wh_f = AddArc(sh, wh, 820, TYPE_FLIGHT);
    AddSchedule(sh_wh_f, _T("MU5102"), TimeToMin(_T("11:30")), TimeToMin(_T("13:00")), 690);

    ArcNode* sh_wh_t = AddArc(sh, wh, 820, TYPE_TRAIN);
    AddSchedule(sh_wh_t, _T("G1723"), TimeToMin(_T("14:00")), TimeToMin(_T("18:30")), 370);
        // ================= 华南线路 =================

    // 长沙 -> 广州
    ArcNode* cs_gz_f = AddArc(cs, gz, 670, TYPE_FLIGHT);
    AddSchedule(cs_gz_f, _T("CZ3011"), TimeToMin(_T("09:00")), TimeToMin(_T("10:20")), 560);

    ArcNode* cs_gz_t = AddArc(cs, gz, 670, TYPE_TRAIN);
    AddSchedule(cs_gz_t, _T("G801"), TimeToMin(_T("08:00")), TimeToMin(_T("10:45")), 314);
    AddSchedule(cs_gz_t, _T("G803"), TimeToMin(_T("15:00")), TimeToMin(_T("17:45")), 314);

    // 广州 -> 长沙
    ArcNode* gz_cs_f = AddArc(gz, cs, 670, TYPE_FLIGHT);
    AddSchedule(gz_cs_f, _T("CZ3012"), TimeToMin(_T("11:30")), TimeToMin(_T("12:50")), 560);

    ArcNode* gz_cs_t = AddArc(gz, cs, 670, TYPE_TRAIN);
    AddSchedule(gz_cs_t, _T("G802"), TimeToMin(_T("11:30")), TimeToMin(_T("14:15")), 314);
    AddSchedule(gz_cs_t, _T("G804"), TimeToMin(_T("18:30")), TimeToMin(_T("21:15")), 314);

    // 广州 -> 深圳
    ArcNode* gz_sz_t = AddArc(gz, sz, 140, TYPE_TRAIN);
    AddSchedule(gz_sz_t, _T("G6501"), TimeToMin(_T("08:00")), TimeToMin(_T("08:40")), 75);
    AddSchedule(gz_sz_t, _T("G6503"), TimeToMin(_T("16:00")), TimeToMin(_T("16:40")), 75);

    ArcNode* sz_gz_t = AddArc(sz, gz, 140, TYPE_TRAIN);
    AddSchedule(sz_gz_t, _T("G6502"), TimeToMin(_T("09:00")), TimeToMin(_T("09:40")), 75);
    AddSchedule(sz_gz_t, _T("G6504"), TimeToMin(_T("17:00")), TimeToMin(_T("17:40")), 75);

    // 广州 -> 南宁
    ArcNode* gz_nn_f = AddArc(gz, nn, 560, TYPE_FLIGHT);
    AddSchedule(gz_nn_f, _T("CZ3291"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 530);

    ArcNode* gz_nn_t = AddArc(gz, nn, 560, TYPE_TRAIN);
    AddSchedule(gz_nn_t, _T("D3601"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 210);

    // 南宁 -> 广州
    ArcNode* nn_gz_f = AddArc(nn, gz, 560, TYPE_FLIGHT);
    AddSchedule(nn_gz_f, _T("CZ3292"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 530);

    ArcNode* nn_gz_t = AddArc(nn, gz, 560, TYPE_TRAIN);
    AddSchedule(nn_gz_t, _T("D3602"), TimeToMin(_T("14:00")), TimeToMin(_T("17:30")), 210);

    // 广州 -> 海口
    ArcNode* gz_hk_f = AddArc(gz, hk, 600, TYPE_FLIGHT);
    AddSchedule(gz_hk_f, _T("CZ6771"), TimeToMin(_T("10:00")), TimeToMin(_T("11:25")), 620);
    AddSchedule(gz_hk_f, _T("CZ6773"), TimeToMin(_T("18:00")), TimeToMin(_T("19:25")), 580);

    ArcNode* hk_gz_f = AddArc(hk, gz, 600, TYPE_FLIGHT);
    AddSchedule(hk_gz_f, _T("CZ6772"), TimeToMin(_T("12:30")), TimeToMin(_T("13:55")), 620);
    AddSchedule(hk_gz_f, _T("CZ6774"), TimeToMin(_T("20:30")), TimeToMin(_T("21:55")), 580);

    // ================= 西南线路 =================

    // 武汉 -> 重庆
    ArcNode* wh_cq_f = AddArc(wh, cq, 870, TYPE_FLIGHT);
    AddSchedule(wh_cq_f, _T("CA4301"), TimeToMin(_T("09:30")), TimeToMin(_T("11:10")), 680);

    ArcNode* wh_cq_t = AddArc(wh, cq, 870, TYPE_TRAIN);
    AddSchedule(wh_cq_t, _T("D2231"), TimeToMin(_T("08:00")), TimeToMin(_T("14:30")), 260);

    // 重庆 -> 武汉
    ArcNode* cq_wh_f = AddArc(cq, wh, 870, TYPE_FLIGHT);
    AddSchedule(cq_wh_f, _T("CA4302"), TimeToMin(_T("12:30")), TimeToMin(_T("14:10")), 680);

    ArcNode* cq_wh_t = AddArc(cq, wh, 870, TYPE_TRAIN);
    AddSchedule(cq_wh_t, _T("D2232"), TimeToMin(_T("15:30")), TimeToMin(_T("22:00")), 260);

    // 重庆 -> 成都
    ArcNode* cq_cd_t = AddArc(cq, cd, 310, TYPE_TRAIN);
    AddSchedule(cq_cd_t, _T("G8501"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 146);
    AddSchedule(cq_cd_t, _T("G8503"), TimeToMin(_T("15:00")), TimeToMin(_T("16:20")), 146);

    ArcNode* cd_cq_t = AddArc(cd, cq, 310, TYPE_TRAIN);
    AddSchedule(cd_cq_t, _T("G8502"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 146);
    AddSchedule(cd_cq_t, _T("G8504"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 146);

    // 重庆 -> 贵阳
    ArcNode* cq_gy_f = AddArc(cq, gy, 380, TYPE_FLIGHT);
    AddSchedule(cq_gy_f, _T("3U8511"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 420);

    ArcNode* cq_gy_t = AddArc(cq, gy, 380, TYPE_TRAIN);
    AddSchedule(cq_gy_t, _T("D8551"), TimeToMin(_T("08:30")), TimeToMin(_T("10:40")), 130);

    ArcNode* gy_cq_f = AddArc(gy, cq, 380, TYPE_FLIGHT);
    AddSchedule(gy_cq_f, _T("3U8512"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* gy_cq_t = AddArc(gy, cq, 380, TYPE_TRAIN);
    AddSchedule(gy_cq_t, _T("D8552"), TimeToMin(_T("13:00")), TimeToMin(_T("15:10")), 130);

    // 贵阳 -> 昆明
    ArcNode* gy_km_f = AddArc(gy, km, 520, TYPE_FLIGHT);
    AddSchedule(gy_km_f, _T("MU5901"), TimeToMin(_T("10:00")), TimeToMin(_T("11:10")), 500);

    ArcNode* gy_km_t = AddArc(gy, km, 520, TYPE_TRAIN);
    AddSchedule(gy_km_t, _T("G2831"), TimeToMin(_T("09:00")), TimeToMin(_T("11:30")), 212);

    ArcNode* km_gy_f = AddArc(km, gy, 520, TYPE_FLIGHT);
    AddSchedule(km_gy_f, _T("MU5902"), TimeToMin(_T("12:00")), TimeToMin(_T("13:10")), 500);

    ArcNode* km_gy_t = AddArc(km, gy, 520, TYPE_TRAIN);
    AddSchedule(km_gy_t, _T("G2832"), TimeToMin(_T("14:00")), TimeToMin(_T("16:30")), 212);

    // 成都 -> 昆明
    ArcNode* cd_km_f = AddArc(cd, km, 650, TYPE_FLIGHT);
    AddSchedule(cd_km_f, _T("3U8667"), TimeToMin(_T("12:30")), TimeToMin(_T("14:00")), 520);

    ArcNode* cd_km_t = AddArc(cd, km, 650, TYPE_TRAIN);
    AddSchedule(cd_km_t, _T("G2837"), TimeToMin(_T("09:30")), TimeToMin(_T("15:00")), 280);

    ArcNode* km_cd_f = AddArc(km, cd, 650, TYPE_FLIGHT);
    AddSchedule(km_cd_f, _T("3U8668"), TimeToMin(_T("15:00")), TimeToMin(_T("16:30")), 520);

    ArcNode* km_cd_t = AddArc(km, cd, 650, TYPE_TRAIN);
    AddSchedule(km_cd_t, _T("G2838"), TimeToMin(_T("16:00")), TimeToMin(_T("21:30")), 280);

    // ================= 西北线路 =================

    // 郑州 -> 西安
    ArcNode* zz_xa_f = AddArc(zz, xa, 480, TYPE_FLIGHT);  // 郑州到西安的航班
    AddSchedule(zz_xa_f, _T("MU2201"), TimeToMin(_T("09:00")), TimeToMin(_T("10:10")), 480);

    ArcNode* zz_xa_t = AddArc(zz, xa, 480, TYPE_TRAIN);
    AddSchedule(zz_xa_t, _T("G2001"), TimeToMin(_T("08:00")), TimeToMin(_T("10:10")), 230);

    ArcNode* xa_zz_f = AddArc(xa, zz, 480, TYPE_FLIGHT);
    AddSchedule(xa_zz_f, _T("MU2202"), TimeToMin(_T("11:00")), TimeToMin(_T("12:10")), 480);

    ArcNode* xa_zz_t = AddArc(xa, zz, 480, TYPE_TRAIN);
    AddSchedule(xa_zz_t, _T("G2002"), TimeToMin(_T("13:00")), TimeToMin(_T("15:10")), 230);

    // 西安 -> 兰州
    ArcNode* xa_lz_f = AddArc(xa, lz, 630, TYPE_FLIGHT);
    AddSchedule(xa_lz_f, _T("MU2311"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 520);

    ArcNode* xa_lz_t = AddArc(xa, lz, 630, TYPE_TRAIN);
    AddSchedule(xa_lz_t, _T("D2651"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 174);

    ArcNode* lz_xa_f = AddArc(lz, xa, 630, TYPE_FLIGHT);
    AddSchedule(lz_xa_f, _T("MU2312"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 520);

    ArcNode* lz_xa_t = AddArc(lz, xa, 630, TYPE_TRAIN);
    AddSchedule(lz_xa_t, _T("D2652"), TimeToMin(_T("14:00")), TimeToMin(_T("17:30")), 174);

    // 兰州 -> 西宁
    ArcNode* lz_xn_t = AddArc(lz, xn, 220, TYPE_TRAIN);
    AddSchedule(lz_xn_t, _T("D2701"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 58);

    ArcNode* xn_lz_t = AddArc(xn, lz, 220, TYPE_TRAIN);
    AddSchedule(xn_lz_t, _T("D2702"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 58);

    // 兰州 -> 银川
    ArcNode* lz_yc_f = AddArc(lz, yc, 420, TYPE_FLIGHT);
    AddSchedule(lz_yc_f, _T("MU2411"), TimeToMin(_T("09:30")), TimeToMin(_T("10:30")), 420);

    ArcNode* lz_yc_t = AddArc(lz, yc, 420, TYPE_TRAIN);
    AddSchedule(lz_yc_t, _T("K9661"), TimeToMin(_T("18:30")), TimeToMin(_T("23:40")), 95);

    ArcNode* yc_lz_f = AddArc(yc, lz, 420, TYPE_FLIGHT);
    AddSchedule(yc_lz_f, _T("MU2412"), TimeToMin(_T("11:30")), TimeToMin(_T("12:30")), 420);

    ArcNode* yc_lz_t = AddArc(yc, lz, 420, TYPE_TRAIN);
    AddSchedule(yc_lz_t, _T("K9662"), TimeToMin(_T("19:30")), TimeToMin(_T("19:30")) + 310, 95);

    // 兰州 -> 乌鲁木齐
    ArcNode* lz_ur_f = AddArc(lz, ur, 1900, TYPE_FLIGHT);
    AddSchedule(lz_ur_f, _T("CZ6901"), TimeToMin(_T("08:30")), TimeToMin(_T("11:30")), 980);

    ArcNode* lz_ur_t = AddArc(lz, ur, 1900, TYPE_TRAIN);
    AddSchedule(lz_ur_t, _T("Z105"), TimeToMin(_T("19:00")), TimeToMin(_T("19:00")) + 1220, 310);

    ArcNode* ur_lz_f = AddArc(ur, lz, 1900, TYPE_FLIGHT);
    AddSchedule(ur_lz_f, _T("CZ6902"), TimeToMin(_T("12:30")), TimeToMin(_T("15:30")), 980);

    ArcNode* ur_lz_t = AddArc(ur, lz, 1900, TYPE_TRAIN);
    AddSchedule(ur_lz_t, _T("Z106"), TimeToMin(_T("20:00")), TimeToMin(_T("20:00")) + 1220, 310);

    // 北京 -> 西安
    ArcNode* bj_xa_f = AddArc(bj, xa, 1100, TYPE_FLIGHT);  // 添加北京到西安的航班弧
    AddSchedule(bj_xa_f, _T("CA1201"), TimeToMin(_T("08:00")), TimeToMin(_T("10:10")), 760);  // 北京到西安的航班
    AddSchedule(bj_xa_f, _T("CA1203"), TimeToMin(_T("16:00")), TimeToMin(_T("18:10")), 720);  // 北京到西安的航班

    ArcNode* bj_xa_t = AddArc(bj, xa, 1100, TYPE_TRAIN);
    AddSchedule(bj_xa_t, _T("G651"), TimeToMin(_T("07:00")), TimeToMin(_T("12:30")), 515);

    ArcNode* xa_bj_f = AddArc(xa, bj, 1100, TYPE_FLIGHT);
    AddSchedule(xa_bj_f, _T("CA1202"), TimeToMin(_T("11:30")), TimeToMin(_T("13:40")), 760);

    ArcNode* xa_bj_t = AddArc(xa, bj, 1100, TYPE_TRAIN);
    AddSchedule(xa_bj_t, _T("G652"), TimeToMin(_T("14:00")), TimeToMin(_T("19:30")), 515);

    // 西安 -> 成都
    ArcNode* xa_cd_f = AddArc(xa, cd, 650, TYPE_FLIGHT);
    AddSchedule(xa_cd_f, _T("MU2205"), TimeToMin(_T("13:00")), TimeToMin(_T("14:30")), 560);

    ArcNode* xa_cd_t = AddArc(xa, cd, 650, TYPE_TRAIN);
    AddSchedule(xa_cd_t, _T("D1921"), TimeToMin(_T("15:00")), TimeToMin(_T("18:30")), 263);

    ArcNode* cd_xa_f = AddArc(cd, xa, 650, TYPE_FLIGHT);
    AddSchedule(cd_xa_f, _T("MU2206"), TimeToMin(_T("15:30")), TimeToMin(_T("17:00")), 560);

    ArcNode* cd_xa_t = AddArc(cd, xa, 650, TYPE_TRAIN);
    AddSchedule(cd_xa_t, _T("D1922"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 263);

    // 收尾：函数结束
}

// 参与人员：董 王
//=============================================================================
// 第六部分：核心路径规划算法
//=============================================================================
// 算法选型：SPFA（Shortest Path Faster Algorithm，Bellman-Ford 的队列优化版）
// 为什么不用 Dijkstra？因为我们的"边权值"不是固定的——同一班次在不同时间出发
//   的等待时间不同，相当于边的权值动态变化。SPFA 能处理这种情况（节点可重复入队）
//
// === 单段路径搜索 ===
// 功能：在 start 和 end 两个城市之间找最优路径
// 参数说明：
//   start, end - 起点和终点城市下标
//   start_time - 出发绝对时间（分钟数）
//   is_transfer_at_start - 起点是否为一个中转站（影响是否需要等待缓冲时间）
//   decision - 优化目标：1=最快到达（时间优先），2=最低费用（省钱优先）
//   vehicle - 交通工具限制：TYPE_FLIGHT/TYPE_TRAIN/TYPE_MIXED
//   path_out, sch_out, types_out - 输出参数，接收找到的路径
// 返回值：true=找到路径，false=无法到达
//
// 核心逻辑（逐行讲解见函数体内注释）：
//   1. 初始化：所有城市的 best_value=INF（不可达），起点的 best_value=start_time
//   2. 起点入队，开始 SPFA 循环
//   3. 每次从队首取出一个城市 u，遍历 u 的所有出边
//   4. 对每条边上的每个班次，计算"如果选这个班次，几点能到 v，花多少钱"
//   5. 如果这条路径比当前记录更优，更新状态并把 v 重新入队
//   6. 队列为空时结束，从 end 回溯出完整路径
// ----------------- 核心算法：单段最优路径搜索 -----------------
bool SolveSingleLeg(int start, int end, int start_time, bool is_transfer_at_start, int decision, int vehicle, vector<int>& path_out, vector<Schedule*>& sch_out, vector<int>& types_out) {
    // state[i] 记录到达第 i 个城市时的最佳状态，in_queue[i] 表示它是否还在 SPFA 队列里
    PathState state[MAX_VERTEX];
    bool in_queue[MAX_VERTEX];
    queue<int> q;  // SPFA 的核心队列，保存等待处理的城市

    // 第1步：把所有城市先设成“还没找到可到达的路径”
    for (int i = 0; i < G.vexnum; i++) {
        state[i].best_value = INF;  // 默认设为无限大，表示当前不可达
        state[i].pre_vex = -1;  // 还没有前驱城市
        state[i].chosen_sch = NULL;  // 还没有选中的班次
        state[i].arrival_time = INF;  // 还没有实际到达时间
        in_queue[i] = false;  // 一开始都不在队列中
    }

    // 第2步：给起点一个初始状态，并把它放进队列
    state[start].arrival_time = start_time;  // 起点的到达时间就是出发时间
    state[start].best_value = (decision == 1) ? start_time : 0;  // 时间优先用时间，费用优先用费用初值 0
    q.push(start);  // 把起点加入等待队列
    in_queue[start] = true;  // 标记它已经在队列里

    // 第3步：只要队列里还有城市，就继续做松弛运算
    while (!q.empty()) {
        int u = q.front(); q.pop();  // 取出队首城市进行处理
        in_queue[u] = false;  // 处理完后取消队列标记

        // 遍历当前城市 u 发出的所有交通线路
        for (ArcNode* arc = G.vertices[u].firstarc; arc != NULL; arc = arc->nextarc) {
            if (vehicle != TYPE_MIXED && arc->type != vehicle) continue;  // 如果限制了交通方式，就跳过不符合的线路
            int v = arc->adjvex;  // 这条线通向的下一个城市

            // 换乘缓冲时间：飞机需要更长的准备时间，火车则更短
            int min_wait = (arc->type == TYPE_FLIGHT) ? 120 : 60;

            // 遍历这条线路上挂着的所有班次
            for (Schedule* sch = arc->sch_list; sch != NULL; sch = sch->next) {
                int u_arrival = state[u].arrival_time;  // 当前城市 u 的到达时间
                // 如果起点就不用等待缓冲，否则需要预留换乘时间
                int buffer = (u == start && !is_transfer_at_start) ? 0 : min_wait;
                int earliest_dep = u_arrival + buffer;   // 这个班次最早能从 u 出发的时间

                // 如果班次已经过了，就推到下一天再算
                int day_offset = 0;
                if (sch->dep_time < earliest_dep) {
                    day_offset = ((earliest_dep - sch->dep_time - 1) / 1440 + 1) * 1440;
                }
                int actual_arr = sch->arr_time + day_offset;  // 计算出真正到达 v 的绝对时间

                // 第4步：检查这条路线是否更优，如果更好就更新状态
                if (decision == 1) {  // 时间优先：尽量让到达更早
                    if (actual_arr < state[v].best_value) {
                        state[v].best_value = actual_arr;  // 更新最早到达时间
                        state[v].arrival_time = actual_arr;  // 更新到达时刻
                        state[v].pre_vex = u;  // 记录前一个城市
                        state[v].chosen_sch = sch;  // 记录选中的班次
                        state[v].chosen_type = arc->type;  // 记录交通类型
                        if (!in_queue[v]) {
                            q.push(v);  // 如果这个城市还没在队列里，就加入
                            in_queue[v] = true;
                        }
                    }
                }
                else {  // 费用优先：尽量让总花费更少，时间相同则优先更早到
                    double cost = state[u].best_value + sch->cost;
                    if (cost < state[v].best_value || (cost == state[v].best_value && actual_arr < state[v].arrival_time)) {
                        state[v].best_value = cost;  // 更新累计费用
                        state[v].arrival_time = actual_arr;  // 更新实际到达时间
                        state[v].pre_vex = u;  // 记录前一个城市
                        state[v].chosen_sch = sch;  // 记录选中的班次
                        state[v].chosen_type = arc->type;  // 记录交通类型
                        if (!in_queue[v]) {
                            q.push(v);  // 如果这个城市还没在队列里，就加入
                            in_queue[v] = true;
                        }
                    }
                }
            }
        }
    }

    // 第5步：从终点开始反推整条路径
    if (state[end].best_value >= INF) return false;  // 如果终点仍然不可达，说明没有找到路线

    vector<int> temp_path;  // 临时保存城市编号路径
    vector<Schedule*> temp_sch;  // 临时保存每段班次
    vector<int> temp_types;  // 临时保存每段交通类型
    int curr = end;  // 当前回溯到的城市
    while (curr != start) {  // 从终点一步步回到起点
        temp_path.push_back(curr);  // 把当前城市加入路径
        temp_sch.push_back(state[curr].chosen_sch);  // 把对应班次记录下来
        temp_types.push_back(state[curr].chosen_type);  // 把交通类型记录下来
        curr = state[curr].pre_vex;  // 往前一个城市回退
    }
    temp_path.push_back(start);  // 最后把起点也加入路径

    // 回溯得到的是终点到起点的顺序，所以要翻转成起点到终点
    reverse(temp_path.begin(), temp_path.end());
    reverse(temp_sch.begin(), temp_sch.end());
    reverse(temp_types.begin(), temp_types.end());

    path_out = temp_path;  // 输出最终城市路径
    sch_out = temp_sch;  // 输出每段班次
    types_out = temp_types;  // 输出每段交通类型
    return true;  // 找到了可行路径
}

// === 路线计算结果结构体 ===
// 存储一条完整出行方案的所有信息
struct GlobalResult {  // 把一次完整路线查询的所有结果打包成一个结构体，方便后续显示和保存
    vector<int> full_path;              // 途经城市编号序列，例如 [北京, 天津, 上海]
    vector<Schedule*> full_schs;        // 每一段路线对应选中的班次指针
    vector<int> dep_times_absolute;     // 每段实际出发时间，单位是“从 0 点开始的分钟数”
    vector<int> arr_times_absolute;     // 每段实际到达时间，单位也是分钟数
    vector<int> segment_types;          // 每段交通类型，飞机或火车
    int total_duration;                 // 全程总耗时，单位为分钟
    double total_cost;                  // 全程总费用，单位为元
};
// 参与人员：董
// ----------------- 历史记录功能 -----------------
#define MAX_HISTORY 20  // 历史记录最多保存 20 条，避免占用太多内存

typedef basic_string<TCHAR> TString;  // 给 TCHAR 字符串取一个简写别名，方便后面拼接文本

struct HistoryRecord {  // 历史记录中的一条数据，包含标题和详细内容
    TString title;      // 简短标题，用来在列表里显示
    TString detail;     // 完整路线信息，详细展示给用户
};

vector<HistoryRecord> g_history;  // 全局历史记录容器，保存用户以前查询过的路线

// 参与人员：董
const TCHAR* VehicleName(int vehicle) {  // 把数字类型转换成用户可读的交通方式文字
    if (vehicle == TYPE_FLIGHT) return _T("航空");
    if (vehicle == TYPE_TRAIN) return _T("铁路");
    if (vehicle == TYPE_MIXED) return _T("混合");
    return _T("未知");
}

// 参与人员：董
const TCHAR* DecisionName(int decision) {  // 把策略编号换成更直观的文字说明
    if (decision == 1) return _T("最快到达");
    if (decision == 2) return _T("最低费用");
    return _T("未知策略");
}

// 参与人员：董 李
// （李：扩展详细查询内容保存，含完整分段行程信息）
void AddHistoryRecord(  // 把一次成功的路线查询结果保存到历史记录里，方便后面查看
    int start_node,
    int end_node,
    const vector<int>& vias,
    int vehicle,
    int decision,
    int start_hour,
    int start_minute,
    const GlobalResult& res
) {
    if (res.total_duration == INF || res.full_path.empty() || res.full_schs.empty()) {
        return;  // 如果没有找到有效路线，就不用保存
    }

    SYSTEMTIME st;  // 当前系统时间，用于生成查询时间和标题
    GetLocalTime(&st);

    TCHAR title_buf[256];  // 用来存放历史记录标题
    _stprintf_s(
        title_buf,
        256,
        _T("[%02d:%02d:%02d] %s → %s | %s | %s"),
        st.wHour,
        st.wMinute,
        st.wSecond,
        G.vertices[start_node].name,
        G.vertices[end_node].name,
        VehicleName(vehicle),
        DecisionName(decision)
    );

    TString detail;  // 用来拼接整条详细路线说明
    TCHAR line[512];  // 临时行缓冲区

    _stprintf_s(
        line,
        512,
        _T("查询时间：%04d-%02d-%02d %02d:%02d:%02d\n"),
        st.wYear,
        st.wMonth,
        st.wDay,
        st.wHour,
        st.wMinute,
        st.wSecond
    );
    detail += line;  // 把查询时间写入详细内容

    _stprintf_s(
        line,
        512,
        _T("起点：%s\n终点：%s\n出发时间：%02d:%02d\n交通方式：%s\n决策方式：%s\n"),
        G.vertices[start_node].name,
        G.vertices[end_node].name,
        start_hour,
        start_minute,
        VehicleName(vehicle),
        DecisionName(decision)
    );
    detail += line;  // 写入起点、终点和策略信息

    if (!vias.empty()) {  // 如果用户设置了途经点，就把它们也写入历史记录
        detail += _T("途径点：");
        for (size_t i = 0; i < vias.size(); i++) {
            detail += G.vertices[vias[i]].name;
            if (i + 1 < vias.size()) detail += _T("、");
        }
        detail += _T("\n");
    }
    else {
        detail += _T("途径点：无\n");
    }

    int segment_count = (int)res.full_schs.size();  // 一共分了多少段
    int transfer_count = segment_count > 0 ? segment_count - 1 : 0;  // 换乘次数等于段数减一

    TString path_overview;  // 先把整条路径概览拼出来
    for (size_t i = 0; i < res.full_path.size(); i++) {
        path_overview += G.vertices[res.full_path[i]].name;
        if (i + 1 < res.full_path.size()) {
            path_overview += _T(" → ");
        }
    }

    _stprintf_s(
        line,
        512,
        _T("路径总览：%s\n"),
        path_overview.c_str()
    );
    detail += line;  // 写入路径总览

    _stprintf_s(
        line,
        512,
        _T("总耗时：%d小时%d分钟\n总费用：%.2f 元\n总段数：%d 段\n换乘次数：%d 次\n\n详细路线：\n"),
        res.total_duration / 60,
        res.total_duration % 60,
        res.total_cost,
        segment_count,
        transfer_count
    );
    detail += line;  // 写入总耗时、总费用和分段数量

    for (size_t i = 0; i < res.full_schs.size(); i++) {  // 逐段写出每一小段路线细节
        int u_idx = res.full_path[i];
        int v_idx = res.full_path[i + 1];

        TCHAR dep_time_str[40];
        TCHAR arr_time_str[40];
        MinToTimeStr(res.dep_times_absolute[i], dep_time_str, 40);  // 把绝对分钟数转成可读时间
        MinToTimeStr(res.arr_times_absolute[i], arr_time_str, 40);

        int wait_min = 0;  // 计算上一段到这一段之间的等待时间
        if (i > 0) {
            wait_min = res.dep_times_absolute[i] - res.arr_times_absolute[i - 1];
            if (wait_min < 0) wait_min = 0;
        }

        if (i == 0) {  // 第一段不需要显示“上一站等待”
            _stprintf_s(
                line,
                512,
                _T("%d. %s → %s | %s | 班次：%s | 出发：%s | 到达：%s | 费用：%.2f元\n"),
                (int)i + 1,
                G.vertices[u_idx].name,
                G.vertices[v_idx].name,
                res.segment_types[i] == TYPE_FLIGHT ? _T("飞机") : _T("火车"),
                res.full_schs[i]->no,
                dep_time_str,
                arr_time_str,
                res.full_schs[i]->cost
            );
        }
        else {  // 后面各段会显示换乘等待时长
            _stprintf_s(
                line,
                512,
                _T("%d. %s → %s | %s | 班次：%s | 出发：%s | 到达：%s | 费用：%.2f元 | 上一站等待：%d小时%d分钟\n"),
                (int)i + 1,
                G.vertices[u_idx].name,
                G.vertices[v_idx].name,
                res.segment_types[i] == TYPE_FLIGHT ? _T("飞机") : _T("火车"),
                res.full_schs[i]->no,
                dep_time_str,
                arr_time_str,
                res.full_schs[i]->cost,
                wait_min / 60,
                wait_min % 60
            );
        }

        detail += line;  // 把这一段的文字加入详细内容
    }

    HistoryRecord rec;  // 创建一条新的历史记录对象
    rec.title = title_buf;
    rec.detail = detail;

    g_history.insert(g_history.begin(), rec);  // 把新记录放在最前面，显示为“最新”

    if ((int)g_history.size() > MAX_HISTORY) {  // 超过上限就删掉最旧的一条
        g_history.pop_back();
    }
}

// 参与人员：董 李
// （李：编号查看详情交互，清空全部记录功能）
void ShowHistoryWindow() {  // 打开历史记录窗口，显示过去查询过的路线
    if (g_history.empty()) {  // 如果没有记录，就提示用户
        MessageBox(GetHWnd(), _T("暂无历史查询记录。"), _T("历史记录"), MB_OK | MB_ICONINFORMATION);
        return;
    }

    TString text;  // 用来显示一份历史记录列表
    TCHAR line[512];

    text += _T("最近查询记录：\n\n");

    for (size_t i = 0; i < g_history.size(); i++) {  // 把每条历史记录的标题列出来
        _stprintf_s(
            line,
            512,
            _T("%d. %s\n"),
            (int)i + 1,
            g_history[i].title.c_str()
        );
        text += line;
    }

    text += _T("\n请输入记录编号查看完整详情。");
    text += _T("\n输入 0 可以清空全部历史记录。");

    TCHAR input[20] = { 0 };  // 用户输入的编号

    if (!InputBox(
        input,
        20,
        text.c_str(),
        _T("历史记录"),
        _T("1")
    )) {
        return;  // 如果用户取消输入，就直接退出
    }

    int choice = _ttoi(input);  // 把输入转换为整数

    if (choice == 0) {  // 用户想清空历史记录
        int ret = MessageBox(
            GetHWnd(),
            _T("确定要清空全部历史记录吗？"),
            _T("清空历史"),
            MB_YESNO | MB_ICONWARNING
        );

        if (ret == IDYES) {  // 如果确认，就清空容器
            g_history.clear();  // 清空历史记录
            MessageBox(GetHWnd(), _T("历史记录已清空。"), _T("提示"), MB_OK | MB_ICONINFORMATION);  // 提示用户已经清空
        }
        return;
    }

    if (choice < 1 || choice > (int)g_history.size()) {  // 如果编号越界，就报错
        MessageBox(GetHWnd(), _T("输入编号无效。"), _T("错误"), MB_OK | MB_ICONERROR);  // 提示用户输入编号无效
        return;
    }

    int idx = choice - 1;  // 转成数组下标

    TString detail_text;  // 详细内容窗口的文本
    detail_text += _T("【历史记录详情】\n\n");
    detail_text += g_history[idx].detail;

    MessageBox(
        GetHWnd(),
        detail_text.c_str(),
        g_history[idx].title.c_str(),
        MB_OK | MB_ICONINFORMATION
    );
}

// 参与人员：董 王
// === 带途经点的完整路线求解 ===
// 功能：在起点→终点之间插入若干途经点，找出访问所有途经点的最优路线
// 算法：全排列枚举（next_permutation），对途经点的每种排列顺序分别计算
//      每种排列被拆分成多段单段路径（start→via1, via1→via2, ..., viaN→end）
// 复杂度：n个途经点 → n!种排列 → 每种排列调用(n+1)次SolveSingleLeg
// ⚠️ 途经点太多会爆炸！建议限制 ≤3 个（3!=6, 4!=24, 5!=120, 8!=40320）
GlobalResult SolveWithVias(int start, int end, int start_time, int decision, int vehicle, const vector<int>& vias) {  // 先枚举途经点的访问顺序，再把每段都交给单段算法求解
    GlobalResult best_res;  // 保存当前最优路线结果
    best_res.total_duration = INF;  // 默认先设为不可达
    best_res.total_cost = INF;

    vector<int> perm = vias;  // 复制一份途经点，准备做全排列
    sort(perm.begin(), perm.end());  // 先按顺序排序，保证枚举从小到大

    do {  // 每种途经点顺序都尝试一次
        vector<int> sequence;  // 这是当前排列下的访问顺序，包含起点和终点
        sequence.push_back(start);  // 先把起点放进去
        for (size_t i = 0; i < perm.size(); i++) {
            sequence.push_back(perm[i]);  // 再把途经点依次加入
        }
        sequence.push_back(end);  // 最后添加终点

        int current_min = start_time;  // 当前已经走到的时间点
        vector<int> combined_path;  // 合并后的城市路径
        vector<Schedule*> combined_sch;  // 合并后的班次列表
        vector<int> dep_abs;  // 每段实际出发时间
        vector<int> arr_abs;  // 每段实际到达时间
        vector<int> combined_types;    // 每段类型
        bool possible = true;  // 当前顺序是否能走通

        for (size_t i = 0; i < sequence.size() - 1; i++) {  // 按顺序把每一段单独求解
            int from_node = sequence[i];
            int to_node = sequence[i + 1];
            bool is_transfer = (i > 0);  // 除了第一段外，其余都算作有换乘

            vector<int> sub_path;  // 这一小段的路径
            vector<Schedule*> sub_sch;  // 这一小段的班次
            vector<int> sub_types;  // 这一小段的交通类型
            if (!SolveSingleLeg(from_node, to_node, current_min, is_transfer, decision, vehicle, sub_path, sub_sch, sub_types)) {
                possible = false;  // 某一段算不出来，就放弃这个顺序
                break;
            }

            int u_arrival = current_min;  // 这一段的起点时间
            for (size_t k = 0; k < sub_sch.size(); k++) {  // 逐段计算实际出发到达时间
                // 混合模式按每段实际类型计算等待时间
                int min_wait = (vehicle == TYPE_MIXED)
                    ? ((sub_types[k] == TYPE_FLIGHT) ? 120 : 60)
                    : ((vehicle == TYPE_FLIGHT) ? 120 : 60);
                int buffer = (k == 0 && !is_transfer) ? 0 : min_wait;  // 第一次出发通常不用等待，后面换乘要留时间
                int earliest_dep = u_arrival + buffer;
                int day_offset = 0;
                if (sub_sch[k]->dep_time < earliest_dep) {  // 如果班次已经错过，就推到下一天
                    day_offset = ((earliest_dep - sub_sch[k]->dep_time - 1) / 1440 + 1) * 1440;
                }
                int actual_dep = sub_sch[k]->dep_time + day_offset;
                int actual_arr = sub_sch[k]->arr_time + day_offset;

                dep_abs.push_back(actual_dep);  // 保存每段真实出发时间
                arr_abs.push_back(actual_arr);  // 保存每段真实到达时间
                u_arrival = actual_arr;  // 更新当前时间点
            }

            if (combined_path.empty()) {  // 如果还是第一段，就直接把结果接过来
                combined_path = sub_path;
            }
            else {  // 从第二段开始，只把后面新增的城市接进去
                for (size_t k = 1; k < sub_path.size(); k++) combined_path.push_back(sub_path[k]);
            }
            for (size_t k = 0; k < sub_sch.size(); k++) {  // 把每段班次和类型也合并进去
                combined_sch.push_back(sub_sch[k]);
                combined_types.push_back(sub_types[k]);
            }

            current_min = u_arrival;  // 更新当前最新到达时间
        }

        if (possible) {  // 如果当前顺序全都能走通，就拿它和当前最优结果比较
            int duration = current_min - start_time;
            double cost = 0;
            for (auto* s : combined_sch) cost += s->cost;  // 把所有段的票价加起来

            bool is_better = false;
            if (best_res.total_duration == INF) {
                is_better = true;  // 还没有任何可行方案时，先选第一个
            }
            else if (decision == 1) { 
                if (duration < best_res.total_duration) is_better = true;  // 时间优先时，选更快的
            }
            else { 
                if (cost < best_res.total_cost) is_better = true;  // 费用优先时，选更便宜的
            }

            if (is_better) {  // 如果更好，就更新当前最优结果
                best_res.full_path = combined_path;
                best_res.full_schs = combined_sch;
                best_res.dep_times_absolute = dep_abs;
                best_res.arr_times_absolute = arr_abs;
                best_res.segment_types = combined_types;
                best_res.total_duration = duration;
                best_res.total_cost = cost;
            }
        }

    } while (next_permutation(perm.begin(), perm.end()));  // 继续枚举下一个途经点排列

    return best_res;  // 返回所有排列里最优的一种
}

// 参与人员：董 陈
// ----------------- 交互式数据编辑（含跨天修正）-----------------
void InteractiveEditNetwork() {  // 这是一个引导用户手动录入交通数据的函数
    HWND hwnd = GetHWnd();  // 获取当前窗口句柄，方便弹出提示框
    int msg_choice = MessageBox(hwnd,  // 先问用户是否要进入图形引导录入流程
        _T("即将开启图形引导录入。系统会自动检测城市是否存在，若不存在将引导您设定该城市在地图上的显示坐标及三字代码。是否继续？"),  // 提示内容
        _T("智能网络数据管理器"), MB_YESNO | MB_ICONINFORMATION);  // 提示框标题和按钮类型
        
    if (msg_choice != IDYES) return;  // 如果用户不同意，就直接退出

    TCHAR src_name[30] = {0}, dest_name[30] = {0}, no[20] = {0};  // 起点、终点、班次号的输入缓冲区
    TCHAR dep_str[10] = {0}, arr_str[10] = {0}, vehicle_str[10] = {0};  // 出发时间、到达时间、交通工具输入缓冲区
    TCHAR dist_str[10] = {0}, cost_str[10] = {0};  // 里程和票价输入缓冲区
    TCHAR x_str[10] = {0}, y_str[10] = {0}, code_str[10] = {0};  // 坐标和城市代码输入缓冲区

    // 1. 输入起点城市
    if (!InputBox(src_name, 30, _T("请输入起点城市名称（如：成都）："), _T("添加联动关系 - [1/9] 起点名称"))) return;  // 读取起点城市名
    int u = LocateVex(src_name);  // 检查起点城市是否已经存在
    if (u == -1) {  // 如果不存在，就引导用户创建它
        TCHAR hint[100];  // 用来提示用户输入的文本缓冲区
        _stprintf_s(hint, 100, _T("检测到城市 [%s] 尚不存在。请输入其三字英文代码/简称（如：CTU）："), src_name);  // 提示输入城市代码
        if (!InputBox(code_str, 10, hint, _T("自动创建起点节点 - [1/3] 三字码"))) return;  // 读取代码
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 X 像素坐标\n(当前大地图有效范围：0 到 %d)："), src_name, MAP_AREA_MAX-20);  // 提示输入 X 坐标
        if (!InputBox(x_str, 10, hint, _T("自动创建起点节点 - [2/3] X坐标"), _T("300"))) return;  // 读取 X
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 Y 像素坐标\n(当前大地图有效范围：0 到 600)："), src_name);  // 提示输入 Y 坐标
        if (!InputBox(y_str, 10, hint, _T("自动创建起点节点 - [3/3] Y坐标"), _T("300"))) return;  // 读取 Y

        int nx = _ttoi(x_str);  // 把 X 字符串转成整数
        int ny = _ttoi(y_str);  // 把 Y 字符串转成整数
        u = AddVertex(src_name, code_str, nx, ny);  // 把新城市加入图中
        if (u == -1) { MessageBox(hwnd, _T("错误：网络图城市节点数量已达上限！"), _T("错误"), MB_OK | MB_ICONERROR); return; }  // 如果超出上限就报错退出
    }

    // 2. 输入终点城市
    if (!InputBox(dest_name, 30, _T("请输入终点城市名称（如：北京）："), _T("添加联动关系 - [2/9] 终点名称"))) return;  // 读取终点城市名
    int v = LocateVex(dest_name);  // 检查终点城市是否已经存在
    if (v == -1) {  // 如果不存在，就引导用户创建它
        TCHAR hint[100];  // 提示文本缓冲区
        _stprintf_s(hint, 100, _T("检测到城市 [%s] 尚不存在。请输入其三字英文代码/简称（如：BJS）："), dest_name);  // 提示输入城市代码
        if (!InputBox(code_str, 10, hint, _T("自动创建终点节点 - [1/3] 三字码"))) return;  // 读取代码
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 X 像素坐标\n(当前大地图有效范围：0 到 %d)："), dest_name, MAP_AREA_MAX-20);  // 提示输入 X 坐标
        if (!InputBox(x_str, 10, hint, _T("自动创建终点节点 - [2/3] X坐标"), _T("400"))) return;  // 读取 X
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 Y 像素坐标\n(当前大地图有效范围：0 到 600)："), dest_name);  // 提示输入 Y 坐标
        if (!InputBox(y_str, 10, hint, _T("自动创建终点节点 - [3/3] Y坐标"), _T("250"))) return;  // 读取 Y

        int nx = _ttoi(x_str);  // 把 X 字符串转成整数
        int ny = _ttoi(y_str);  // 把 Y 字符串转成整数
        v = AddVertex(dest_name, code_str, nx, ny);  // 把新城市加入图中
        if (v == -1) { MessageBox(hwnd, _T("错误：网络图城市节点数量已达上限！"), _T("错误"), MB_OK | MB_ICONERROR); return; }  // 如果超出上限就报错退出
    }

    if (u == v) {  // 如果起点和终点是同一个城市，就不允许录入
        MessageBox(hwnd, _T("起点和终点不能为同一城市！"), _T("录入失败"), MB_OK | MB_ICONWARNING);  // 弹出提醒
        return;  // 直接退出
    }

    // 3. 交通工具选择
    if (!InputBox(vehicle_str, 10, _T("请输入交通工具类型：\n输入 1 代表 [飞机]\n输入 2 代表 [火车]"), _T("添加联动关系 - [3/9] 载具类型"), _T("1"))) return;  // 读取交通工具类型
    int vehicle = _ttoi(vehicle_str);  // 把输入字符串转成整数
    if (vehicle != 1 && vehicle != 2) {  // 如果输入不是 1 或 2，就报错
        MessageBox(hwnd, _T("无效的工具类型！必须输入 1(飞机) 或 2(火车)。"), _T("录入失败"), MB_OK | MB_ICONWARNING);  // 提示错误
        return;  // 直接退出
    }

    // 4. 里程输入
    if (!InputBox(dist_str, 10, _T("请输入两城市间的里程距离（公里）："), _T("添加联动关系 - [4/9] 里程"), _T("1000"))) return;  // 读取里程
    int distance = _ttoi(dist_str);  // 把字符串转成整数

    // 5. 班次/航班号
    if (!InputBox(no, 20, _T("请输入航班号或列车车次（如：3U8881 / G102）："), _T("添加联动关系 - [5/9] 班次编号"))) return;  // 读取班次号

    // 6. 出发时间
    if (!InputBox(dep_str, 10, _T("请输入预计出发时间\n格式为 hh:mm（如：08:30）："), _T("添加联动关系 - [6/9] 出发时间"))) return;  // 读取出发时间

    // 7. 到达时间
    if (!InputBox(arr_str, 10, _T("请输入预计到达时间\n格式为 hh:mm（如：11:45）："), _T("添加联动关系 - [7/9] 到达时间"))) return;  // 读取到达时间

    // 8. 价格票价
    if (!InputBox(cost_str, 10, _T("请输入单人标准票价（元）："), _T("添加联动关系 - [8/9] 票价旅资"))) return;  // 读取票价
    double cost = _tcstod(cost_str, NULL);  // 把票价字符串转成浮点数

    int dep_min = TimeToMin(dep_str);  // 把出发时间字符串转成分钟数
    int arr_min = TimeToMin(arr_str);  // 把到达时间字符串转成分钟数
    if (arr_min < dep_min) {  // 如果到达时间比出发时间小，就说明跨天了
        arr_min += 1440;  // 把到达时间加上一整天，变成下一天的时间
    }

    ArcNode* arc = AddArc(u, v, distance, vehicle);  // 在图中创建一条新的线路边
    AddSchedule(arc, no, dep_min, arr_min, cost);  // 给这条线路挂上对应班次

    TCHAR success_msg[200];  // 用来存放成功提示信息
    _stprintf_s(success_msg, 200, _T("【成功】[%s] 经由 [%s] 至 [%s] 的交通运输大通道以及车次 [%s] 已实时成功注入图形网络中！"), src_name, vehicle == 1 ? _T("航空") : _T("铁路"), dest_name, no);  // 生成成功提示文本
    MessageBox(hwnd, success_msg, _T("数据添加成功"), MB_OK | MB_ICONINFORMATION);  // 弹出成功提示
}

// 参与人员：董 王
// ====== UI 交互判定工具函数 ======
// 用勾股定理判断鼠标坐标(mx,my)是否在城市圆圈内
// 为什么不直接用 EasyX 的点击检测？因为要精确控制半径，且地图区和侧边栏区分开
bool IsInCircle(int mx, int my, int cx, int cy, int r) {  // 判断鼠标点是否落在某个圆形区域内
    return (mx - cx) * (mx - cx) + (my - cy) * (my - cy) <= r * r;  // 用平方距离和半径平方做比较，判断是否在圆内
}

// 参与人员：董 王
// 判断鼠标坐标是否在矩形按钮区域内（用于侧边栏按钮点击检测）
bool IsInRect(int mx, int my, int rx1, int ry1, int rx2, int ry2) {  // 判断鼠标点是否落在矩形按钮区域内
    return mx >= rx1 && mx <= rx2 && my >= ry1 && my <= ry2;  // 同时检查 X 和 Y 是否都在矩形边界内
}

// 参与人员：董 王
// === 自绘按钮组件 ===
// 为什么不用Windows原生按钮？EasyX是像素级绘图库，不支持Windows控件
// 所以按钮全是手工画的：先画圆角矩形背景，再居中写文字
// active=true → 深色激活态（表示当前选中），active=false → 浅色普通态
void DrawButton(const TCHAR* label, int x1, int y1, int x2, int y2, bool active) {  // 画一个自定义按钮
    if (active) {  // 如果按钮处于激活状态，就用深色样式
        setfillcolor(RGB(30, 41, 59));  // 设置按钮背景颜色为深蓝灰
        setlinecolor(RGB(34, 197, 94));  // 设置按钮边框颜色为绿色
    }
    else {  // 如果按钮没有被选中，就用浅色样式
        setfillcolor(RGB(241, 245, 249));  // 设置按钮背景颜色为浅灰
        setlinecolor(RGB(203, 213, 225));  // 设置按钮边框颜色为灰蓝
    }
    fillroundrect(x1, y1, x2, y2, 8, 8);  // 画出圆角矩形按钮背景
    settextcolor(active ? WHITE : RGB(71, 85, 105));  // 根据状态设置文字颜色
    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置按钮文字字体样式
    setbkmode(TRANSPARENT);  // 让文字背景透明，不遮盖按钮底色
    int w = textwidth(label);  // 计算文字宽度，方便居中显示
    int h = textheight(label);  // 计算文字高度，方便居中显示
    outtextxy(x1 + (x2 - x1 - w) / 2, y1 + (y2 - y1 - h) / 2, label);  // 把文字画在按钮中间
}

// 参与人员：董 王
// === 自绘方向箭头 ===
// 功能：在地图上画一条带箭头的线段，表示最优路径的行进方向
// 原理：先画主线，再用 atan2 算出方向角，在终点处画两条短斜线形成箭头
void DrawArrow(int x1, int y1, int x2, int y2, COLORREF color) {  // 画一条带箭头的线路方向
    setlinecolor(color);  // 设置箭头颜色
    setlinestyle(PS_SOLID, 3);  // 设置线条为实线且较粗
    line(x1, y1, x2, y2);  // 先画出主线

    double angle = atan2(y2 - y1, x2 - x1);  // 计算线段方向角
    int r = 12;  // 箭头长度
    int ax1 = x2 - (int)(r * cos(angle - 0.4));  // 计算箭头第一条线的终点 X
    int ay1 = y2 - (int)(r * sin(angle - 0.4));  // 计算箭头第一条线的终点 Y
    int ax2 = x2 - (int)(r * cos(angle + 0.4));  // 计算箭头第二条线的终点 X
    int ay2 = y2 - (int)(r * sin(angle + 0.4));  // 计算箭头第二条线的终点 Y
    line(x2, y2, ax1, ay1);  // 画出箭头的一条边
    line(x2, y2, ax2, ay2);  // 画出箭头的另一条边
}

// 参与人员：董
// ====== 右键上下文菜单系统 ======
// 设计思路：不用 Windows 原生菜单（太丑且与EasyX不兼容），纯手工像素绘制
// 菜单组成：阴影层 + 白色背景 + 菜单项 + 悬停高亮
// 两个图层：空白处右键(添加城市/管理航线) vs 节点右键(删除/查看详情)
#define CTX_MENU_WIDTH   200    // 菜单宽度
#define CTX_MENU_ITEM_H  34     // 每个菜单项的高度
#define CTX_MENU_PADDING 6      // 菜单内边距

// 参与人员：董
void DrawContextMenu() {  // 绘制右键弹出的上下文菜单
    if (!g_ctx_menu_visible) return;  // 如果菜单没有显示，就直接返回

    int menu_w = CTX_MENU_WIDTH;  // 计算菜单宽度
    int menu_h = CTX_MENU_PADDING * 2 + g_ctx_menu_count * CTX_MENU_ITEM_H;  // 计算菜单高度
    int mx = g_ctx_menu_x, my = g_ctx_menu_y;  // 获取菜单左上角坐标

    // 防止菜单超出屏幕
    if (mx + menu_w > SCREEN_WIDTH)  mx = SCREEN_WIDTH - menu_w - 5;  // 如果菜单太靠右，就往左挪
    if (my + menu_h > SCREEN_HEIGHT) my = SCREEN_HEIGHT - menu_h - 5;  // 如果菜单太靠下，就往上挪
    if (mx < 5) mx = 5;  // 防止菜单超出左边界
    if (my < 5) my = 5;  // 防止菜单超出上边界

    // 阴影
    setfillcolor(RGB(0, 0, 0));  // 设置阴影颜色为黑色
    setlinecolor(RGB(0, 0, 0));  // 设置阴影边框颜色为黑色
    fillroundrect(mx + 3, my + 3, mx + menu_w + 3, my + menu_h + 3, 10, 10);  // 先画出阴影层
    // 用半透明效果替代：先画深色再画白色覆盖
    // 白色背景
    setfillcolor(RGB(255, 255, 255));  // 设置菜单背景为白色
    setlinecolor(RGB(200, 200, 210));  // 设置菜单边框颜色为浅灰
    fillroundrect(mx, my, mx + menu_w, my + menu_h, 10, 10);  // 画出菜单主体背景

    // 获取当前鼠标位置用于悬停检测
    POINT cur_pt;  // 定义一个点变量保存鼠标位置
    GetCursorPos(&cur_pt);  // 获取鼠标在屏幕上的坐标
    ScreenToClient(GetHWnd(), &cur_pt);  // 把坐标换算成窗口相对坐标

    // 绘制菜单项
    for (int i = 0; i < g_ctx_menu_count; i++) {  // 遍历每一个菜单项
        int item_y = my + CTX_MENU_PADDING + i * CTX_MENU_ITEM_H;  // 计算当前菜单项的 Y 位置
        bool hover = (cur_pt.x >= mx && cur_pt.x <= mx + menu_w &&
                      cur_pt.y >= item_y && cur_pt.y < item_y + CTX_MENU_ITEM_H);  // 判断鼠标是否悬停在当前项上

        if (hover) {  // 如果鼠标悬停在当前项上，就高亮显示
            setfillcolor(RGB(230, 240, 255));  // 设置高亮背景色
            solidroundrect(mx + 4, item_y, mx + menu_w - 4, item_y + CTX_MENU_ITEM_H, 6, 6);  // 画出高亮块
            settextcolor(RGB(30, 64, 175));  // 设置高亮时的文字颜色
        } else {  // 如果没有悬停，就使用普通样式
            settextcolor(RGB(30, 30, 40));  // 设置普通文字颜色
        }

        setbkmode(TRANSPARENT);  // 让文字背景透明
        settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置菜单项文字样式

        const TCHAR* label = NULL;  // 先准备一个空的菜单项文字指针
        if (g_ctx_menu_target == -1) {  // 如果右键点的是地图空白处
            // 空白处右键菜单项
            switch (i) {  // 根据菜单项序号决定显示什么内容
                case 0: label = _T(" 在此添加城市节点"); break;  // 第一个选项是添加节点
                case 1: label = _T("全航线管理"); break;  // 第二个选项是管理航线
            }
        } else {  // 如果右键点的是某个城市节点
            // 节点右键菜单项
            switch (i) {  // 根据菜单项序号决定显示什么内容
                case 0: label = _T("删除此节点"); break;  // 第一个选项是删除节点
                case 1: label = _T("查看节点详情"); break;  // 第二个选项是查看节点详情
            }
        }
        if (label) {  // 如果当前项有文字，就把它画出来
            outtextxy(mx + 10, item_y + (CTX_MENU_ITEM_H - 20) / 2, label);  // 在菜单项中间输出文字
        }
    }
}

// 参与人员：董
// ====== 全航线管理面板（独立子系统）======
// 这个面板是一个"程序中的程序"——有自己的渲染循环、事件处理和缩放逻辑
// RouteRow：表格的一行数据，从图的邻接表中扁平化提取出来方便展示
struct RouteRow {
    int from_idx, to_idx;   // 起点/终点城市下标
    int type;               // TYPE_FLIGHT / TYPE_TRAIN
    int distance;           // 里程
    TCHAR no[20];           // 班次号
    int dep_time, arr_time; // 出发/到达时间（分钟）
    double cost;            // 票价
};

// 参与人员：董
// 从图的邻接表中提取所有航线段，扁平化为表格行
vector<RouteRow> CollectAllRoutes() {  // 扫描图的邻接表，把所有航线段提取出来，返回一个 RouteRow 的列表
    vector<RouteRow> rows;  // 用来保存所有航线段的表格行
    for (int i = 0; i < G.vexnum; i++) {    // 遍历每个城市节点
        for (ArcNode* arc = G.vertices[i].firstarc; arc; arc = arc->nextarc) {  // 遍历每个城市的邻接边
            for (Schedule* sch = arc->sch_list; sch; sch = sch->next) {  // 遍历每条边的班次列表
                RouteRow r;  // 创建一个新的表格行
                r.from_idx = i;   // 起点城市下标
                r.to_idx = arc->adjvex;  // 终点城市下标
                r.type = arc->type;  // 交通类型（飞机/火车）
                r.distance = arc->distance;   // 里程
                _tcscpy_s(r.no, 20, sch->no);  // 班次号
                r.dep_time = sch->dep_time;   // 出发时间（分钟）
                r.arr_time = sch->arr_time;   // 到达时间（分钟）
                r.cost = sch->cost;  // 票价
                rows.push_back(r);   // 把这一行加入到结果列表中
            }
        }
    }
    return rows;  // 返回所有航线段的表格行列表
}

// 参与人员：董
// 全航线管理面板主函数——一个独立的"子程序"
// 功能：9列表格展示所有航线，支持筛选(全部/航空/铁路)、滚轮翻页、单击选中、双击编辑、删除
// 交互：ESC/返回按钮退出，滚轮上下翻页，双击弹窗编辑
// 架构：自己的 while(running) 循环 + BeginBatchDraw/FlushBatchDraw 渲染
void RouteManagementPanel() {  // 这是一个独立的“全航线管理子界面”
    vector<RouteRow> all = CollectAllRoutes();  // 先把当前图中的所有航线数据取出来

    int filter = 0;        // 过滤条件：0=全部, 1=航空, 2=铁路
    int scroll = 0;        // 当前列表滚动到第几行
    int selected = -1;     // 当前被选中的航线编号
    const int ROW_H = 44;  // 每一行的高度
    const int HEADER_H = 56;  // 表头区域高度
    const int BTN_H = 42;  // 底部按钮栏高度

    // 列宽
    const int COL_X[] = {10, 55, 210, 370, 460, 580, 700, 820, 940};  // 每列的起始 X 坐标
    const TCHAR* COL_NAMES[] = {_T("#"), _T("类型"), _T("起点"), _T("终点"), _T("里程"), _T("班次号"), _T("出发"), _T("到达"), _T("票价")};  // 每列的标题名称

    bool running = true;         // 面板是否继续运行
    ExMessage m;                 // 用于接收鼠标/键盘事件的结构体
    DWORD last_resize_time = 0;  // 上一次窗口大小变化的时间戳，用于防抖处理
    DWORD last_click_tick = 0;   // 上一次鼠标点击的时间戳，用于双击检测
    int   last_click_row = -1;   // 上一次鼠标点击的行号，用于双击检测

    BeginBatchDraw();  // 开始批量绘制，避免界面闪烁

    while (running) {  // 只要管理面板没有关闭，就持续刷新界面
        int VISIBLE = (SCREEN_HEIGHT - HEADER_H - BTN_H - 20) / ROW_H;  // 计算当前窗口一次最多能显示几行数据
        if (VISIBLE < 1) VISIBLE = 1;  // 至少保证显示一行，防止除以零或显示为空

        // 先根据当前过滤条件，把所有航线筛出来
        vector<int> visible_idx;  // 保存当前条件下真正要显示的航线序号
        for (int i = 0; i < (int)all.size(); i++) {   // 遍历全部航线数据
            if (filter == 0 || all[i].type == filter) visible_idx.push_back(i);  // 如果是“全部”或者类型匹配，就加入显示列表
        }

        // 开始绘制界面内容，不再调用 BeginBatchDraw，因为外层已经启动了批量绘制
        setfillcolor(RGB(248, 250, 252));  // 设置整个面板的背景颜色
        solidrectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);   // 把整个面板背景填满

        // 绘制标题栏
        setfillcolor(RGB(30, 41, 59));  // 设置标题栏背景颜色为深色
        solidrectangle(0, 0, SCREEN_WIDTH, HEADER_H);  // 画出标题栏矩形区域
        settextcolor(WHITE);  // 设置标题文字颜色为白色
        settextstyle(24, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置标题文字样式
        setbkmode(TRANSPARENT);  // 让文字背景透明，不遮挡底色
        outtextxy(15, 10, _T("全航线管理"));  // 在标题栏中输出标题文字

        // 绘制过滤按钮
        int btn_y = 8;  // 按钮的顶部 Y 坐标
        DrawButton(_T("全部"), SCREEN_WIDTH/2-140, btn_y, SCREEN_WIDTH/2-60, btn_y+34, filter == 0);  // 画出“全部”筛选按钮
        DrawButton(_T("[航空]"), SCREEN_WIDTH/2-50, btn_y, SCREEN_WIDTH/2+40, btn_y+34, filter == 1);  // 画出“航空”筛选按钮
        DrawButton(_T("[铁路]"), SCREEN_WIDTH/2+50, btn_y, SCREEN_WIDTH/2+140, btn_y+34, filter == 2);  // 画出“铁路”筛选按钮

        // 绘制表头区域
        setfillcolor(RGB(241, 245, 249));  // 设置表头背景色为浅灰
        solidrectangle(0, HEADER_H, SCREEN_WIDTH, HEADER_H + 32);  // 画出表头背景块
        settextcolor(RGB(71, 85, 105));  // 设置表头文字颜色为灰蓝
        settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置表头字体样式
        for (int c = 0; c < 9; c++)  // 遍历 9 列表头
            outtextxy(COL_X[c], HEADER_H + 5, COL_NAMES[c]);  // 输出每一列的名称

        setlinecolor(RGB(226, 232, 240));  // 设置分隔线颜色
        line(0, HEADER_H + 36, SCREEN_WIDTH, HEADER_H + 36);  // 画出表头下方的分隔线

        // 绘制数据行
        int row_y = HEADER_H + 40;  // 第一条数据行的起始 Y 坐标
        for (int i = scroll; i < min(scroll + VISIBLE, (int)visible_idx.size()); i++) {  // 只绘制当前窗口可见的行
            int idx = visible_idx[i];  // 取出当前行对应的航线索引
            RouteRow& r = all[idx];  // 取出当前航线记录
            int ry = row_y + (i - scroll) * ROW_H;  // 计算当前行的 Y 坐标
            bool sel = (idx == selected);  // 判断当前行是否被选中

            if (sel) {  // 如果当前行被选中，就用高亮背景
                setfillcolor(RGB(219, 234, 254));  // 设置选中行背景颜色
                solidrectangle(0, ry, SCREEN_WIDTH, ry + ROW_H);  // 画出高亮背景矩形
                settextcolor(RGB(30, 64, 175));  // 设置选中行文字颜色为深蓝
            } else if ((i - scroll) % 2 == 0) {  // 偶数行使用默认文字颜色
                settextcolor(RGB(30, 30, 40));  // 设置普通文字颜色
            } else {  // 奇数行使用浅色背景隔行显示
                setfillcolor(RGB(250, 250, 252));  // 设置隔行背景颜色
                solidrectangle(0, ry, SCREEN_WIDTH, ry + ROW_H);  // 画出隔行背景矩形
                settextcolor(RGB(30, 30, 40));  // 设置普通文字颜色
            }

            settextstyle(19, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置数据行文字样式
            setbkmode(TRANSPARENT);  // 让文字背景透明

            TCHAR buf[60];  // 用于格式化输出的临时字符串
            _stprintf_s(buf, 60, _T("%d"), idx + 1);              outtextxy(COL_X[0], ry + 8, buf);  // 输出序号
            outtextxy(COL_X[1], ry + 8, r.type == TYPE_FLIGHT ? _T("航空") : _T("铁路"));  // 输出类型名称
            outtextxy(COL_X[2], ry + 8, G.vertices[r.from_idx].name);  // 输出起点城市名
            outtextxy(COL_X[3], ry + 8, G.vertices[r.to_idx].name);  // 输出终点城市名
            _stprintf_s(buf, 60, _T("%d km"), r.distance);         outtextxy(COL_X[4], ry + 8, buf);  // 输出里程信息
            outtextxy(COL_X[5], ry + 8, r.no);  // 输出班次号
            TCHAR ta[10], tb[10];  // 分别保存出发和到达时间字符串
            MinToTimeStr(r.dep_time, ta, 10);  // 把分钟数转为出发时间字符串
            MinToTimeStr(r.arr_time, tb, 10);  // 把分钟数转为到达时间字符串
            _stprintf_s(buf, 60, _T("%s"), ta + (_tcslen(ta) > 4 ? _tcslen(ta) - 5 : 0));  // 简化时间显示，避免多余的日期部分
            outtextxy(COL_X[6], ry + 8, ta);  // 输出出发时间
            outtextxy(COL_X[7], ry + 8, tb);  // 输出到达时间
            _stprintf_s(buf, 60, _T("¥%.0f"), r.cost);             outtextxy(COL_X[8], ry + 8, buf);  // 输出票价
        }

        // 绘制底部栏
        int btm_y = SCREEN_HEIGHT - BTN_H - 5;  // 底部按钮栏的顶部 Y 坐标
        setlinecolor(RGB(226, 232, 240));  // 设置底部分隔线颜色
        line(0, btm_y - 5, SCREEN_WIDTH, btm_y - 5);  // 画出底部分隔线

        TCHAR info[80];  // 保存底部提示信息的字符串
        _stprintf_s(info, 80, _T("共 %d 条航线  |  滚轮翻页  |  点击选择"), (int)visible_idx.size());  // 构造提示文字
        settextcolor(RGB(148, 163, 184));  // 设置提示文字颜色为灰蓝
        settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置提示文字样式
        outtextxy(15, btm_y + 10, info);  // 输出底部提示信息

        DrawButton(_T("添加航线"), SCREEN_WIDTH - 340, btm_y, SCREEN_WIDTH - 220, btm_y + 34, false);  // 画出“添加航线”按钮
        DrawButton(_T("删除选中"), SCREEN_WIDTH - 210, btm_y, SCREEN_WIDTH - 90, btm_y + 34, selected != -1);  // 画出“删除选中”按钮
        DrawButton(_T("返回地图"), SCREEN_WIDTH - 80, btm_y, SCREEN_WIDTH - 10, btm_y + 34, false);  // 画出“返回地图”按钮

        FlushBatchDraw();  // 把当前这一帧内容一次性刷新到屏幕上

        // 处理用户输入：点击按钮、翻页、选中行、双击编辑等
        while (peekmessage(&m, EM_MOUSE | EM_KEY)) {  // 循环取出所有输入消息
            if (m.message == WM_LBUTTONDOWN) {  // 用户按下鼠标左键
                int mx = m.x, my = m.y;  // 记录点击位置

                // 过滤按钮区域判断
                if (my >= 8 && my <= 42) {  // 如果点击发生在顶部筛选按钮区域内
                    if (mx >= SCREEN_WIDTH/2-140 && mx <= SCREEN_WIDTH/2-60)  { filter = 0; selected = -1; scroll = 0; }  // 点击“全部”时重置筛选
                    if (mx >= SCREEN_WIDTH/2-50  && mx <= SCREEN_WIDTH/2+40)  { filter = 1; selected = -1; scroll = 0; }  // 点击“航空”时切换筛选
                    if (mx >= SCREEN_WIDTH/2+50  && mx <= SCREEN_WIDTH/2+140) { filter = 2; selected = -1; scroll = 0; }  // 点击“铁路”时切换筛选
                }

                // 底栏按钮区域判断
                if (my >= btm_y && my <= btm_y + 34) {  // 如果点击发生在底部按钮栏里
                    if (mx >= SCREEN_WIDTH - 340 && mx <= SCREEN_WIDTH - 220) {  // 判断是否点击了“添加航线”按钮
                        // 添加航线：调用编辑界面，然后刷新当前航线列表
                        InteractiveEditNetwork();  // 打开航线录入流程
                        all = CollectAllRoutes();  // 重新读取最新航线数据
                        selected = -1;  // 清空当前选中项
                    }
                    if (mx >= SCREEN_WIDTH - 210 && mx <= SCREEN_WIDTH - 90 && selected != -1) {  // 判断是否点击了“删除选中”按钮
                        // 删除选中航线：先弹出确认框，再从图中移除对应班次
                        RouteRow& r = all[selected];  // 取出当前选中的航线记录
                        TCHAR cfm[200];  // 保存确认提示文字
                        _stprintf_s(cfm, 200, _T("删除航线：%s → %s\n班次 %s (%s)？"),  // 构造确认提示内容
                            G.vertices[r.from_idx].name, G.vertices[r.to_idx].name,
                            r.no, r.type == TYPE_FLIGHT ? _T("航空") : _T("铁路"));
                        if (MessageBox(GetHWnd(), cfm, _T("确认"), MB_YESNO | MB_ICONWARNING) == IDYES) {  // 如果用户确认删除
                            // 从图中删除该班次
                            ArcNode* arc = G.vertices[r.from_idx].firstarc;  // 从起点城市的第一条边开始找
                            while (arc) {  // 遍历所有出边
                                if (arc->adjvex == r.to_idx && arc->type == r.type) {  // 找到对应的边
                                    Schedule** sp = &arc->sch_list;  // 指向班次链表头指针
                                    while (*sp) {  // 遍历班次链表
                                        if (_tcscmp((*sp)->no, r.no) == 0) {  // 找到要删除的班次
                                            Schedule* tmp = *sp;  // 保存当前班次节点
                                            *sp = (*sp)->next;  // 把链表头指向下一个节点
                                            free(tmp);  // 释放该班次节点内存
                                            break;  // 删除完就停止
                                        }
                                        sp = &(*sp)->next;  // 指向下一个班次节点
                                    }
                                    break;  // 找到边后也停止外层循环
                                }
                                arc = arc->nextarc;  // 继续找下一条边
                            }
                            all = CollectAllRoutes();  // 重新收集所有航线数据
                            selected = -1;  // 清空当前选择
                        }
                    }
                    if (mx >= SCREEN_WIDTH - 80 && mx <= SCREEN_WIDTH - 10) {  // 判断是否点击了“返回地图”按钮
                        running = false;  // 退出管理面板，回到主地图界面
                    }
                }

                // 点击数据行：单击选中，双击编辑
                int data_y = HEADER_H + 40;  // 数据区域的起始 Y 坐标
                if (my >= data_y && my < data_y + VISIBLE * ROW_H) {  // 如果点击发生在可见数据行区域内
                    int row = (my - data_y) / ROW_H + scroll;  // 计算用户点击的是第几行
                    if (row >= 0 && row < (int)visible_idx.size()) {  // 确保点击行在当前显示范围内
                        int idx = visible_idx[row];  // 获取实际对应的航线索引
                        DWORD now = GetTickCount();  // 获取当前时间，用于判断双击

                        // 双击检测：同一行 500ms 内连点两次
                        if (idx == last_click_row && (now - last_click_tick) < 500) {  // 如果是双击同一行
                            // 双击 → 编辑当前航线信息
                            RouteRow& r = all[idx];  // 取出当前航线记录
                            Schedule* target_sch = NULL;  // 用于记录要编辑的班次节点
                            ArcNode* target_arc = NULL;  // 用于记录对应的边节点
                            for (ArcNode* arc = G.vertices[r.from_idx].firstarc; arc; arc = arc->nextarc) {  // 遍历起点的出边
                                if (arc->adjvex == r.to_idx && arc->type == r.type) {  // 找到对应的边
                                    for (Schedule* sch = arc->sch_list; sch; sch = sch->next) {  // 遍历该边上的所有班次
                                        if (_tcscmp(sch->no, r.no) == 0) {  // 找到要编辑的班次
                                            target_sch = sch; target_arc = arc; break;  // 保存目标班次和边
                                        }
                                    }
                                    if (target_sch) break;  // 找到后停止外层循环
                                }
                            }
                            if (target_sch) {  // 如果成功找到目标班次
                                TCHAR buf[30], title[100];  // 缓冲区用于输入框和标题
                                _stprintf_s(title, 100, _T("编辑 %s → %s (%s)"),  // 创建编辑窗口标题
                                    G.vertices[r.from_idx].name, G.vertices[r.to_idx].name, r.no);
                                _stprintf_s(buf, 30, _T("%d"), r.distance);  // 把里程转成字符串
                                if (InputBox(buf, 30, _T("里程 (公里)："), title, buf)) {  // 让用户输入新的里程
                                    int d = _ttoi(buf); if (d > 0) { r.distance = d; target_arc->distance = d; }  // 更新显示和图中数据
                                }
                                if (InputBox(r.no, 20, _T("班次号："), title, r.no))  // 让用户输入新的班次号
                                    _tcscpy_s(target_sch->no, 20, r.no);  // 更新班次号
                                TCHAR ds[10], as[10];  // 保存出发和到达时间字符串
                                _stprintf_s(ds, 10, _T("%02d:%02d"), r.dep_time / 60, r.dep_time % 60);  // 格式化出发时间
                                if (InputBox(ds, 10, _T("出发时间："), title, ds)) {  // 让用户输入新的出发时间
                                    int t = TimeToMin(ds); r.dep_time = t; target_sch->dep_time = t;  // 更新显示和班次数据
                                }
                                _stprintf_s(as, 10, _T("%02d:%02d"), r.arr_time / 60, r.arr_time % 60);  // 格式化到达时间
                                if (InputBox(as, 10, _T("到达时间："), title, as)) {  // 让用户输入新的到达时间
                                    int t = TimeToMin(as); r.arr_time = t; target_sch->arr_time = t;  // 更新显示和班次数据
                                }
                                _stprintf_s(buf, 30, _T("%.0f"), r.cost);  // 把票价转成字符串
                                if (InputBox(buf, 30, _T("票价 (元)："), title, buf)) {  // 让用户输入新的票价
                                    double c = _tcstod(buf, NULL); if (c >= 0) { r.cost = c; target_sch->cost = c; }  // 更新显示和班次数据
                                }
                            }
                            last_click_row = -1;  // 双击处理完成后清空记录
                        } else {  // 不是双击，而是单击
                            // 单击 → 选中当前航线
                            selected = idx;  // 记录当前选中航线
                            last_click_tick = now;  // 记录这次点击时间
                            last_click_row = idx;  // 记录这次点击的航线
                        }
                    }
                }
            }

            if (m.message == WM_MOUSEWHEEL) {  // 如果滚轮滚动
                int delta = m.wheel / 120;  // 根据滚轮方向计算滚动值
                scroll -= delta;  // 让列表向上或向下滚动
                if (scroll < 0) scroll = 0;  // 防止滚动到最顶部之前继续往上
                int max_scroll = max(0, (int)visible_idx.size() - VISIBLE);  // 计算最大可滚动距离
                if (scroll > max_scroll) scroll = max_scroll;  // 防止滚动到最底部之后继续往下
            }

            if (m.message == WM_KEYDOWN && m.vkcode == VK_ESCAPE) {  // 如果用户按下了 Esc 键
                running = false;  // 退出当前管理面板
            }
        }

        // ---- 窗口缩放检测（与管理面板同步） ----
        {
            RECT cur_rect;  // 保存当前窗口客户区尺寸的结构体
            if (GetClientRect(GetHWnd(), &cur_rect)) {  // 成功获取当前窗口尺寸
                int cur_w = cur_rect.right - cur_rect.left;  // 当前窗口宽度
                int cur_h = cur_rect.bottom - cur_rect.top;  // 当前窗口高度
                if ((cur_w != SCREEN_WIDTH || cur_h != SCREEN_HEIGHT) && cur_w >= 600 && cur_h >= 400) {  // 只有尺寸变化且足够大时才重建界面
                    if (GetKeyState(VK_LBUTTON) & 0x8000) { Sleep(16); continue; }  // 如果用户正拖拽窗口边缘，就暂时跳过
                    DWORD now_tick = GetTickCount();  // 获取当前时间，用于防抖
                    if (now_tick - last_resize_time > 300) {  // 间隔大于 300ms 才处理一次，避免频繁重建
                        last_resize_time = now_tick;  // 更新防抖时间
                        
                        HWND old_hwnd = GetHWnd();  // 保存旧窗口句柄
                        bool is_maximized = IsZoomed(old_hwnd);  // 判断窗口是否处于最大化状态
                        RECT old_win_rect;  // 保存旧窗口位置
                        GetWindowRect(old_hwnd, &old_win_rect);

                        EndBatchDraw();  // 结束当前批次绘制
                        closegraph();  // 关闭当前图形窗口
                        
                        // 直接使用客户区尺寸
                        initgraph(cur_w, cur_h);  // 用新的客户区尺寸重新创建图形窗口
                        
                        HWND hwnd2 = GetHWnd();  // 获取新窗口句柄
                        LONG style2 = GetWindowLong(hwnd2, GWL_STYLE);  // 读取新窗口样式
                        SetWindowLong(hwnd2, GWL_STYLE, style2 | WS_SIZEBOX | WS_MAXIMIZEBOX);  // 允许重新调整大小和最大化
                        
                        if (is_maximized) {  // 如果原来是最大化状态，就继续保持最大化
                            ShowWindow(hwnd2, SW_MAXIMIZE);
                        } else {  // 否则恢复到原来的窗口位置
                            SetWindowPos(hwnd2, NULL, old_win_rect.left, old_win_rect.top, 0, 0, 
                                SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
                        }

                        RECT sync_rect;  // 保存新窗口客户区尺寸
                        GetClientRect(hwnd2, &sync_rect);  // 获取新窗口的客户区尺寸
                        SCREEN_WIDTH = sync_rect.right - sync_rect.left;  // 更新全局宽度
                        SCREEN_HEIGHT = sync_rect.bottom - sync_rect.top;  // 更新全局高度
                        MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;  // 更新地图区域最大宽度
                        if (MAP_AREA_MAX < 200) MAP_AREA_MAX = 200;  // 防止地图区太窄
                        
                        setbkmode(TRANSPARENT);  // 设置文字透明
                        BeginBatchDraw();  // 重新开始批次绘制
                        cleardevice();  // 清空当前设备内容
                        
                        // 更新时间戳防抖
                        last_resize_time = GetTickCount();  // 重新记录时间，避免连续触发
                        continue;  // 直接跳到下一轮循环，重新绘制界面
                    }
                }
            }
        }
        // --------------------------------------------------------

        Sleep(16);  // 让程序每帧等待一小段时间，保持大约 60FPS 的刷新节奏
    }

    EndBatchDraw();  // 面板退出，结束批次
}

// 参与人员：董 王 李
// ====== 主渲染函数：整个程序界面的"总导演" ======
// 职责：每一帧调用一次，绘制整个窗口的所有内容
// 绘制顺序（由底到顶，后面的会覆盖前面的）：
//   1.清空背景 → 2.地图网格 → 3.侧边栏背景 → 4.所有交通线路（蓝虚线=飞机/红实线=火车）
//   → 5.最优路径箭头（深蓝/深红） → 6.城市节点圆圈 → 7.侧边栏按钮和文字
//   → 8.当前规划状态区 → 9.查询结果区 → 10.右键菜单（最顶层）
// 参数：起止点、途经点列表、交通模式、决策类型、出发时间、算法计算结果
// ----------------- 渲染函数（地图 + 线路 + 节点 + UI 分层显示）-----------------
void Render(int start_node, int end_node, const vector<int>& vias, int vehicle, int decision, int hour, int minute, const GlobalResult& route_res) {  // 这是整个界面的主绘制函数，每一帧都会被调用一次
    // 1. 清空背景（地图区+侧边栏）
    setfillcolor(RGB(248, 250, 252));  // 设置整个窗口背景色为浅灰蓝
    solidrectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);  // 用背景色把整个窗口填满

    // 2. 绘制地图区网格（仅0-MAP_AREA_MAX范围）
    setlinecolor(RGB(235, 240, 245));  // 设置网格线颜色为淡灰
    setlinestyle(PS_SOLID, 1);  // 设置线条为细实线
    for (int i = 0; i < MAP_AREA_MAX; i += 30) line(i, 0, i, SCREEN_HEIGHT);  // 画竖线网格
    for (int i = 0; i < SCREEN_HEIGHT; i += 30) line(0, i, MAP_AREA_MAX, i);  // 画横线网格

    // 3. 绘制侧边栏背景（区分地图区）
    setfillcolor(WHITE);  // 设置侧边栏背景为白色
    setlinecolor(RGB(226, 232, 240));  // 设置边框颜色为浅灰
    fillrectangle(MAP_AREA_MAX, 0, SCREEN_WIDTH, SCREEN_HEIGHT);  // 在右侧区域画出侧边栏背景
    // 绘制分隔线
    setlinecolor(RGB(203, 213, 225));  // 设置地图和侧边栏之间的分隔线颜色
    line(MAP_AREA_MAX, 0, MAP_AREA_MAX, SCREEN_HEIGHT);  // 画出分隔线

    // 4. 绘制交通线路：飞机=蓝色虚线（天空），铁路=红色实线（铁轨）
    //    单类型模式下自动隐藏另一种线路，避免地图杂乱
    for (int i = 0; i < G.vexnum; i++) {  // 遍历所有城市节点
        ArcNode* arc = G.vertices[i].firstarc;  // 从当前城市的第一条边开始
        while (arc != NULL) {  // 遍历当前城市所有连出的线路
            // 单类型模式下隐藏另一种线路
            if (vehicle != TYPE_MIXED && arc->type != vehicle) {  // 如果当前只显示一种交通方式，就跳过另一种
                arc = arc->nextarc;  // 继续看下一条边
                continue;
            }
            COLORREF line_color = (arc->type == TYPE_FLIGHT)  
                ? RGB(59, 130, 246)   // 蓝色：飞机
                : RGB(239, 68, 68);    // 红色：铁路
            setlinecolor(line_color);  // 设置当前线路颜色
            setlinestyle(arc->type == TYPE_FLIGHT ? PS_DASH : PS_SOLID, 2);  // 飞机用虚线，铁路用实线
            line(G.vertices[i].x, G.vertices[i].y, G.vertices[arc->adjvex].x, G.vertices[arc->adjvex].y);  // 画出线路
            arc = arc->nextarc;  // 继续处理下一条边
        }
    }

    // 5. 绘制最优路径方向箭头（按段着色：深蓝=飞机段，深红=铁路段）
    //    只在算法已经计算出结果后才绘制（total_duration != INF）
    if (route_res.total_duration != INF && route_res.full_path.size() > 1) {  // 如果已经算出可行路径
        for (size_t i = 0; i < route_res.full_path.size() - 1; i++) {  // 遍历路径中的每一段
            int u = route_res.full_path[i];  // 当前段起点城市索引
            int v = route_res.full_path[i + 1];  // 当前段终点城市索引
            COLORREF seg_color = (i < route_res.segment_types.size() && route_res.segment_types[i] == TYPE_FLIGHT)
                ? RGB(37, 99, 235)    // 深蓝：飞机段
                : RGB(220, 38, 38);    // 深红：铁路段
            DrawArrow(G.vertices[u].x, G.vertices[u].y, G.vertices[v].x, G.vertices[v].y, seg_color);  // 画出当前段的方向箭头
        }
    }

    // 6. 绘制城市节点：起点=绿色, 终点=红色, 途经点=橙色, 普通=白色
    for (int i = 0; i < G.vexnum; i++) {  // 遍历所有城市节点
        bool is_start = (i == start_node);  // 判断当前节点是不是起点
        bool is_end = (i == end_node);  // 判断当前节点是不是终点
        bool is_via = (find(vias.begin(), vias.end(), i) != vias.end());  // 判断当前节点是不是途经点

        COLORREF circle_color = WHITE;  // 默认节点填充色为白色
        COLORREF border_color = RGB(148, 163, 184);  // 默认边框色为灰色
        if (is_start) {  // 如果是起点，就用绿色
            circle_color = RGB(34, 197, 94);  
            border_color = RGB(220, 252, 231);
        }
        else if (is_end) {  // 如果是终点，就用红色
            circle_color = RGB(244, 63, 94);  
            border_color = RGB(254, 226, 226);
        }
        else if (is_via) {  // 如果是途经点，就用橙色
            circle_color = RGB(245, 158, 11); 
            border_color = RGB(254, 243, 199);
        }

        setlinecolor(border_color);  // 设置外圈边框颜色
        setlinestyle(PS_SOLID, 3);  // 设置外圈线条粗细
        circle(G.vertices[i].x, G.vertices[i].y, 14);  // 画出节点外圈

        setfillcolor(circle_color);  // 设置节点填充色
        setlinecolor(RGB(71, 85, 105));  // 设置节点内部边框颜色
        setlinestyle(PS_SOLID, 1);  // 设置内部线条细
        fillcircle(G.vertices[i].x, G.vertices[i].y, 10);  // 填充节点圆形

        setbkmode(TRANSPARENT);  // 文字背景透明
        settextcolor(RGB(15, 23, 42));  // 设置城市名称文字颜色
        settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置文字样式
        outtextxy(G.vertices[i].x - textwidth(G.vertices[i].name) / 2, G.vertices[i].y + 18, G.vertices[i].name);  // 在节点下方输出城市名
    }

    // ====== 侧边栏UI：交通咨询控制台（从MAP_AREA_MAX+20开始，SIDEBAR_WIDTH=300宽）======
    // 分区排布：标题→城市信息→交通选择→决策选择→时间调整→功能按钮→规划状态→结果展示
    int sidebar_x = MAP_AREA_MAX + 20;  // 侧边栏起始 X 坐标
    int y = 20;  // 侧边栏起始 Y 坐标

    // 标题
    settextcolor(RGB(15, 23, 42));  // 设置标题文字颜色
    settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置标题字体
    outtextxy(sidebar_x, y, _T("交通咨询控制台"));  // 输出标题
    y += 35;  // 让下方内容往下排

    // 基础信息区
    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_MEDIUM, false, false, false);  // 设置基础信息字体
    settextcolor(RGB(51, 65, 85));  // 设置基础信息文字颜色
    
    TCHAR start_str[50] = _T("出发城市: [未选择]");  // 默认显示“未选择”
    if (start_node != -1) _stprintf_s(start_str, 50, _T("出发城市: %s (%s)"), G.vertices[start_node].name, G.vertices[start_node].code);  // 如果已选起点，就显示具体城市
    outtextxy(sidebar_x, y, start_str);  // 输出出发城市信息
    y += 28;  // 换下一行

    TCHAR end_str[50] = _T("目的地:   [未选择]");  // 默认显示“未选择”
    if (end_node != -1) _stprintf_s(end_str, 50, _T("目的地:   %s (%s)"), G.vertices[end_node].name, G.vertices[end_node].code);  // 如果已选终点，就显示具体城市
    outtextxy(sidebar_x, y, end_str);  // 输出目的地信息
    y += 28;  // 换下一行

    TCHAR vias_str[50];  // 保存途经点信息的字符串
    _stprintf_s(vias_str, 50, _T("中转途径点: %d 个"), (int)vias.size());  // 显示当前途经点数量
    outtextxy(sidebar_x, y, vias_str);  // 输出途经点数量
    y += 30;  // 换下一行

    // 交通工具选择区（三列）
    DrawButton(_T("航空"), sidebar_x, y, sidebar_x+58, y+30, vehicle == TYPE_FLIGHT);  // 画出航空模式按钮
    DrawButton(_T("铁路"), sidebar_x+65, y, sidebar_x+123, y+30, vehicle == TYPE_TRAIN);  // 画出铁路模式按钮
    DrawButton(_T("混合"), sidebar_x+130, y, sidebar_x+190, y+30, vehicle == TYPE_MIXED);  // 画出混合模式按钮
    y += 40;  // 下面内容下移

    // 决策类型选择区
    DrawButton(_T("最快到达"), sidebar_x, y, sidebar_x+90, y+30, decision == 1);  // 画出“最快到达”按钮
    DrawButton(_T("最省钱到达"), sidebar_x+100, y, sidebar_x+190, y+30, decision == 2);  // 画出“最省钱到达”按钮
    y += 40;  // 下面内容下移

    // 出发时间调整区
    TCHAR time_btn_str[30];  // 保存时间按钮文本
    _stprintf_s(time_btn_str, 30, _T("出发时间: %02d:%02d"), hour, minute);  // 拼出当前出发时间字符串
    DrawButton(time_btn_str, sidebar_x, y, sidebar_x+130, y+32, false);  // 画出显示当前时间的按钮
    DrawButton(_T("+"), sidebar_x+140, y, sidebar_x+165, y+32, false);  // 画出加一小时按钮
    DrawButton(_T("-"), sidebar_x+175, y, sidebar_x+190, y+32, false);  // 画出减一小时按钮
    y += 40;  // 下面内容下移

    // 功能按钮区（垂直排布，间距10）
    DrawButton(_T("随机生成途径点"), sidebar_x, y, sidebar_x+190, y+30, false);  // 画出随机生成途径点按钮
    y += 35;  // 换下一行
    DrawButton(_T("重置当前规划"), sidebar_x, y, sidebar_x+190, y+30, false);  // 画出重置当前规划按钮
    y += 35;  // 换下一行
    DrawButton(_T("开始最优检索"), sidebar_x, y, sidebar_x+190, y+30, true);  // 画出开始检索按钮
    y += 35;  // 换下一行
    DrawButton(_T("查看历史记录"), sidebar_x, y, sidebar_x+190, y+30, false);  // 画出查看历史记录按钮
    y += 35;  // 换下一行
    // 提示窗口可自由调整大小
    settextcolor(RGB(148, 163, 184));  // 设置提示文字颜色为灰蓝
    settextstyle(14, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置提示文字样式
    outtextxy(sidebar_x, y, _T("拖拽窗口边缘可自由调整大小"));  // 输出提示文字
    y += 25;  // 换下一行
        // ====== 当前规划状态区 ======
        // 显示用户当前选择的所有查询条件，让用户在点"开始最优检索"前确认
    setlinecolor(RGB(226, 232, 240));  // 设置状态区域边框颜色
    setfillcolor(RGB(248, 250, 252));  // 设置状态区域背景色
    fillroundrect(sidebar_x - 5, y, SCREEN_WIDTH - 20, y + 175, 12, 12);  // 画出带圆角的状态区域背景

    y += 10;  // 让内容从区域内部往下排

    settextcolor(RGB(15, 23, 42));  // 设置状态标题文字颜色
    settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置状态标题字体
    outtextxy(sidebar_x, y, _T("【当前规划状态】"));  // 输出状态标题
    y += 25;  // 换下一行

    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置状态内容字体
    settextcolor(RGB(51, 65, 85));  // 设置状态内容文字颜色

    TCHAR cur_line[180];  // 保存要输出的一行状态文字

    if (start_node != -1) {  // 如果已经选择了起点
        _stprintf_s(cur_line, 180, _T("起点：%s"), G.vertices[start_node].name);  // 拼出起点信息
    }
    else {  // 如果还没选起点
        _stprintf_s(cur_line, 180, _T("起点：未选择"));  // 显示未选择
    }
    outtextxy(sidebar_x, y, cur_line);  // 输出起点信息
    y += 24;  // 换下一行

    if (end_node != -1) {  // 如果已经选择了终点
        _stprintf_s(cur_line, 180, _T("终点：%s"), G.vertices[end_node].name);  // 拼出终点信息
    }
    else {  // 如果还没选终点
        _stprintf_s(cur_line, 180, _T("终点：未选择"));  // 显示未选择
    }
    outtextxy(sidebar_x, y, cur_line);  // 输出终点信息
    y += 24;  // 换下一行

    if (vias.empty()) {  // 如果当前没有途经点
        _stprintf_s(cur_line, 180, _T("途经：无"));  // 拼出“途经：无”
        outtextxy(sidebar_x, y, cur_line);  // 输出途经信息
        y += 24;  // 换下一行
    }
    else {  // 如果有途经点
        TString vias_text = _T("途经：");  // 先写一个“途经：”开头
        for (size_t i = 0; i < vias.size(); i++) {  // 遍历所有途经点
            vias_text += G.vertices[vias[i]].name;  // 拼接城市名
            if (i + 1 < vias.size()) vias_text += _T("、");  // 在多个途经点之间加分隔符
        }

        if (vias_text.length() > 16) {  // 如果途经点太多，就截断显示
            vias_text = vias_text.substr(0, 16);  // 只保留前 16 个字符
            vias_text += _T("...");  // 补省略号
        }

        outtextxy(sidebar_x, y, vias_text.c_str());  // 输出整理好的途经点字符串
        y += 24;  // 换下一行
    }

    _stprintf_s(cur_line, 180, _T("方式：%s"), VehicleName(vehicle));  // 拼出当前交通方式
    outtextxy(sidebar_x, y, cur_line);  // 输出交通方式
    y += 24;  // 换下一行

    _stprintf_s(cur_line, 180, _T("策略：%s"), DecisionName(decision));  // 拼出当前决策策略
    outtextxy(sidebar_x, y, cur_line);  // 输出策略
    y += 24;  // 换下一行

    _stprintf_s(cur_line, 180, _T("出发：%02d:%02d"), hour, minute);  // 拼出当前出发时间
    outtextxy(sidebar_x, y, cur_line);  // 输出出发时间
    y += 25;  // 换下一行
    // 分割线
    setlinecolor(RGB(226, 232, 240));  // 设置分隔线颜色
    line(MAP_AREA_MAX + 10, y, SCREEN_WIDTH - 20, y);  // 画出分隔线
    y += 15;  // 换下一行

    // ====== 结果展示区 ======
    // 显示算法计算结果：总耗时、总费用、前4段简要行程
    settextcolor(RGB(15, 23, 42));  // 设置结果标题文字颜色
    settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);  // 设置结果标题字体
    outtextxy(sidebar_x, y, _T("【智能乘车调度方案】"));  // 输出结果标题
    y += 25;  // 换下一行

    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);  // 设置结果内容字体
    settextcolor(RGB(71, 85, 105));  // 设置结果内容字体颜色
    if (route_res.total_duration == INF) {  // 如果还没有找到可行方案
        outtextxy(sidebar_x, y, _T("无活动方案。请依次在地图上"));  // 输出提示信息
        outtextxy(sidebar_x, y+20, _T("点击城市并点击“开始最优检索”。"));  // 输出下一行提示信息
    }
    else {  // 如果已经找到方案
        TCHAR duration_str[100];  // 保存总耗时字符串
        _stprintf_s(duration_str, 100, _T("全程总耗时: %d小时%d分钟"), route_res.total_duration / 60, route_res.total_duration % 60);  // 拼出总耗时文本
        outtextxy(sidebar_x, y, duration_str);  // 输出总耗时
        y += 20;  // 换下一行

        TCHAR cost_str[100];  // 保存总费用字符串
        _stprintf_s(cost_str, 100, _T("总旅行旅资: %.2f 元"), route_res.total_cost);  // 拼出总费用文本
        outtextxy(sidebar_x, y, cost_str);  // 输出总费用
        y += 20;  // 换下一行

        outtextxy(sidebar_x, y, _T("详细依次搭乘："));  // 输出“详细依次搭乘”提示
        y += 15;  // 换下一行
        for (size_t i = 0; i < route_res.full_schs.size() && i < 4; i++) {  // 只显示前 4 段行程
            TCHAR step_info[150];  // 用来保存一段行程的文字
            TCHAR dep_time_str[30];  // 保存出发时间字符串
            TCHAR arr_time_str[30];  // 保存到达时间字符串
            MinToTimeStr(route_res.dep_times_absolute[i], dep_time_str, 30);  // 把分钟数转成出发时间字符串
            MinToTimeStr(route_res.arr_times_absolute[i], arr_time_str, 30);  // 把分钟数转成到达时间字符串

            int u_idx = route_res.full_path[i];  // 当前段起点索引
            int v_idx = route_res.full_path[i + 1];  // 当前段终点索引

            _stprintf_s(step_info, 150, _T("%s->%s: %s (%s开)"), G.vertices[u_idx].name, G.vertices[v_idx].name, route_res.full_schs[i]->no, dep_time_str);  // 拼出某一段行程说明
            outtextxy(sidebar_x, y, step_info);  // 输出这一段行程
            y += 15;  // 换下一行
        }
        if (route_res.full_schs.size() > 4) {  // 如果方案段数超过 4 段，就显示省略号提示
            outtextxy(sidebar_x, y, _T("...(省略后续中转步骤)..."));  // 输出省略提示
        }
    }

    // 绘制右键菜单（最顶层）
    DrawContextMenu();  // 把右键菜单画在最上层，确保它能覆盖其他内容
}

// 参与人员：董
// ====== 最优结果自动弹窗 ======
// 触发时机：用户点击"开始最优检索"且成功找到路线后自动弹出
// 弹窗内容：标题（时间最优/费用最优）+ 完整路径箭头 + 总耗时/总费用 + 每段详情
// 为什么用 MessageBox？简单可靠，自带滚动条，不需要自己画窗口
// ----------------- 自动弹窗：显示最优计算结果 -----------------
// 这个函数会把当前计算出的最优路线整理成一段可读文本，然后用消息框弹给用户
void ShowResultPopup(int start_node, int end_node, int decision, int start_hour, int start_minute, const GlobalResult& res) {  // 这是一个把最优方案弹窗显示给用户的函数
    // 如果没有有效路线，或者没有可显示的方案内容，就直接返回，避免弹出空白结果
    if (res.total_duration == INF || res.full_path.empty() || res.full_schs.empty()) return;  // 如果没有找到路线，就不弹窗

    // text 用来拼接整个弹窗内容，line 则作为单行格式化缓冲区
    TString text;  // 用来拼接整个弹窗内容
    TCHAR line[512];  // 每一行的缓冲区

    // 标题：根据决策类型区分
    // 时间最优和费用最优分别显示不同的标题，方便用户一眼看出当前方案类型
    text += (decision == 1) ? _T("★★★ 时间最优方案 ★★★\n") : _T("★★★ 费用最优方案 ★★★\n"); // 根据决策类型显示标题
    text += _T("（自动计算结果）\n\n");   // 提示这是自动计算的结果

    // 起止点与策略
    // 这里把出发地、目的地、出发时间和当前优化策略一起写进弹窗正文
    _stprintf_s(line, 512, _T("出发地：%s\n目的地：%s\n出发时间：%02d:%02d\n优化策略：%s\n\n"),  // 拼接起止点、出发时间和策略信息
        G.vertices[start_node].name,   // 出发地名称
        G.vertices[end_node].name,     // 目的地名称
        start_hour, start_minute,       // 出发时间
        (decision == 1) ? _T("最快到达（时间优先）") : _T("最省钱的方案（费用优先）")); // 优化策略
    text += line;

    // 路径概览
    _stprintf_s(line, 512, _T("【完整路径】\n"));  // 拼接完整路径标题
    text += line;   // 添加完整路径标题
    for (size_t i = 0; i < res.full_path.size(); i++) {  // 遍历完整路径中的每个节点
        text += G.vertices[res.full_path[i]].name;   // 添加当前节点名称
        if (i + 1 < res.full_path.size()) text += _T("  →  ");  // 如果不是最后一个节点，就添加箭头符号
    }
    text += _T("\n\n");  // 换行，准备显示总耗时和总费用

    // 总耗时和总费用
    _stprintf_s(line, 512, _T("【行程总览】\n总耗时：%d 小时 %d 分钟\n总费用：¥ %.2f 元\n总段数：%d 段\n换乘次数：%d 次\n\n"),
        res.total_duration / 60, res.total_duration % 60,  // 总耗时
        res.total_cost,   // 总费用
        (int)res.full_schs.size(),  // 总段数
        (int)res.full_schs.size() > 0 ? (int)res.full_schs.size() - 1 : 0);  // 拼接总耗时、总费用、总段数和换乘次数信息
    text += line;  // 添加总览信息到弹窗正文

    // 详细分段
    text += _T("【详细分段】\n");  // 添加详细分段标题
    for (size_t i = 0; i < res.full_schs.size(); i++) {  // 遍历每一段行程，显示详细信息
        int u_idx = res.full_path[i];  // 当前段的起点索引
        int v_idx = res.full_path[i + 1];  // 当前段的起点和终点索引

        TCHAR dep_str[40], arr_str[40];  // 保存出发时间和到达时间的字符串
        MinToTimeStr(res.dep_times_absolute[i], dep_str, 40);  // 把分钟数转成时间字符串
        MinToTimeStr(res.arr_times_absolute[i], arr_str, 40);  // 把分钟数转成时间字符串

        const TCHAR* type_name = (res.segment_types[i] == TYPE_FLIGHT) ? _T("[航空]") : _T("[铁路]");  // 根据交通方式选择标签

        _stprintf_s(line, 512, _T("第%d段：%s → %s | %s | %s | %s → %s | ¥%.0f\n"),  // 拼接每段行程的详细信息
            (int)i + 1,   // 段数
            G.vertices[u_idx].name,  // 出发地名称
            G.vertices[v_idx].name,  // 目的地名称
            type_name,   // 交通方式标签
            res.full_schs[i]->no,  // 车次/航班号
            dep_str, arr_str,  // 出发时间和到达时间
            res.full_schs[i]->cost);  // 费用
        text += line;   // 添加每段行程信息到弹窗正文

        // 换乘等待时间
        if (i > 0) {
            int wait = res.dep_times_absolute[i] - res.arr_times_absolute[i - 1];  // 计算换乘等待时间（分钟）
            if (wait < 0) wait = 0;  // 如果计算结果为负数，说明时间有误，强制设为0
            if (wait > 0) {  // 如果有换乘等待时间，就显示出来
                _stprintf_s(line, 512, _T("    ↳ 换乘等待：%d 小时 %d 分钟\n"), wait / 60, wait % 60);  // 拼接换乘等待时间信息
                text += line;  // 添加换乘等待时间信息到弹窗正文
            }
        }
    }

    MessageBox(GetHWnd(), text.c_str(), _T("最优路线计算结果"), MB_OK | MB_ICONINFORMATION);  // 弹出消息框显示结果
}

// 参与人员：董 王
// ====== 主函数：程序入口 + 系统集成 + 事件循环 ======
// 运行流程：初始化数据 → 创建窗口 → 进入主循环(渲染→处理输入→渲染→处理输入...)
// 事件循环：每帧先渲染画面，再处理鼠标消息（左键点击/右键菜单）
// 模块调度：根据用户操作调用不同子系统（路线计算/历史记录/航线管理面板）
// ----------------- 主函数（系统集成 + 事件循环 + 模块调度）-----------------
int main() {  // 程序入口，整个系统从这里开始运行
    // === 第1步：初始化交通网络数据 ===
    InjectTestData();  // 先把测试数据灌进图结构中，保证程序一启动就有内容可显示

    // === 第2步：创建 EasyX 图形窗口（1200×800 像素，适合大多数屏幕）===
    initgraph(1200, 800);  // 创建窗口，EasyX 会自动计算客户区大小

    // === 第3步：设置窗口样式，允许用户拖拽边缘自由缩放 ===
    // WS_SIZEBOX = 可拖拽边框, WS_MAXIMIZEBOX = 最大化按钮
    {
        HWND hwnd_init = GetHWnd();  // 获取 EasyX 创建的窗口句柄
        LONG style_init = GetWindowLong(hwnd_init, GWL_STYLE);  // 获取当前窗口样式
        SetWindowLong(hwnd_init, GWL_STYLE, style_init | WS_SIZEBOX | WS_MAXIMIZEBOX);  // 添加可拖拽边框和最大化按钮
        SetWindowPos(hwnd_init, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);    // 立即刷新窗口样式
    }
    // 所有窗口调整完毕后同步实际客户区尺寸
    {
        RECT init_rect;   // 获取客户区矩形
        GetClientRect(GetHWnd(), &init_rect);  // 获取客户区矩形
        SCREEN_WIDTH = init_rect.right - init_rect.left;    // 计算客户区宽度
        SCREEN_HEIGHT = init_rect.bottom - init_rect.top;   // 计算客户区高度
        MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;        // 计算地图区域最大宽度
    }

    // === 第4步：启动 EasyX 双缓冲渲染（避免画面闪烁）===
    // TRANSPARENT = 文字背景透明（不会盖住下面的地图线条）
    setbkmode(TRANSPARENT);
    BeginBatchDraw();  // 全局批渲染开始，每帧只需 FlushBatchDraw

    int start_node = -1;  // -1 表示未选择起点
    int end_node = -1;    // -1 表示未选择终点
    vector<int> vias;     // 保存途经点的索引列表
    int vehicle = TYPE_FLIGHT;  // 默认交通方式为航空
    int decision = 1;    // 默认决策策略为时间最优
    int start_hour = 11;  // 默认出发时间为 11:00
    int start_minute = 0;  // 默认出发时间为 11:00

    GlobalResult route_result;   // 保存当前路线计算结果的结构体
    route_result.total_duration = INF;  // 默认总耗时为无穷大，表示还没有计算出路线

    ExMessage msg;   // 用于接收鼠标消息的结构体
    DWORD last_resize_time = 0;   // 记录上一次窗口缩放的时间戳，用于防抖处理，避免频繁重建窗口

    // === 第5步：主事件循环（程序的核心"心跳"）===
    // 每16ms一帧（~60FPS）：先画 → 再处理输入 → 循环
    while (true) {
        // 每一帧都先根据当前状态重新绘制整个界面
        Render(start_node, end_node, vias, vehicle, decision, start_hour, start_minute, route_result);
        FlushBatchDraw();  // 把后台画好的内容一次性翻到屏幕上（双缓冲）

        // ---- 窗口缩放检测：支持用户拖拽边缘调整大小 ----
        // 如果窗口大小发生变化，就重新创建绘图环境，避免界面变形或渲染异常
        RECT cur_rect;
        if (GetClientRect(GetHWnd(), &cur_rect)) {
            int cur_w = cur_rect.right - cur_rect.left;
            int cur_h = cur_rect.bottom - cur_rect.top;
            if ((cur_w != SCREEN_WIDTH || cur_h != SCREEN_HEIGHT) && cur_w >= 600 && cur_h >= 400) {  // 窗口最小尺寸限制，避免过小导致布局错乱
                // 鼠标按住时跳过（用户正在拖拽边缘，松手后再重建）
                if (GetKeyState(VK_LBUTTON) & 0x8000) { Sleep(16); continue; }
                DWORD now_tick = GetTickCount();
                if (now_tick - last_resize_time > 300) {  // 300ms防抖：避免拖拽时每秒重建几十次
                    last_resize_time = now_tick; 
    
                    SCREEN_WIDTH = cur_w;
                    SCREEN_HEIGHT = cur_h;
                    MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;
                    if (MAP_AREA_MAX < 200) MAP_AREA_MAX = 200;

                    // 1. 记录旧窗口的位置和最大化状态
                    HWND old_hwnd = GetHWnd();
                    bool is_maximized = IsZoomed(old_hwnd);
                    RECT old_win_rect;
                    GetWindowRect(old_hwnd, &old_win_rect);

                    EndBatchDraw();
                    closegraph();

                    // 2. 注意：EasyX 的 initgraph 参数直接传入客户区大小即可，无需 AdjustWindowRect
                    initgraph(cur_w, cur_h);

                    HWND hwnd2 = GetHWnd();
                    LONG style2 = GetWindowLong(hwnd2, GWL_STYLE);
                    SetWindowLong(hwnd2, GWL_STYLE, style2 | WS_SIZEBOX | WS_MAXIMIZEBOX);

                    // 3. 完美恢复窗口之前的状态和位置
                    if (is_maximized) {
                        ShowWindow(hwnd2, SW_MAXIMIZE);
                    } else {
                        SetWindowPos(hwnd2, NULL, old_win_rect.left, old_win_rect.top, 0, 0,
                            SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
                    }

                    // 4. 所有窗口调整完毕后再同步实际客户区尺寸
                    RECT sync_rect;
                    GetClientRect(hwnd2, &sync_rect);
                    SCREEN_WIDTH = sync_rect.right - sync_rect.left;  // 计算客户区宽度
                    SCREEN_HEIGHT = sync_rect.bottom - sync_rect.top;  // 计算客户区高度

                    MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;
                    if (MAP_AREA_MAX < 200) MAP_AREA_MAX = 200;

                    setbkmode(TRANSPARENT);
                    BeginBatchDraw();
                    cleardevice();
                    route_result.total_duration = INF; // 刷新路线绘制
                    
                    // 再次更新防抖时间，防止 ShowWindow(SW_MAXIMIZE) 触发二次死循环
                    last_resize_time = GetTickCount();
                    continue;
                }
            }
        }
        // --------------------------------------------------------

        // ---- 鼠标输入处理 ----
        // peekmessage 逐一取出鼠标事件（左键按下、滚轮等）
        // 这里优先处理点击操作，确保地图和控件的交互响应及时
        while (peekmessage(&msg, EM_MOUSE)) {   // 只处理鼠标消息
            if (msg.message == WM_LBUTTONDOWN) {  // 鼠标左键按下
                int mx = msg.x;  // 鼠标点击位置X坐标
                int my = msg.y;  // 鼠标点击位置Y坐标

                // 优先处理右键菜单（如果菜单打开，点击要么选菜单项，要么关闭菜单）
                if (g_ctx_menu_visible) {  // 当前右键菜单正在显示，后续点击都先交给菜单逻辑处理
                    int menu_w = CTX_MENU_WIDTH;  // 菜单宽度固定，方便判断是否点击在菜单区域内
                    int menu_h = CTX_MENU_PADDING * 2 + g_ctx_menu_count * CTX_MENU_ITEM_H; // 菜单高度由上下边距和条目数量决定
                    // 点击菜单外部 → 关闭菜单，不执行任何操作
                    if (mx < g_ctx_menu_x || mx > g_ctx_menu_x + menu_w ||    
                        my < g_ctx_menu_y || my > g_ctx_menu_y + menu_h) {
                        g_ctx_menu_visible = false;  // 关闭当前菜单
                        continue;  // 结束本次点击处理，避免后续地图逻辑误触发
                    }
                    // 点击菜单项：遍历每一项，判断鼠标落在了哪一项上
                    for (int i = 0; i < g_ctx_menu_count; i++) {
                        int item_y = g_ctx_menu_y + CTX_MENU_PADDING + i * CTX_MENU_ITEM_H;  // 当前菜单项的纵坐标
                        if (my >= item_y && my < item_y + CTX_MENU_ITEM_H) {
                            g_ctx_menu_visible = false;  // 先收起菜单，避免重复显示
                            // 根据菜单类型执行不同动作
                            if (g_ctx_menu_target == -1) {
                                // 这是空白处右键弹出的菜单，提供添加节点和管理航线的操作
                                if (i == 0) {
                                    // 添加节点：弹出输入框，让用户输入城市名和三字代码
                                    TCHAR new_name[30] = {0}, new_code[10] = {0};
                                    if (InputBox(new_name, 30, _T("请输入新城市名称："), _T("添加节点 - 名称"))
                                        && InputBox(new_code, 10, _T("请输入三字代码："), _T("添加节点 - 代码"))) {
                                        AddVertex(new_name, new_code, g_ctx_menu_x, g_ctx_menu_y);  // 把新节点加入地图
                                        route_result.total_duration = INF;  // 清空当前路线缓存，防止旧结果残留
                                    }
                                } else if (i == 1) {
                                    // 打开全航线管理面板，用户可在其中维护线路信息
                                    FlushBatchDraw();
                                    EndBatchDraw();
                                    RouteManagementPanel();
                                    setbkmode(TRANSPARENT);
                                    BeginBatchDraw();
                                    route_result.total_duration = INF;  // 重新计算路线时刷新显示
                                }
                            } else {
                                // 这是点击某个节点后弹出的菜单，提供删除与详情查看操作
                                if (i == 0) {
                                    // 删除节点：确认后删掉该节点及其关联线路
                                    TCHAR cfm[120];
                                    _stprintf_s(cfm, 120, _T("确定删除 [%s] 及其关联线路？"),
                                        G.vertices[g_ctx_menu_target].name);
                                    if (MessageBox(GetHWnd(), cfm, _T("删除"), MB_YESNO | MB_ICONWARNING) == IDYES) {
                                        DeleteVertexByName(G.vertices[g_ctx_menu_target].name);  // 删除对应城市节点
                                        start_node = -1; end_node = -1; vias.clear();  // 清空当前选择状态
                                        route_result.total_duration = INF;  // 取消旧路线结果
                                    }
                                } else if (i == 1) {
                                    // 查看节点详情：展示城市名称、代码和坐标信息
                                    TCHAR info[256];
                                    _stprintf_s(info, 256, _T("城市：%s\n三字码：%s\n坐标：(X=%d, Y=%d)"),  //
                                        G.vertices[g_ctx_menu_target].name,
                                        G.vertices[g_ctx_menu_target].code,
                                        G.vertices[g_ctx_menu_target].x,
                                        G.vertices[g_ctx_menu_target].y);
                                    MessageBox(GetHWnd(), info, _T("节点详情"), MB_OK | MB_ICONINFORMATION);
                                }
                            }
                            break;  // 找到命中的菜单项后立即结束循环
                        }
                    }
                    continue;  // 本次点击已由菜单逻辑消费，跳过后面的地图点击处理
                }

                // A. 地图区：检测是否点中了某个城市节点（IsInCircle碰撞检测）
                int clicked_node = -1;  // -1表示未点击到任何节点
                if (mx < MAP_AREA_MAX) {   // 只在地图区域内检测节点点击
                    for (int i = 0; i < G.vexnum; i++) {  // 遍历所有城市节点
                        if (IsInCircle(mx, my, G.vertices[i].x, G.vertices[i].y, 14)) {  // 半径14像素的圆形碰撞检测
                            clicked_node = i;  // 记录点击到的节点索引
                            break;  // 找到第一个被点击的节点后就退出循环
                        }
                    }
                }

                if (clicked_node != -1) {  // 用户点击了某个城市节点    
                    if (start_node == -1) {  // 如果还没选起点，就把点击的节点设为起点
                        start_node = clicked_node;  // 记录起点索引
                    }
                    else if (end_node == -1) {   // 如果还没选终点，就把点击的节点设为终点
                        if (clicked_node != start_node) {  // 如果点击的节点不是起点，就设为终点
                            end_node = clicked_node;   // 记录终点索引
                        }
                        else {
                            start_node = -1;   // 如果点击的节点是起点，就取消起点选择
                        }
                    }
                    else {
                        if (clicked_node == start_node) {   // 如果点击的节点是起点，就取消起点选择
                            start_node = -1;  // 取消起点选择
                        }
                        else if (clicked_node == end_node) {  // 如果点击的节点是终点，就取消终点选择
                            end_node = -1;    // 取消终点选择
                        }
                        else {
                            auto it = find(vias.begin(), vias.end(), clicked_node);  // 检查点击的节点是否已经在途经点列表中
                            if (it != vias.end()) {  // 如果点击的节点已经在途经点列表中，就把它移除
                                vias.erase(it);   // 移除途经点
                            }
                            else {
                                vias.push_back(clicked_node); // 如果点击的节点不在途经点列表中，就把它加入途经点列表
                            }
                        }
                    }
                    route_result.total_duration = INF; // 任何点击操作都清空当前路线结果，等待下一次计算
                }

                // B. 侧边栏：检测是否点中了按钮（IsInRect矩形检测）
                int sb_x = MAP_AREA_MAX + 20;  // 侧边栏按钮的X坐标起点
                if (mx >= MAP_AREA_MAX) {      // 只在侧边栏区域内检测按钮点击
                    // 交通工具按钮（三列）
                    if (IsInRect(mx, my, sb_x, 140, sb_x+58, 170)) {  // 检测是否点击了航空按钮
                        vehicle = TYPE_FLIGHT;   // 设置交通方式为航空
                        route_result.total_duration = INF;   // 清空当前路线结果，等待下一次计算
                    }
                    if (IsInRect(mx, my, sb_x+65, 140, sb_x+123, 170)) {  // 检测是否点击了铁路按钮
                        vehicle = TYPE_TRAIN;   // 设置交通方式为铁路
                        route_result.total_duration = INF;   // 清空当前路线结果，等待下一次计算
                    }
                    if (IsInRect(mx, my, sb_x+130, 140, sb_x+190, 170)) {   // 检测是否点击了混合按钮
                        vehicle = TYPE_MIXED;   // 设置交通方式为混合
                        route_result.total_duration = INF;  // 清空当前路线结果，等待下一次计算
                    }

                    // 决策类型按钮
                    if (IsInRect(mx, my, sb_x, 180, sb_x+90, 210)) {   // 检测是否点击了时间最优按钮
                        decision = 1;     // 设置决策类型为时间最优
                        route_result.total_duration = INF;   // 清空当前路线结果，等待下一次计算
                    }
                    if (IsInRect(mx, my, sb_x+100, 180, sb_x+190, 210)) {   // 检测是否点击了费用最优按钮
                        decision = 2;
                        route_result.total_duration = INF;   // 清空当前路线结果，等待下一次计算
                    }

                    // 时间调整按钮
                    if (IsInRect(mx, my, sb_x+140, 220, sb_x+165, 250)) {     // 检测是否点击了"增加1小时"按钮
                        start_hour = (start_hour + 1) % 24;   // 增加1小时，超过23点就回到0点
                        route_result.total_duration = INF;    // 清空当前路线结果，等待下一次计算
                    }
                    if (IsInRect(mx, my, sb_x+175, 220, sb_x+190, 250)) {   // 检测是否点击了"减少1小时"按钮
                        start_hour = (start_hour + 23) % 24;    // 减少1小时，低于0点就回到23点
                        route_result.total_duration = INF;      // 清空当前路线结果，等待下一次计算
                    }

                    // 功能按钮
                    if (IsInRect(mx, my, sb_x, 260, sb_x+190, 290)) {   // 检测是否点击了"开始最优检索"按钮
                        if (start_node != -1 && end_node != -1) {   // 如果起点和终点都已选择，就随机生成若干个途经点
                            vias.clear();
                            vector<int> candidates;
                            for (int i = 0; i < G.vexnum; i++) {   // 遍历所有节点，生成候选途经点列表
                                if (i != start_node && i != end_node) candidates.push_back(i);  // 生成候选途经点列表，排除起点和终点
                            }
                            if (candidates.size() > 0) {   // 如果有候选途经点，就随机选择若干个加入途经点列表
                                int count = rand() % 2 + 1;  // 随机选择1~2个途经点
                                std::random_device rd;  // 用于生成随机数种子
                                std::mt19937 g(rd());   // 用于随机打乱候选节点顺序的随机数生成器
                                std::shuffle(candidates.begin(), candidates.end(), g);  // 随机打乱候选节点顺序
                                for (int i = 0; i < count && i < (int)candidates.size(); i++) {   // 随机选择若干个途经点加入列表
                                    vias.push_back(candidates[i]);   // 添加随机途经点
                                }
                            }
                            route_result.total_duration = INF;
                        }
                    }
                    if (IsInRect(mx, my, sb_x, 295, sb_x+190, 325)) {
                        start_node = -1;
                        end_node = -1;
                        vias.clear();
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x, 330, sb_x+190, 360)) {   // 检测是否点击了"开始最优检索"按钮
                        if (start_node != -1 && end_node != -1) {       // 如果起点和终点都已选择，就开始计算最优路线
                            int base_start_min = start_hour * 60 + start_minute;  // 把出发时间转换为分钟数，方便后续计算

                            // 先正常计算路线
                            route_result = SolveWithVias(start_node, end_node, base_start_min, decision, vehicle, vias);

                            // 如果找到路线，就保存到历史记录并自动弹出结果
                                if (route_result.total_duration != INF) {   // 如果找到可行路线，就把本次计算结果加入历史记录
                                    AddHistoryRecord(
                                    start_node,
                                    end_node,
                                    vias,
                                    vehicle,
                                    decision,
                                    start_hour,
                                    start_minute,
                                    route_result
                                    );
                                    // 自动弹出本次最优计算结果
                                    ShowResultPopup(start_node, end_node, decision, start_hour, start_minute, route_result);
                                }
                            }
                        }
                        if (IsInRect(mx, my, sb_x, 365, sb_x+190, 395)) {   // 历史记录按钮
                            ShowHistoryWindow();
                        }
                    }
                }
            }   

        // ---- 右键菜单触发 ----
        // 为什么用 GetAsyncKeyState 而不是 peekmessage？
        // peekmessage 只取队列消息，如果消息处理慢可能丢失右键事件
        // GetAsyncKeyState 直接查询物理按键状态，更可靠
        {
            static bool prev_rbtn = false;
            bool cur_rbtn = GetAsyncKeyState(VK_RBUTTON) & 0x8000;  // 获取当前右键按下状态
            if (cur_rbtn && !prev_rbtn) {  
                // 右键刚按下
                POINT pt;
                GetCursorPos(&pt);
                ScreenToClient(GetHWnd(), &pt);
                int mx = pt.x, my = pt.y;

                if (mx < MAP_AREA_MAX && !g_ctx_menu_visible) {
                    // 检测节点
                    int clicked_node = -1;
                    for (int i = 0; i < G.vexnum; i++) {
                        if (IsInCircle(mx, my, G.vertices[i].x, G.vertices[i].y, 14)) {  // 半径14像素的圆形碰撞检测
                            clicked_node = i; break;
                        }
                    }
                    g_ctx_menu_target = clicked_node;  // 记录右键菜单的目标节点索引（-1表示空白处）
                    g_ctx_menu_x = mx; g_ctx_menu_y = my;  // 记录右键菜单的屏幕坐标
                    g_ctx_menu_count = 2;  // 菜单项数量
                    g_ctx_menu_visible = true;  // 显示右键菜单
                    g_ctx_menu_hover = -1;   // 重置悬停状态，避免上次悬停残留
                }
            }
            prev_rbtn = cur_rbtn;  // 记录当前右键状态，供下一帧比较
        }

        Sleep(16);  // 每帧约16ms，约60FPS
    }

    EndBatchDraw();  // 结束双缓冲渲染
    closegraph();  // 关闭 EasyX 图形窗口

    // === 程序退出：释放所有动态分配的内存 ===
    // 遍历每个城市，释放它的出边链表（边链表内部会递归释放班次链表）
    for (int i = 0; i < G.vexnum; i++) {  // 遍历每个城市节点
        FreeArcList(G.vertices[i].firstarc);  // 释放每个城市的出边链表，避免内存泄漏
    }

    return 0;  // 程序正常退出
}