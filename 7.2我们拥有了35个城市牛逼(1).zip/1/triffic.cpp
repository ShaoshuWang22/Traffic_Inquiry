#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#pragma execution_character_set("utf-8")
#define _CRT_SECURE_NO_WARNINGS

#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <vector>
#include <string>
#include <algorithm>
#include <random>
#include <queue>
#include <tchar.h>

// --- UCRT MinGW 兼容补丁 ---
// EasyX 库可能依赖旧版 MSVCRT 的 __iob_func 符号，
// 新版 MinGW-w64 (UCRT) 已移除该符号，此处提供兼容定义。
// 若链接时报 undefined reference to __iob_func 则需要此补丁。
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#ifdef __cplusplus
extern "C" {
#endif
    FILE* __cdecl __iob_func(void) {
        static FILE* mock_iob[3] = { stdin, stdout, stderr };
        return (FILE*)mock_iob;
    }
    void* __imp___iob_func = (void*)__iob_func;
#ifdef __cplusplus
}
#endif
#pragma GCC diagnostic pop
// --- UCRT MinGW 兼容补丁结束 ---

using namespace std;

#define MAX_VERTEX 50
#define INF 1e9
#define TYPE_FLIGHT 1
#define TYPE_TRAIN 2
#define MAP_AREA_WIDTH (SCREEN_WIDTH - SIDEBAR_WIDTH)
// ----------------- 数据结构定义 -----------------
typedef struct Schedule {
    TCHAR no[20];         // 班次号
    int dep_time;        // 出发时间（分钟）
    int arr_time;        // 到达时间
    double cost;         // 费用
    struct Schedule* next;
} Schedule;

typedef struct ArcNode {
    int adjvex;              // 目标城市下标
    int distance;            // 里程
    int type;                // 1-飞机，2-火车
    Schedule* sch_list;      // 班次链表
    struct ArcNode* nextarc;
} ArcNode;

typedef struct VNode {
    TCHAR name[30];          // 城市名称
    TCHAR code[10];          // 三字代码
    int x, y;                // 地图像素坐标
    ArcNode* firstarc;
} VNode, AdjList[MAX_VERTEX];

typedef struct {
    AdjList vertices;
    int vexnum;
} Graph;

typedef struct {
    double best_value;   // 累积最优值
    int pre_vex;         // 前驱城市
    Schedule* chosen_sch;// 选中的班次
    int arrival_time;    // 到达绝对时间
} PathState;

// ----------------- 全局变量 -----------------
Graph G;
int SCREEN_WIDTH = 1480;
int SCREEN_HEIGHT = 900;
int SIDEBAR_WIDTH = 300;
int MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;
// ----------------- 工具函数 -----------------
int TimeToMin(const TCHAR* time_str) {
    int h = 0, m = 0;
    if (_stscanf_s(time_str, _T("%d:%d"), &h, &m) == 2) {
        return h * 60 + m;
    }
    return 0;
}

// 辅助函数：删除节点（简单实现：标记法或重置法）
void DeleteNode(int node_idx) 
{
    if (node_idx < 0 || node_idx >= G.vexnum) return
;
    // 简单的删除策略：将最后一个节点移到当前位置，更新vexnum
    // 注意：这会改变所有节点的索引，在本项目中可能需要清空当前路径缓存
    G.vexnum--;
    G.vertices[node_idx] = G.vertices[G.vexnum];
    // 清除关联的边(简化处理)
    G.vertices[node_idx].firstarc = 
NULL
; 
}

void MinToTimeStr(int total_min, TCHAR* out_str, size_t size) {
    int days = total_min / 1440;
    int rem = total_min % 1440;
    int h = rem / 60;
    int m = rem % 60;
    if (days == 0) {
        _stprintf_s(out_str, size, _T("当天 %02d:%02d"), h, m);
    }
    else {
        _stprintf_s(out_str, size, _T("第%d天 %02d:%02d"), days + 1, h, m);
    }
}

int LocateVex(const TCHAR* name) {
    for (int i = 0; i < G.vexnum; i++) {
        if (_tcscmp(G.vertices[i].name, name) == 0) return i;
    }
    return -1;
}

int AddVertex(const TCHAR* name, const TCHAR* code, int x, int y) {
    if (G.vexnum >= MAX_VERTEX) return -1;
    // 限制城市坐标在地图区内
    int mapRight = SCREEN_WIDTH - SIDEBAR_WIDTH - 40;
    int mapBottom = SCREEN_HEIGHT - 40;

    if (x > mapRight) x = mapRight;
    if (y > mapBottom) y = mapBottom;
    if (x < 40) x = 40;
    if (y < 40) y = 40;

    int idx = LocateVex(name);
    if (idx != -1) return idx;
    _tcscpy_s(G.vertices[G.vexnum].name, 30, name);
    _tcscpy_s(G.vertices[G.vexnum].code, 10, code);
    G.vertices[G.vexnum].x = x;
    G.vertices[G.vexnum].y = y;
    G.vertices[G.vexnum].firstarc = NULL;
    G.vexnum++;
    return G.vexnum - 1;
}

ArcNode* AddArc(int u, int v, int distance, int type) {
    ArcNode* p = G.vertices[u].firstarc;
    while (p != NULL) {
        if (p->adjvex == v && p->type == type) return p;
        p = p->nextarc;
    }
    ArcNode* arc = (ArcNode*)malloc(sizeof(ArcNode));
    if (!arc) return NULL;
    arc->adjvex = v;
    arc->distance = distance;
    arc->type = type;
    arc->sch_list = NULL;
    arc->nextarc = G.vertices[u].firstarc;
    G.vertices[u].firstarc = arc;
    return arc;
}

void AddSchedule(ArcNode* arc, const TCHAR* no, int dep, int arr, double cost) {
    if (!arc) return;
    Schedule* sch = (Schedule*)malloc(sizeof(Schedule));
    if (!sch) return;
    _tcscpy_s(sch->no, 20, no);
    sch->dep_time = dep;
    sch->arr_time = arr;
    sch->cost = cost;
    sch->next = arc->sch_list;
    arc->sch_list = sch;
}

// ----------------- 初始化测试数据 -----------------
void DeleteVertexByName(const TCHAR* name) {
    int idx = LocateVex(name);
    if (idx == -1) {
        MessageBox(GetHWnd(), _T("未找到该城市！"), _T("错误"), MB_OK | MB_ICONERROR);
        return;
    }

    // 1. 删除所有指向该节点的边
    for (int i = 0; i < G.vexnum; i++) {
        ArcNode** p = &G.vertices[i].firstarc;
        while (*p != NULL) {
            if ((*p)->adjvex == idx) {
                ArcNode* temp = *p;
                *p = (*p)->nextarc;
                // 这里建议写一个释放 Schedule 链表的函数防止内存泄漏
                free(temp); 
            } else {
                // 如果边的指向索引大于被删除的节点，需要修正索引
                if ((*p)->adjvex > idx) (*p)->adjvex--;
                p = &((*p)->nextarc);
            }
        }
    }

    // 2. 将数组中的最后一个元素移到被删除的位置
    G.vexnum--;
    if (idx < G.vexnum) {
        G.vertices[idx] = G.vertices[G.vexnum];
    }
    
    MessageBox(GetHWnd(), _T("节点删除成功，相关链路已清理。"), _T("提示"), MB_OK | MB_ICONINFORMATION);
}

void InjectTestData() {
    G.vexnum = 0;

        // ================= 城市节点：重新排布版 =================
    int ur  = AddVertex(_T("乌鲁木齐"), _T("URC"), 90, 120);
    int xn  = AddVertex(_T("西宁"), _T("XNN"), 230, 250);
    int lz  = AddVertex(_T("兰州"), _T("LHW"), 290, 230);
    int yc  = AddVertex(_T("银川"), _T("INC"), 340, 170);
    int hh  = AddVertex(_T("呼和浩特"), _T("HET"), 470, 110);

    int bj  = AddVertex(_T("北京"), _T("BJS"), 600, 170);
    int tj  = AddVertex(_T("天津"), _T("TSN"), 660, 200);
    int sjz = AddVertex(_T("石家庄"), _T("SJW"), 560, 245);
    int ty  = AddVertex(_T("太原"), _T("TYN"), 500, 230);

    int hrb = AddVertex(_T("哈尔滨"), _T("HRB"), 790, 55);
    int cc  = AddVertex(_T("长春"), _T("CGQ"), 760, 105);
    int sy  = AddVertex(_T("沈阳"), _T("SHE"), 730, 165);
    int dl  = AddVertex(_T("大连"), _T("DLC"), 760, 235);

    int xa  = AddVertex(_T("西安"), _T("SIA"), 430, 310);
    int zz  = AddVertex(_T("郑州"), _T("CGO"), 555, 325);
    int jn  = AddVertex(_T("济南"), _T("TNA"), 665, 285);
    int qd  = AddVertex(_T("青岛"), _T("TAO"), 755, 300);

    int hf  = AddVertex(_T("合肥"), _T("HFE"), 640, 390);
    int nj  = AddVertex(_T("南京"), _T("NKG"), 710, 380);
    int sh  = AddVertex(_T("上海"), _T("SHA"), 805, 400);
    int hz  = AddVertex(_T("杭州"), _T("HGH"), 755, 455);

    int wh  = AddVertex(_T("武汉"), _T("WUH"), 560, 430);
    int nc  = AddVertex(_T("南昌"), _T("KHN"), 625, 500);
    int cs  = AddVertex(_T("长沙"), _T("CSX"), 545, 520);

    int cd  = AddVertex(_T("成都"), _T("CTU"), 360, 430);
    int cq  = AddVertex(_T("重庆"), _T("CKG"), 420, 480);
    int gy  = AddVertex(_T("贵阳"), _T("KWE"), 430, 560);
    int km  = AddVertex(_T("昆明"), _T("KMG"), 330, 610);

    int gz  = AddVertex(_T("广州"), _T("CAN"), 590, 615);
    int sz  = AddVertex(_T("深圳"), _T("SZX"), 655, 655);
    int nn  = AddVertex(_T("南宁"), _T("NNG"), 470, 650);
    int hk  = AddVertex(_T("海口"), _T("HAK"), 585, 720);

    // ================= 华北线路 =================

    // 北京 -> 天津
    ArcNode* bj_tj_f = AddArc(bj, tj, 130, TYPE_FLIGHT);
    AddSchedule(bj_tj_f, _T("CA101"), TimeToMin(_T("08:00")), TimeToMin(_T("08:50")), 360);
    AddSchedule(bj_tj_f, _T("CA103"), TimeToMin(_T("16:00")), TimeToMin(_T("16:50")), 320);

    ArcNode* bj_tj_t = AddArc(bj, tj, 130, TYPE_TRAIN);
    AddSchedule(bj_tj_t, _T("C201"), TimeToMin(_T("07:00")), TimeToMin(_T("07:35")), 55);
    AddSchedule(bj_tj_t, _T("C205"), TimeToMin(_T("14:00")), TimeToMin(_T("14:35")), 55);

    // 天津 -> 北京
    ArcNode* tj_bj_f = AddArc(tj, bj, 130, TYPE_FLIGHT);
    AddSchedule(tj_bj_f, _T("CA102"), TimeToMin(_T("09:30")), TimeToMin(_T("10:20")), 360);
    AddSchedule(tj_bj_f, _T("CA104"), TimeToMin(_T("18:00")), TimeToMin(_T("18:50")), 320);

    ArcNode* tj_bj_t = AddArc(tj, bj, 130, TYPE_TRAIN);
    AddSchedule(tj_bj_t, _T("C202"), TimeToMin(_T("08:00")), TimeToMin(_T("08:35")), 55);
    AddSchedule(tj_bj_t, _T("C206"), TimeToMin(_T("15:00")), TimeToMin(_T("15:35")), 55);

    // 北京 -> 石家庄
    ArcNode* bj_sjz_f = AddArc(bj, sjz, 290, TYPE_FLIGHT);
    AddSchedule(bj_sjz_f, _T("CA111"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 420);

    ArcNode* bj_sjz_t = AddArc(bj, sjz, 290, TYPE_TRAIN);
    AddSchedule(bj_sjz_t, _T("G671"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 128);
    AddSchedule(bj_sjz_t, _T("G673"), TimeToMin(_T("15:00")), TimeToMin(_T("16:20")), 128);

    // 石家庄 -> 北京
    ArcNode* sjz_bj_f = AddArc(sjz, bj, 290, TYPE_FLIGHT);
    AddSchedule(sjz_bj_f, _T("CA112"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* sjz_bj_t = AddArc(sjz, bj, 290, TYPE_TRAIN);
    AddSchedule(sjz_bj_t, _T("G672"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 128);
    AddSchedule(sjz_bj_t, _T("G674"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 128);

    // 石家庄 -> 太原
    ArcNode* sjz_ty_f = AddArc(sjz, ty, 230, TYPE_FLIGHT);
    AddSchedule(sjz_ty_f, _T("NS301"), TimeToMin(_T("10:30")), TimeToMin(_T("11:20")), 380);

    ArcNode* sjz_ty_t = AddArc(sjz, ty, 230, TYPE_TRAIN);
    AddSchedule(sjz_ty_t, _T("D1601"), TimeToMin(_T("09:00")), TimeToMin(_T("10:25")), 85);
    AddSchedule(sjz_ty_t, _T("D1603"), TimeToMin(_T("16:00")), TimeToMin(_T("17:25")), 85);

    // 太原 -> 石家庄
    ArcNode* ty_sjz_f = AddArc(ty, sjz, 230, TYPE_FLIGHT);
    AddSchedule(ty_sjz_f, _T("NS302"), TimeToMin(_T("12:30")), TimeToMin(_T("13:20")), 380);

    ArcNode* ty_sjz_t = AddArc(ty, sjz, 230, TYPE_TRAIN);
    AddSchedule(ty_sjz_t, _T("D1602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:25")), 85);
    AddSchedule(ty_sjz_t, _T("D1604"), TimeToMin(_T("18:00")), TimeToMin(_T("19:25")), 85);

    // 太原 -> 呼和浩特
    ArcNode* ty_hh_f = AddArc(ty, hh, 430, TYPE_FLIGHT);
    AddSchedule(ty_hh_f, _T("HU401"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 520);

    ArcNode* ty_hh_t = AddArc(ty, hh, 430, TYPE_TRAIN);
    AddSchedule(ty_hh_t, _T("K1111"), TimeToMin(_T("19:00")), TimeToMin(_T("23:50")), 120);

    // 呼和浩特 -> 太原
    ArcNode* hh_ty_f = AddArc(hh, ty, 430, TYPE_FLIGHT);
    AddSchedule(hh_ty_f, _T("HU402"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 520);

    ArcNode* hh_ty_t = AddArc(hh, ty, 430, TYPE_TRAIN);
    AddSchedule(hh_ty_t, _T("K1112"), TimeToMin(_T("20:00")), TimeToMin(_T("20:00")) + 290, 120);

    // ================= 东北线路 =================

    // 北京 -> 沈阳
    ArcNode* bj_sy_f = AddArc(bj, sy, 700, TYPE_FLIGHT);
    AddSchedule(bj_sy_f, _T("CA1601"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 650);
    AddSchedule(bj_sy_f, _T("CA1603"), TimeToMin(_T("17:00")), TimeToMin(_T("18:30")), 600);

    ArcNode* bj_sy_t = AddArc(bj, sy, 700, TYPE_TRAIN);
    AddSchedule(bj_sy_t, _T("G901"), TimeToMin(_T("07:40")), TimeToMin(_T("11:20")), 295);
    AddSchedule(bj_sy_t, _T("G905"), TimeToMin(_T("14:00")), TimeToMin(_T("17:40")), 295);

    // 沈阳 -> 北京
    ArcNode* sy_bj_f = AddArc(sy, bj, 700, TYPE_FLIGHT);
    AddSchedule(sy_bj_f, _T("CA1602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:30")), 650);
    AddSchedule(sy_bj_f, _T("CA1604"), TimeToMin(_T("19:00")), TimeToMin(_T("20:30")), 600);

    ArcNode* sy_bj_t = AddArc(sy, bj, 700, TYPE_TRAIN);
    AddSchedule(sy_bj_t, _T("G902"), TimeToMin(_T("08:00")), TimeToMin(_T("11:40")), 295);
    AddSchedule(sy_bj_t, _T("G906"), TimeToMin(_T("15:00")), TimeToMin(_T("18:40")), 295);

    // 沈阳 -> 大连
    ArcNode* sy_dl_f = AddArc(sy, dl, 380, TYPE_FLIGHT);
    AddSchedule(sy_dl_f, _T("CZ6411"), TimeToMin(_T("10:00")), TimeToMin(_T("11:00")), 420);

    ArcNode* sy_dl_t = AddArc(sy, dl, 380, TYPE_TRAIN);
    AddSchedule(sy_dl_t, _T("G8001"), TimeToMin(_T("08:00")), TimeToMin(_T("10:00")), 175);
    AddSchedule(sy_dl_t, _T("G8005"), TimeToMin(_T("14:00")), TimeToMin(_T("16:00")), 175);

    // 大连 -> 沈阳
    ArcNode* dl_sy_f = AddArc(dl, sy, 380, TYPE_FLIGHT);
    AddSchedule(dl_sy_f, _T("CZ6412"), TimeToMin(_T("12:00")), TimeToMin(_T("13:00")), 420);

    ArcNode* dl_sy_t = AddArc(dl, sy, 380, TYPE_TRAIN);
    AddSchedule(dl_sy_t, _T("G8002"), TimeToMin(_T("09:00")), TimeToMin(_T("11:00")), 175);
    AddSchedule(dl_sy_t, _T("G8006"), TimeToMin(_T("15:00")), TimeToMin(_T("17:00")), 175);

    // 沈阳 -> 长春
    ArcNode* sy_cc_f = AddArc(sy, cc, 310, TYPE_FLIGHT);
    AddSchedule(sy_cc_f, _T("CZ6511"), TimeToMin(_T("09:20")), TimeToMin(_T("10:10")), 400);

    ArcNode* sy_cc_t = AddArc(sy, cc, 310, TYPE_TRAIN);
    AddSchedule(sy_cc_t, _T("G8011"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 145);
    AddSchedule(sy_cc_t, _T("G8013"), TimeToMin(_T("16:30")), TimeToMin(_T("18:00")), 145);

    // 长春 -> 沈阳
    ArcNode* cc_sy_f = AddArc(cc, sy, 310, TYPE_FLIGHT);
    AddSchedule(cc_sy_f, _T("CZ6512"), TimeToMin(_T("11:00")), TimeToMin(_T("11:50")), 400);

    ArcNode* cc_sy_t = AddArc(cc, sy, 310, TYPE_TRAIN);
    AddSchedule(cc_sy_t, _T("G8012"), TimeToMin(_T("10:30")), TimeToMin(_T("12:00")), 145);
    AddSchedule(cc_sy_t, _T("G8014"), TimeToMin(_T("18:30")), TimeToMin(_T("20:00")), 145);

    // 长春 -> 哈尔滨
    ArcNode* cc_hrb_f = AddArc(cc, hrb, 250, TYPE_FLIGHT);
    AddSchedule(cc_hrb_f, _T("CZ6611"), TimeToMin(_T("08:50")), TimeToMin(_T("09:40")), 380);

    ArcNode* cc_hrb_t = AddArc(cc, hrb, 250, TYPE_TRAIN);
    AddSchedule(cc_hrb_t, _T("G1201"), TimeToMin(_T("09:00")), TimeToMin(_T("10:20")), 110);
    AddSchedule(cc_hrb_t, _T("G1203"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 110);

    // 哈尔滨 -> 长春
    ArcNode* hrb_cc_f = AddArc(hrb, cc, 250, TYPE_FLIGHT);
    AddSchedule(hrb_cc_f, _T("CZ6612"), TimeToMin(_T("10:30")), TimeToMin(_T("11:20")), 380);

    ArcNode* hrb_cc_t = AddArc(hrb, cc, 250, TYPE_TRAIN);
    AddSchedule(hrb_cc_t, _T("G1202"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 110);
    AddSchedule(hrb_cc_t, _T("G1204"), TimeToMin(_T("19:00")), TimeToMin(_T("20:20")), 110);
        // ================= 华东线路 =================

    // 北京 -> 济南
    ArcNode* bj_jn_f = AddArc(bj, jn, 420, TYPE_FLIGHT);
    AddSchedule(bj_jn_f, _T("CA201"), TimeToMin(_T("08:20")), TimeToMin(_T("09:30")), 520);
    AddSchedule(bj_jn_f, _T("CA203"), TimeToMin(_T("16:20")), TimeToMin(_T("17:30")), 480);

    ArcNode* bj_jn_t = AddArc(bj, jn, 420, TYPE_TRAIN);
    AddSchedule(bj_jn_t, _T("G101"), TimeToMin(_T("07:00")), TimeToMin(_T("08:40")), 185);
    AddSchedule(bj_jn_t, _T("G103"), TimeToMin(_T("14:00")), TimeToMin(_T("15:40")), 185);

    // 济南 -> 北京
    ArcNode* jn_bj_f = AddArc(jn, bj, 420, TYPE_FLIGHT);
    AddSchedule(jn_bj_f, _T("CA202"), TimeToMin(_T("10:20")), TimeToMin(_T("11:30")), 520);

    ArcNode* jn_bj_t = AddArc(jn, bj, 420, TYPE_TRAIN);
    AddSchedule(jn_bj_t, _T("G102"), TimeToMin(_T("09:20")), TimeToMin(_T("11:00")), 185);
    AddSchedule(jn_bj_t, _T("G104"), TimeToMin(_T("17:20")), TimeToMin(_T("19:00")), 185);

    // 济南 -> 青岛
    ArcNode* jn_qd_f = AddArc(jn, qd, 360, TYPE_FLIGHT);
    AddSchedule(jn_qd_f, _T("SC801"), TimeToMin(_T("09:00")), TimeToMin(_T("09:50")), 390);

    ArcNode* jn_qd_t = AddArc(jn, qd, 360, TYPE_TRAIN);
    AddSchedule(jn_qd_t, _T("G221"), TimeToMin(_T("08:30")), TimeToMin(_T("10:10")), 121);
    AddSchedule(jn_qd_t, _T("G223"), TimeToMin(_T("15:30")), TimeToMin(_T("17:10")), 121);

    // 青岛 -> 济南
    ArcNode* qd_jn_f = AddArc(qd, jn, 360, TYPE_FLIGHT);
    AddSchedule(qd_jn_f, _T("SC802"), TimeToMin(_T("11:00")), TimeToMin(_T("11:50")), 390);

    ArcNode* qd_jn_t = AddArc(qd, jn, 360, TYPE_TRAIN);
    AddSchedule(qd_jn_t, _T("G222"), TimeToMin(_T("11:00")), TimeToMin(_T("12:40")), 121);
    AddSchedule(qd_jn_t, _T("G224"), TimeToMin(_T("18:00")), TimeToMin(_T("19:40")), 121);

    // 南京 -> 上海
    ArcNode* nj_sh_f = AddArc(nj, sh, 300, TYPE_FLIGHT);
    AddSchedule(nj_sh_f, _T("MU2801"), TimeToMin(_T("09:30")), TimeToMin(_T("10:30")), 420);

    ArcNode* nj_sh_t = AddArc(nj, sh, 300, TYPE_TRAIN);
    AddSchedule(nj_sh_t, _T("G7001"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 135);
    AddSchedule(nj_sh_t, _T("G7003"), TimeToMin(_T("14:00")), TimeToMin(_T("15:20")), 135);

    // 上海 -> 南京
    ArcNode* sh_nj_f = AddArc(sh, nj, 300, TYPE_FLIGHT);
    AddSchedule(sh_nj_f, _T("MU2802"), TimeToMin(_T("11:30")), TimeToMin(_T("12:30")), 420);

    ArcNode* sh_nj_t = AddArc(sh, nj, 300, TYPE_TRAIN);
    AddSchedule(sh_nj_t, _T("G7002"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 135);
    AddSchedule(sh_nj_t, _T("G7004"), TimeToMin(_T("16:00")), TimeToMin(_T("17:20")), 135);

    // 上海 -> 杭州
    ArcNode* sh_hz_f = AddArc(sh, hz, 180, TYPE_FLIGHT);
    AddSchedule(sh_hz_f, _T("FM911"), TimeToMin(_T("09:20")), TimeToMin(_T("10:00")), 360);

    ArcNode* sh_hz_t = AddArc(sh, hz, 180, TYPE_TRAIN);
    AddSchedule(sh_hz_t, _T("G7311"), TimeToMin(_T("08:00")), TimeToMin(_T("09:00")), 73);
    AddSchedule(sh_hz_t, _T("G7313"), TimeToMin(_T("15:00")), TimeToMin(_T("16:00")), 73);

    // 杭州 -> 上海
    ArcNode* hz_sh_f = AddArc(hz, sh, 180, TYPE_FLIGHT);
    AddSchedule(hz_sh_f, _T("FM912"), TimeToMin(_T("11:20")), TimeToMin(_T("12:00")), 360);

    ArcNode* hz_sh_t = AddArc(hz, sh, 180, TYPE_TRAIN);
    AddSchedule(hz_sh_t, _T("G7312"), TimeToMin(_T("10:00")), TimeToMin(_T("11:00")), 73);
    AddSchedule(hz_sh_t, _T("G7314"), TimeToMin(_T("17:00")), TimeToMin(_T("18:00")), 73);

    // 南京 -> 合肥
    ArcNode* nj_hf_t = AddArc(nj, hf, 180, TYPE_TRAIN);
    AddSchedule(nj_hf_t, _T("G7251"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 86);

    ArcNode* hf_nj_t = AddArc(hf, nj, 180, TYPE_TRAIN);
    AddSchedule(hf_nj_t, _T("G7252"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 86);

    // ================= 华中线路 =================

    // 郑州 -> 武汉
    ArcNode* zz_wh_f = AddArc(zz, wh, 520, TYPE_FLIGHT);
    AddSchedule(zz_wh_f, _T("CZ8801"), TimeToMin(_T("09:00")), TimeToMin(_T("10:10")), 500);

    ArcNode* zz_wh_t = AddArc(zz, wh, 520, TYPE_TRAIN);
    AddSchedule(zz_wh_t, _T("G551"), TimeToMin(_T("08:00")), TimeToMin(_T("10:00")), 244);
    AddSchedule(zz_wh_t, _T("G553"), TimeToMin(_T("15:00")), TimeToMin(_T("17:00")), 244);

    // 武汉 -> 郑州
    ArcNode* wh_zz_f = AddArc(wh, zz, 520, TYPE_FLIGHT);
    AddSchedule(wh_zz_f, _T("CZ8802"), TimeToMin(_T("11:00")), TimeToMin(_T("12:10")), 500);

    ArcNode* wh_zz_t = AddArc(wh, zz, 520, TYPE_TRAIN);
    AddSchedule(wh_zz_t, _T("G552"), TimeToMin(_T("10:30")), TimeToMin(_T("12:30")), 244);
    AddSchedule(wh_zz_t, _T("G554"), TimeToMin(_T("18:00")), TimeToMin(_T("20:00")), 244);

    // 武汉 -> 长沙
    ArcNode* wh_cs_f = AddArc(wh, cs, 350, TYPE_FLIGHT);
    AddSchedule(wh_cs_f, _T("CZ8811"), TimeToMin(_T("08:30")), TimeToMin(_T("09:30")), 420);

    ArcNode* wh_cs_t = AddArc(wh, cs, 350, TYPE_TRAIN);
    AddSchedule(wh_cs_t, _T("G601"), TimeToMin(_T("09:00")), TimeToMin(_T("10:30")), 164);
    AddSchedule(wh_cs_t, _T("G603"), TimeToMin(_T("16:00")), TimeToMin(_T("17:30")), 164);

    // 长沙 -> 武汉
    ArcNode* cs_wh_f = AddArc(cs, wh, 350, TYPE_FLIGHT);
    AddSchedule(cs_wh_f, _T("CZ8812"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* cs_wh_t = AddArc(cs, wh, 350, TYPE_TRAIN);
    AddSchedule(cs_wh_t, _T("G602"), TimeToMin(_T("11:00")), TimeToMin(_T("12:30")), 164);
    AddSchedule(cs_wh_t, _T("G604"), TimeToMin(_T("18:00")), TimeToMin(_T("19:30")), 164);

    // 武汉 -> 南昌
    ArcNode* wh_nc_t = AddArc(wh, nc, 340, TYPE_TRAIN);
    AddSchedule(wh_nc_t, _T("D321"), TimeToMin(_T("09:00")), TimeToMin(_T("11:00")), 150);

    // 南昌 -> 武汉
    ArcNode* nc_wh_t = AddArc(nc, wh, 340, TYPE_TRAIN);
    AddSchedule(nc_wh_t, _T("D322"), TimeToMin(_T("13:00")), TimeToMin(_T("15:00")), 150);

    // 武汉 -> 上海
    ArcNode* wh_sh_f = AddArc(wh, sh, 820, TYPE_FLIGHT);
    AddSchedule(wh_sh_f, _T("MU5101"), TimeToMin(_T("08:30")), TimeToMin(_T("10:00")), 690);

    ArcNode* wh_sh_t = AddArc(wh, sh, 820, TYPE_TRAIN);
    AddSchedule(wh_sh_t, _T("G1722"), TimeToMin(_T("08:00")), TimeToMin(_T("12:30")), 370);

    // 上海 -> 武汉
    ArcNode* sh_wh_f = AddArc(sh, wh, 820, TYPE_FLIGHT);
    AddSchedule(sh_wh_f, _T("MU5102"), TimeToMin(_T("11:30")), TimeToMin(_T("13:00")), 690);

    ArcNode* sh_wh_t = AddArc(sh, wh, 820, TYPE_TRAIN);
    AddSchedule(sh_wh_t, _T("G1723"), TimeToMin(_T("14:00")), TimeToMin(_T("18:30")), 370);
        // ================= 华南线路 =================

    // 长沙 -> 广州
    ArcNode* cs_gz_f = AddArc(cs, gz, 670, TYPE_FLIGHT);
    AddSchedule(cs_gz_f, _T("CZ3011"), TimeToMin(_T("09:00")), TimeToMin(_T("10:20")), 560);

    ArcNode* cs_gz_t = AddArc(cs, gz, 670, TYPE_TRAIN);
    AddSchedule(cs_gz_t, _T("G801"), TimeToMin(_T("08:00")), TimeToMin(_T("10:45")), 314);
    AddSchedule(cs_gz_t, _T("G803"), TimeToMin(_T("15:00")), TimeToMin(_T("17:45")), 314);

    // 广州 -> 长沙
    ArcNode* gz_cs_f = AddArc(gz, cs, 670, TYPE_FLIGHT);
    AddSchedule(gz_cs_f, _T("CZ3012"), TimeToMin(_T("11:30")), TimeToMin(_T("12:50")), 560);

    ArcNode* gz_cs_t = AddArc(gz, cs, 670, TYPE_TRAIN);
    AddSchedule(gz_cs_t, _T("G802"), TimeToMin(_T("11:30")), TimeToMin(_T("14:15")), 314);
    AddSchedule(gz_cs_t, _T("G804"), TimeToMin(_T("18:30")), TimeToMin(_T("21:15")), 314);

    // 广州 -> 深圳
    ArcNode* gz_sz_t = AddArc(gz, sz, 140, TYPE_TRAIN);
    AddSchedule(gz_sz_t, _T("G6501"), TimeToMin(_T("08:00")), TimeToMin(_T("08:40")), 75);
    AddSchedule(gz_sz_t, _T("G6503"), TimeToMin(_T("16:00")), TimeToMin(_T("16:40")), 75);

    ArcNode* sz_gz_t = AddArc(sz, gz, 140, TYPE_TRAIN);
    AddSchedule(sz_gz_t, _T("G6502"), TimeToMin(_T("09:00")), TimeToMin(_T("09:40")), 75);
    AddSchedule(sz_gz_t, _T("G6504"), TimeToMin(_T("17:00")), TimeToMin(_T("17:40")), 75);

    // 广州 -> 南宁
    ArcNode* gz_nn_f = AddArc(gz, nn, 560, TYPE_FLIGHT);
    AddSchedule(gz_nn_f, _T("CZ3291"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 530);

    ArcNode* gz_nn_t = AddArc(gz, nn, 560, TYPE_TRAIN);
    AddSchedule(gz_nn_t, _T("D3601"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 210);

    // 南宁 -> 广州
    ArcNode* nn_gz_f = AddArc(nn, gz, 560, TYPE_FLIGHT);
    AddSchedule(nn_gz_f, _T("CZ3292"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 530);

    ArcNode* nn_gz_t = AddArc(nn, gz, 560, TYPE_TRAIN);
    AddSchedule(nn_gz_t, _T("D3602"), TimeToMin(_T("14:00")), TimeToMin(_T("17:30")), 210);

    // 广州 -> 海口
    ArcNode* gz_hk_f = AddArc(gz, hk, 600, TYPE_FLIGHT);
    AddSchedule(gz_hk_f, _T("CZ6771"), TimeToMin(_T("10:00")), TimeToMin(_T("11:25")), 620);
    AddSchedule(gz_hk_f, _T("CZ6773"), TimeToMin(_T("18:00")), TimeToMin(_T("19:25")), 580);

    ArcNode* hk_gz_f = AddArc(hk, gz, 600, TYPE_FLIGHT);
    AddSchedule(hk_gz_f, _T("CZ6772"), TimeToMin(_T("12:30")), TimeToMin(_T("13:55")), 620);
    AddSchedule(hk_gz_f, _T("CZ6774"), TimeToMin(_T("20:30")), TimeToMin(_T("21:55")), 580);

    // ================= 西南线路 =================

    // 武汉 -> 重庆
    ArcNode* wh_cq_f = AddArc(wh, cq, 870, TYPE_FLIGHT);
    AddSchedule(wh_cq_f, _T("CA4301"), TimeToMin(_T("09:30")), TimeToMin(_T("11:10")), 680);

    ArcNode* wh_cq_t = AddArc(wh, cq, 870, TYPE_TRAIN);
    AddSchedule(wh_cq_t, _T("D2231"), TimeToMin(_T("08:00")), TimeToMin(_T("14:30")), 260);

    // 重庆 -> 武汉
    ArcNode* cq_wh_f = AddArc(cq, wh, 870, TYPE_FLIGHT);
    AddSchedule(cq_wh_f, _T("CA4302"), TimeToMin(_T("12:30")), TimeToMin(_T("14:10")), 680);

    ArcNode* cq_wh_t = AddArc(cq, wh, 870, TYPE_TRAIN);
    AddSchedule(cq_wh_t, _T("D2232"), TimeToMin(_T("15:30")), TimeToMin(_T("22:00")), 260);

    // 重庆 -> 成都
    ArcNode* cq_cd_t = AddArc(cq, cd, 310, TYPE_TRAIN);
    AddSchedule(cq_cd_t, _T("G8501"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 146);
    AddSchedule(cq_cd_t, _T("G8503"), TimeToMin(_T("15:00")), TimeToMin(_T("16:20")), 146);

    ArcNode* cd_cq_t = AddArc(cd, cq, 310, TYPE_TRAIN);
    AddSchedule(cd_cq_t, _T("G8502"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 146);
    AddSchedule(cd_cq_t, _T("G8504"), TimeToMin(_T("17:00")), TimeToMin(_T("18:20")), 146);

    // 重庆 -> 贵阳
    ArcNode* cq_gy_f = AddArc(cq, gy, 380, TYPE_FLIGHT);
    AddSchedule(cq_gy_f, _T("3U8511"), TimeToMin(_T("09:00")), TimeToMin(_T("10:00")), 420);

    ArcNode* cq_gy_t = AddArc(cq, gy, 380, TYPE_TRAIN);
    AddSchedule(cq_gy_t, _T("D8551"), TimeToMin(_T("08:30")), TimeToMin(_T("10:40")), 130);

    ArcNode* gy_cq_f = AddArc(gy, cq, 380, TYPE_FLIGHT);
    AddSchedule(gy_cq_f, _T("3U8512"), TimeToMin(_T("11:00")), TimeToMin(_T("12:00")), 420);

    ArcNode* gy_cq_t = AddArc(gy, cq, 380, TYPE_TRAIN);
    AddSchedule(gy_cq_t, _T("D8552"), TimeToMin(_T("13:00")), TimeToMin(_T("15:10")), 130);

    // 贵阳 -> 昆明
    ArcNode* gy_km_f = AddArc(gy, km, 520, TYPE_FLIGHT);
    AddSchedule(gy_km_f, _T("MU5901"), TimeToMin(_T("10:00")), TimeToMin(_T("11:10")), 500);

    ArcNode* gy_km_t = AddArc(gy, km, 520, TYPE_TRAIN);
    AddSchedule(gy_km_t, _T("G2831"), TimeToMin(_T("09:00")), TimeToMin(_T("11:30")), 212);

    ArcNode* km_gy_f = AddArc(km, gy, 520, TYPE_FLIGHT);
    AddSchedule(km_gy_f, _T("MU5902"), TimeToMin(_T("12:00")), TimeToMin(_T("13:10")), 500);

    ArcNode* km_gy_t = AddArc(km, gy, 520, TYPE_TRAIN);
    AddSchedule(km_gy_t, _T("G2832"), TimeToMin(_T("14:00")), TimeToMin(_T("16:30")), 212);

    // 成都 -> 昆明
    ArcNode* cd_km_f = AddArc(cd, km, 650, TYPE_FLIGHT);
    AddSchedule(cd_km_f, _T("3U8667"), TimeToMin(_T("12:30")), TimeToMin(_T("14:00")), 520);

    ArcNode* cd_km_t = AddArc(cd, km, 650, TYPE_TRAIN);
    AddSchedule(cd_km_t, _T("G2837"), TimeToMin(_T("09:30")), TimeToMin(_T("15:00")), 280);

    ArcNode* km_cd_f = AddArc(km, cd, 650, TYPE_FLIGHT);
    AddSchedule(km_cd_f, _T("3U8668"), TimeToMin(_T("15:00")), TimeToMin(_T("16:30")), 520);

    ArcNode* km_cd_t = AddArc(km, cd, 650, TYPE_TRAIN);
    AddSchedule(km_cd_t, _T("G2838"), TimeToMin(_T("16:00")), TimeToMin(_T("21:30")), 280);

    // ================= 西北线路 =================

    // 郑州 -> 西安
    ArcNode* zz_xa_f = AddArc(zz, xa, 480, TYPE_FLIGHT);
    AddSchedule(zz_xa_f, _T("MU2201"), TimeToMin(_T("09:00")), TimeToMin(_T("10:10")), 480);

    ArcNode* zz_xa_t = AddArc(zz, xa, 480, TYPE_TRAIN);
    AddSchedule(zz_xa_t, _T("G2001"), TimeToMin(_T("08:00")), TimeToMin(_T("10:10")), 230);

    ArcNode* xa_zz_f = AddArc(xa, zz, 480, TYPE_FLIGHT);
    AddSchedule(xa_zz_f, _T("MU2202"), TimeToMin(_T("11:00")), TimeToMin(_T("12:10")), 480);

    ArcNode* xa_zz_t = AddArc(xa, zz, 480, TYPE_TRAIN);
    AddSchedule(xa_zz_t, _T("G2002"), TimeToMin(_T("13:00")), TimeToMin(_T("15:10")), 230);

    // 西安 -> 兰州
    ArcNode* xa_lz_f = AddArc(xa, lz, 630, TYPE_FLIGHT);
    AddSchedule(xa_lz_f, _T("MU2311"), TimeToMin(_T("08:40")), TimeToMin(_T("10:00")), 520);

    ArcNode* xa_lz_t = AddArc(xa, lz, 630, TYPE_TRAIN);
    AddSchedule(xa_lz_t, _T("D2651"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 174);

    ArcNode* lz_xa_f = AddArc(lz, xa, 630, TYPE_FLIGHT);
    AddSchedule(lz_xa_f, _T("MU2312"), TimeToMin(_T("11:00")), TimeToMin(_T("12:20")), 520);

    ArcNode* lz_xa_t = AddArc(lz, xa, 630, TYPE_TRAIN);
    AddSchedule(lz_xa_t, _T("D2652"), TimeToMin(_T("14:00")), TimeToMin(_T("17:30")), 174);

    // 兰州 -> 西宁
    ArcNode* lz_xn_t = AddArc(lz, xn, 220, TYPE_TRAIN);
    AddSchedule(lz_xn_t, _T("D2701"), TimeToMin(_T("08:00")), TimeToMin(_T("09:20")), 58);

    ArcNode* xn_lz_t = AddArc(xn, lz, 220, TYPE_TRAIN);
    AddSchedule(xn_lz_t, _T("D2702"), TimeToMin(_T("10:00")), TimeToMin(_T("11:20")), 58);

    // 兰州 -> 银川
    ArcNode* lz_yc_f = AddArc(lz, yc, 420, TYPE_FLIGHT);
    AddSchedule(lz_yc_f, _T("MU2411"), TimeToMin(_T("09:30")), TimeToMin(_T("10:30")), 420);

    ArcNode* lz_yc_t = AddArc(lz, yc, 420, TYPE_TRAIN);
    AddSchedule(lz_yc_t, _T("K9661"), TimeToMin(_T("18:30")), TimeToMin(_T("23:40")), 95);

    ArcNode* yc_lz_f = AddArc(yc, lz, 420, TYPE_FLIGHT);
    AddSchedule(yc_lz_f, _T("MU2412"), TimeToMin(_T("11:30")), TimeToMin(_T("12:30")), 420);

    ArcNode* yc_lz_t = AddArc(yc, lz, 420, TYPE_TRAIN);
    AddSchedule(yc_lz_t, _T("K9662"), TimeToMin(_T("19:30")), TimeToMin(_T("19:30")) + 310, 95);

    // 兰州 -> 乌鲁木齐
    ArcNode* lz_ur_f = AddArc(lz, ur, 1900, TYPE_FLIGHT);
    AddSchedule(lz_ur_f, _T("CZ6901"), TimeToMin(_T("08:30")), TimeToMin(_T("11:30")), 980);

    ArcNode* lz_ur_t = AddArc(lz, ur, 1900, TYPE_TRAIN);
    AddSchedule(lz_ur_t, _T("Z105"), TimeToMin(_T("19:00")), TimeToMin(_T("19:00")) + 1220, 310);

    ArcNode* ur_lz_f = AddArc(ur, lz, 1900, TYPE_FLIGHT);
    AddSchedule(ur_lz_f, _T("CZ6902"), TimeToMin(_T("12:30")), TimeToMin(_T("15:30")), 980);

    ArcNode* ur_lz_t = AddArc(ur, lz, 1900, TYPE_TRAIN);
    AddSchedule(ur_lz_t, _T("Z106"), TimeToMin(_T("20:00")), TimeToMin(_T("20:00")) + 1220, 310);

    // 北京 -> 西安
    ArcNode* bj_xa_f = AddArc(bj, xa, 1100, TYPE_FLIGHT);
    AddSchedule(bj_xa_f, _T("CA1201"), TimeToMin(_T("08:00")), TimeToMin(_T("10:10")), 760);
    AddSchedule(bj_xa_f, _T("CA1203"), TimeToMin(_T("16:00")), TimeToMin(_T("18:10")), 720);

    ArcNode* bj_xa_t = AddArc(bj, xa, 1100, TYPE_TRAIN);
    AddSchedule(bj_xa_t, _T("G651"), TimeToMin(_T("07:00")), TimeToMin(_T("12:30")), 515);

    ArcNode* xa_bj_f = AddArc(xa, bj, 1100, TYPE_FLIGHT);
    AddSchedule(xa_bj_f, _T("CA1202"), TimeToMin(_T("11:30")), TimeToMin(_T("13:40")), 760);

    ArcNode* xa_bj_t = AddArc(xa, bj, 1100, TYPE_TRAIN);
    AddSchedule(xa_bj_t, _T("G652"), TimeToMin(_T("14:00")), TimeToMin(_T("19:30")), 515);

    // 西安 -> 成都
    ArcNode* xa_cd_f = AddArc(xa, cd, 650, TYPE_FLIGHT);
    AddSchedule(xa_cd_f, _T("MU2205"), TimeToMin(_T("13:00")), TimeToMin(_T("14:30")), 560);

    ArcNode* xa_cd_t = AddArc(xa, cd, 650, TYPE_TRAIN);
    AddSchedule(xa_cd_t, _T("D1921"), TimeToMin(_T("15:00")), TimeToMin(_T("18:30")), 263);

    ArcNode* cd_xa_f = AddArc(cd, xa, 650, TYPE_FLIGHT);
    AddSchedule(cd_xa_f, _T("MU2206"), TimeToMin(_T("15:30")), TimeToMin(_T("17:00")), 560);

    ArcNode* cd_xa_t = AddArc(cd, xa, 650, TYPE_TRAIN);
    AddSchedule(cd_xa_t, _T("D1922"), TimeToMin(_T("09:00")), TimeToMin(_T("12:30")), 263);

    // 收尾：函数结束
}

// ----------------- 核心算法 -----------------
bool SolveSingleLeg(int start, int end, int start_time, bool is_transfer_at_start, int decision, int vehicle, vector<int>& path_out, vector<Schedule*>& sch_out) {
    PathState state[MAX_VERTEX];
    bool in_queue[MAX_VERTEX];
    int queue_arr[MAX_VERTEX * 10];
    int head = 0, tail = 0;

    int min_wait = (vehicle == TYPE_FLIGHT) ? 120 : 60; 

    for (int i = 0; i < G.vexnum; i++) {
        state[i].best_value = INF;
        state[i].pre_vex = -1;
        state[i].chosen_sch = NULL;
        state[i].arrival_time = INF;
        in_queue[i] = false;
    }

    state[start].arrival_time = start_time;
    state[start].best_value = (decision == 1) ? start_time : 0;
    queue_arr[tail++] = start;
    in_queue[start] = true;

    while (head < tail) {
        int u = queue_arr[head++];
        in_queue[u] = false;

        for (ArcNode* arc = G.vertices[u].firstarc; arc != NULL; arc = arc->nextarc) {
            if (arc->type != vehicle) continue;
            int v = arc->adjvex;

            for (Schedule* sch = arc->sch_list; sch != NULL; sch = sch->next) {
                int u_arrival = state[u].arrival_time;
                int buffer = (u == start && !is_transfer_at_start) ? 0 : min_wait;
                int earliest_dep = u_arrival + buffer;

                int day_offset = 0;
                if (sch->dep_time < earliest_dep) {
                    day_offset = ((earliest_dep - sch->dep_time - 1) / 1440 + 1) * 1440;
                }
                int actual_dep = sch->dep_time + day_offset;
                int actual_arr = sch->arr_time + day_offset;

                if (decision == 1) { 
                    if (actual_arr < state[v].best_value) {
                        state[v].best_value = actual_arr;
                        state[v].arrival_time = actual_arr;
                        state[v].pre_vex = u;
                        state[v].chosen_sch = sch;
                        if (!in_queue[v]) {
                            queue_arr[tail++] = v;
                            in_queue[v] = true;
                        }
                    }
                }
                else { 
                    double cost = state[u].best_value + sch->cost;
                    if (cost < state[v].best_value || (cost == state[v].best_value && actual_arr < state[v].arrival_time)) {
                        state[v].best_value = cost;
                        state[v].arrival_time = actual_arr;
                        state[v].pre_vex = u;
                        state[v].chosen_sch = sch;
                        if (!in_queue[v]) {
                            queue_arr[tail++] = v;
                            in_queue[v] = true;
                        }
                    }
                }
            }
        }
    }

    if (state[end].best_value >= INF) return false;

    vector<int> temp_path;
    vector<Schedule*> temp_sch;
    int curr = end;
    while (curr != start) {
        temp_path.push_back(curr);
        temp_sch.push_back(state[curr].chosen_sch);
        curr = state[curr].pre_vex;
    }
    temp_path.push_back(start);

    reverse(temp_path.begin(), temp_path.end());
    reverse(temp_sch.begin(), temp_sch.end());

    path_out = temp_path;
    sch_out = temp_sch;
    return true;
}

struct GlobalResult {
    vector<int> full_path;
    vector<Schedule*> full_schs;
    vector<int> dep_times_absolute;
    vector<int> arr_times_absolute;
    int total_duration;
    double total_cost;
};

GlobalResult SolveWithVias(int start, int end, int start_time, int decision, int vehicle, const vector<int>& vias) {
    GlobalResult best_res;
    best_res.total_duration = INF;
    best_res.total_cost = INF;

    vector<int> perm = vias;
    sort(perm.begin(), perm.end());

    do {
        vector<int> sequence;
        sequence.push_back(start);
        for (size_t i = 0; i < perm.size(); i++) {
            sequence.push_back(perm[i]);
        }
        sequence.push_back(end);

        int current_min = start_time;
        vector<int> combined_path;
        vector<Schedule*> combined_sch;
        vector<int> dep_abs;
        vector<int> arr_abs;
        bool possible = true;

        for (size_t i = 0; i < sequence.size() - 1; i++) {
            int from_node = sequence[i];
            int to_node = sequence[i + 1];
            bool is_transfer = (i > 0); 

            vector<int> sub_path;
            vector<Schedule*> sub_sch;
            if (!SolveSingleLeg(from_node, to_node, current_min, is_transfer, decision, vehicle, sub_path, sub_sch)) {
                possible = false;
                break;
            }

            int u_arrival = current_min;
            int min_wait = (vehicle == TYPE_FLIGHT) ? 120 : 60;
            for (size_t k = 0; k < sub_sch.size(); k++) {
                int buffer = (k == 0 && !is_transfer) ? 0 : min_wait;
                int earliest_dep = u_arrival + buffer;
                int day_offset = 0;
                if (sub_sch[k]->dep_time < earliest_dep) {
                    day_offset = ((earliest_dep - sub_sch[k]->dep_time - 1) / 1440 + 1) * 1440;
                }
                int actual_dep = sub_sch[k]->dep_time + day_offset;
                int actual_arr = sub_sch[k]->arr_time + day_offset;

                dep_abs.push_back(actual_dep);
                arr_abs.push_back(actual_arr);
                u_arrival = actual_arr;
            }

            if (combined_path.empty()) {
                combined_path = sub_path;
            }
            else {
                for (size_t k = 1; k < sub_path.size(); k++) combined_path.push_back(sub_path[k]);
            }
            for (auto* s : sub_sch) combined_sch.push_back(s);

            current_min = u_arrival;
        }

        if (possible) {
            int duration = current_min - start_time;
            double cost = 0;
            for (auto* s : combined_sch) cost += s->cost;

            bool is_better = false;
            if (best_res.total_duration == INF) {
                is_better = true;
            }
            else if (decision == 1) { 
                if (duration < best_res.total_duration) is_better = true;
            }
            else { 
                if (cost < best_res.total_cost) is_better = true;
            }

            if (is_better) {
                best_res.full_path = combined_path;
                best_res.full_schs = combined_sch;
                best_res.dep_times_absolute = dep_abs;
                best_res.arr_times_absolute = arr_abs;
                best_res.total_duration = duration;
                best_res.total_cost = cost;
            }
        }

    } while (next_permutation(perm.begin(), perm.end()));

    return best_res;
}

// ----------------- 交互式数据编辑 -----------------
void InteractiveEditNetwork() {
    HWND hwnd = GetHWnd();
    int msg_choice = MessageBox(hwnd, 
        _T("即将开启图形引导录入。系统会自动检测城市是否存在，若不存在将引导您设定该城市在地图上的显示坐标及三字代码。是否继续？"), 
        _T("智能网络数据管理器"), MB_YESNO | MB_ICONINFORMATION);
        
    if (msg_choice != IDYES) return;

    TCHAR src_name[30] = {0}, dest_name[30] = {0}, no[20] = {0};
    TCHAR dep_str[10] = {0}, arr_str[10] = {0}, vehicle_str[10] = {0};
    TCHAR dist_str[10] = {0}, cost_str[10] = {0};
    TCHAR x_str[10] = {0}, y_str[10] = {0}, code_str[10] = {0};

    // 1. 输入起点城市
    if (!InputBox(src_name, 30, _T("请输入起点城市名称（如：成都）："), _T("添加联动关系 - [1/9] 起点名称"))) return;
    int u = LocateVex(src_name);
    if (u == -1) {
        TCHAR hint[100];
        _stprintf_s(hint, 100, _T("检测到城市 [%s] 尚不存在。请输入其三字英文代码/简称（如：CTU）："), src_name);
        if (!InputBox(code_str, 10, hint, _T("自动创建起点节点 - [1/3] 三字码"))) return;
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 X 像素坐标\n(当前大地图有效范围：0 到 %d)："), src_name, MAP_AREA_MAX-20);
        if (!InputBox(x_str, 10, hint, _T("自动创建起点节点 - [2/3] X坐标"), _T("300"))) return;
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 Y 像素坐标\n(当前大地图有效范围：0 到 600)："), src_name);
        if (!InputBox(y_str, 10, hint, _T("自动创建起点节点 - [3/3] Y坐标"), _T("300"))) return;

        int nx = _ttoi(x_str);
        int ny = _ttoi(y_str);
        u = AddVertex(src_name, code_str, nx, ny);
        if (u == -1) { MessageBox(hwnd, _T("错误：网络图城市节点数量已达上限！"), _T("错误"), MB_OK | MB_ICONERROR); return; }
    }

    // 2. 输入终点城市
    if (!InputBox(dest_name, 30, _T("请输入终点城市名称（如：北京）："), _T("添加联动关系 - [2/9] 终点名称"))) return;
    int v = LocateVex(dest_name);
    if (v == -1) {
        TCHAR hint[100];
        _stprintf_s(hint, 100, _T("检测到城市 [%s] 尚不存在。请输入其三字英文代码/简称（如：BJS）："), dest_name);
        if (!InputBox(code_str, 10, hint, _T("自动创建终点节点 - [1/3] 三字码"))) return;
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 X 像素坐标\n(当前大地图有效范围：0 到 %d)："), dest_name, MAP_AREA_MAX-20);
        if (!InputBox(x_str, 10, hint, _T("自动创建终点节点 - [2/3] X坐标"), _T("400"))) return;
        
        _stprintf_s(hint, 100, _T("请输入 [%s] 在地图上的 Y 像素坐标\n(当前大地图有效范围：0 到 600)："), dest_name);
        if (!InputBox(y_str, 10, hint, _T("自动创建终点节点 - [3/3] Y坐标"), _T("250"))) return;

        int nx = _ttoi(x_str);
        int ny = _ttoi(y_str);
        v = AddVertex(dest_name, code_str, nx, ny);
        if (v == -1) { MessageBox(hwnd, _T("错误：网络图城市节点数量已达上限！"), _T("错误"), MB_OK | MB_ICONERROR); return; }
    }

    if (u == v) {
        MessageBox(hwnd, _T("起点和终点不能为同一城市！"), _T("录入失败"), MB_OK | MB_ICONWARNING);
        return;
    }

    // 3. 交通工具选择
    if (!InputBox(vehicle_str, 10, _T("请输入交通工具类型：\n输入 1 代表 [飞机]\n输入 2 代表 [火车]"), _T("添加联动关系 - [3/9] 载具类型"), _T("1"))) return;
    int vehicle = _ttoi(vehicle_str);
    if (vehicle != 1 && vehicle != 2) {
        MessageBox(hwnd, _T("无效的工具类型！必须输入 1(飞机) 或 2(火车)。"), _T("录入失败"), MB_OK | MB_ICONWARNING);
        return;
    }

    // 4. 里程输入
    if (!InputBox(dist_str, 10, _T("请输入两城市间的里程距离（公里）："), _T("添加联动关系 - [4/9] 里程"), _T("1000"))) return;
    int distance = _ttoi(dist_str);

    // 5. 班次/航班号
    if (!InputBox(no, 20, _T("请输入航班号或列车车次（如：3U8881 / G102）："), _T("添加联动关系 - [5/9] 班次编号"))) return;

    // 6. 出发时间
    if (!InputBox(dep_str, 10, _T("请输入预计出发时间\n格式为 hh:mm（如：08:30）："), _T("添加联动关系 - [6/9] 出发时间"))) return;

    // 7. 到达时间
    if (!InputBox(arr_str, 10, _T("请输入预计到达时间\n格式为 hh:mm（如：11:45）："), _T("添加联动关系 - [7/9] 到达时间"))) return;

    // 8. 价格票价
    if (!InputBox(cost_str, 10, _T("请输入单人标准票价（元）："), _T("添加联动关系 - [8/9] 票价旅资"))) return;
    double cost = _tcstod(cost_str, NULL);

    int dep_min = TimeToMin(dep_str);
    int arr_min = TimeToMin(arr_str);
    if (arr_min < dep_min) {
        arr_min += 1440;
    }

    ArcNode* arc = AddArc(u, v, distance, vehicle);
    AddSchedule(arc, no, dep_min, arr_min, cost);

    TCHAR success_msg[200];
    _stprintf_s(success_msg, 200, _T("【成功】[%s] 经由 [%s] 至 [%s] 的交通运输大通道以及车次 [%s] 已实时成功注入图形网络中！"), src_name, vehicle == 1 ? _T("航空") : _T("铁路"), dest_name, no);
    MessageBox(hwnd, success_msg, _T("数据添加成功"), MB_OK | MB_ICONINFORMATION);
}

// ----------------- UI渲染工具函数 -----------------
bool IsInCircle(int mx, int my, int cx, int cy, int r) {
    return (mx - cx) * (mx - cx) + (my - cy) * (my - cy) <= r * r;
}

bool IsInRect(int mx, int my, int rx1, int ry1, int rx2, int ry2) {
    return mx >= rx1 && mx <= rx2 && my >= ry1 && my <= ry2;
}

void DrawButton(const TCHAR* label, int x1, int y1, int x2, int y2, bool active) {
    if (active) {
        setfillcolor(RGB(30, 41, 59)); 
        setlinecolor(RGB(34, 197, 94)); 
    }
    else {
        setfillcolor(RGB(241, 245, 249)); 
        setlinecolor(RGB(203, 213, 225));
    }
    fillroundrect(x1, y1, x2, y2, 8, 8);
    settextcolor(active ? WHITE : RGB(71, 85, 105));
    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);
    setbkmode(TRANSPARENT);
    int w = textwidth(label);
    int h = textheight(label);
    outtextxy(x1 + (x2 - x1 - w) / 2, y1 + (y2 - y1 - h) / 2, label);
}

void DrawArrow(int x1, int y1, int x2, int y2, COLORREF color) {
    setlinecolor(color);
    setlinestyle(PS_SOLID, 3);
    line(x1, y1, x2, y2);

    double angle = atan2(y2 - y1, x2 - x1);
    int r = 12;
    int ax1 = x2 - (int)(r * cos(angle - 0.4));
    int ay1 = y2 - (int)(r * sin(angle - 0.4));
    int ax2 = x2 - (int)(r * cos(angle + 0.4));
    int ay2 = y2 - (int)(r * sin(angle + 0.4));
    line(x2, y2, ax1, ay1);
    line(x2, y2, ax2, ay2);
}

// ----------------- 渲染函数（优化布局） -----------------
void Render(int start_node, int end_node, const vector<int>& vias, int vehicle, int decision, int hour, int minute, const GlobalResult& route_res) {
    // 1. 清空背景（地图区+侧边栏）
    setfillcolor(RGB(248, 250, 252));
    solidrectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // 2. 绘制地图区网格（仅0-MAP_AREA_MAX范围）
    setlinecolor(RGB(235, 240, 245));
    setlinestyle(PS_SOLID, 1);
    for (int i = 0; i < MAP_AREA_MAX; i += 30) line(i, 0, i, SCREEN_HEIGHT);
    for (int i = 0; i < SCREEN_HEIGHT; i += 30) line(0, i, MAP_AREA_MAX, i);

    // 3. 绘制侧边栏背景（区分地图区）
    setfillcolor(WHITE);
    setlinecolor(RGB(226, 232, 240));
    fillrectangle(MAP_AREA_MAX, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    // 绘制分隔线
    setlinecolor(RGB(203, 213, 225));
    line(MAP_AREA_MAX, 0, MAP_AREA_MAX, SCREEN_HEIGHT);

    // 4. 绘制所有城市间的连接线（仅地图区）
    for (int i = 0; i < G.vexnum; i++) {
        ArcNode* arc = G.vertices[i].firstarc;
        while (arc != NULL) {
            setlinecolor(RGB(210, 215, 225));
            setlinestyle(arc->type == TYPE_FLIGHT ? PS_DASH : PS_SOLID, 1);
            line(G.vertices[i].x, G.vertices[i].y, G.vertices[arc->adjvex].x, G.vertices[arc->adjvex].y);
            arc = arc->nextarc;
        }
    }

    // 5. 绘制最优路径箭头
    if (route_res.total_duration != INF && route_res.full_path.size() > 1) {
        for (size_t i = 0; i < route_res.full_path.size() - 1; i++) {
            int u = route_res.full_path[i];
            int v = route_res.full_path[i + 1];
            DrawArrow(G.vertices[u].x, G.vertices[u].y, G.vertices[v].x, G.vertices[v].y, RGB(34, 197, 94)); 
        }
    }

    // 6. 绘制城市节点（仅地图区）
    for (int i = 0; i < G.vexnum; i++) {
        bool is_start = (i == start_node);
        bool is_end = (i == end_node);
        bool is_via = (find(vias.begin(), vias.end(), i) != vias.end());

        COLORREF circle_color = WHITE;
        COLORREF border_color = RGB(148, 163, 184);
        if (is_start) {
            circle_color = RGB(34, 197, 94);  
            border_color = RGB(220, 252, 231);
        }
        else if (is_end) {
            circle_color = RGB(244, 63, 94);  
            border_color = RGB(254, 226, 226);
        }
        else if (is_via) {
            circle_color = RGB(245, 158, 11); 
            border_color = RGB(254, 243, 199);
        }

        setlinecolor(border_color);
        setlinestyle(PS_SOLID, 3);
        circle(G.vertices[i].x, G.vertices[i].y, 14);

        setfillcolor(circle_color);
        setlinecolor(RGB(71, 85, 105));
        setlinestyle(PS_SOLID, 1);
        fillcircle(G.vertices[i].x, G.vertices[i].y, 10);

        setbkmode(TRANSPARENT);
        settextcolor(RGB(15, 23, 42));
        settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);
        outtextxy(G.vertices[i].x - textwidth(G.vertices[i].name) / 2, G.vertices[i].y + 18, G.vertices[i].name);
    }

    // ----------------- 侧边栏UI（固定坐标，分区排布） -----------------
    int sidebar_x = MAP_AREA_MAX + 20; // 侧边栏起始X坐标（560+20=580）
    int y = 20; // 侧边栏起始Y坐标

    // 标题
    settextcolor(RGB(15, 23, 42));
    settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);
    outtextxy(sidebar_x, y, _T("交通咨询控制台"));
    y += 35;

    // 基础信息区
    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_MEDIUM, false, false, false);
    settextcolor(RGB(51, 65, 85));
    
    TCHAR start_str[50] = _T("出发城市: [未选择]");
    if (start_node != -1) _stprintf_s(start_str, 50, _T("出发城市: %s (%s)"), G.vertices[start_node].name, G.vertices[start_node].code);
    outtextxy(sidebar_x, y, start_str);
    y += 28;

    TCHAR end_str[50] = _T("目的地:   [未选择]");
    if (end_node != -1) _stprintf_s(end_str, 50, _T("目的地:   %s (%s)"), G.vertices[end_node].name, G.vertices[end_node].code);
    outtextxy(sidebar_x, y, end_str);
    y += 28;

    TCHAR vias_str[50];
    _stprintf_s(vias_str, 50, _T("中转途径点: %d 个"), (int)vias.size());
    outtextxy(sidebar_x, y, vias_str);
    y += 30;

    // 交通工具选择区（两行两列，无重叠）
    DrawButton(_T("✈️ 飞机航空"), sidebar_x, y, sidebar_x+90, y+30, vehicle == TYPE_FLIGHT);
    DrawButton(_T("🚊 铁路干线"), sidebar_x+100, y, sidebar_x+190, y+30, vehicle == TYPE_TRAIN);
    y += 40;

    // 决策类型选择区
    DrawButton(_T("⚡ 最快到达"), sidebar_x, y, sidebar_x+90, y+30, decision == 1);
    DrawButton(_T("🪙 最省钱到达"), sidebar_x+100, y, sidebar_x+190, y+30, decision == 2);
    y += 40;

    // 出发时间调整区
    TCHAR time_btn_str[30];
    _stprintf_s(time_btn_str, 30, _T("出发时间: %02d:%02d"), hour, minute);
    DrawButton(time_btn_str, sidebar_x, y, sidebar_x+130, y+32, false);
    DrawButton(_T("➕"), sidebar_x+140, y, sidebar_x+165, y+32, false);
    DrawButton(_T("➖"), sidebar_x+175, y, sidebar_x+190, y+32, false);
    y += 40;

    // 功能按钮区（垂直排布，间距10）
    DrawButton(_T("🔀 随机生成途径点"), sidebar_x, y, sidebar_x+190, y+30, false);
    y += 35;
    DrawButton(_T("🔄 重置当前规划"), sidebar_x, y, sidebar_x+190, y+30, false);
    y += 35;
    DrawButton(_T("⚙️ 管理节点与联动"), sidebar_x, y, sidebar_x+190, y+30, false);
    y += 35;
    DrawButton(_T("🎯 开始最优检索"), sidebar_x, y, sidebar_x+190, y+30, true);
    y += 35;
    DrawButton(_T("🗑️ 删除选中节点"), sidebar_x, y, sidebar_x+190, y+30, false);
    y += 35;
    // 提示窗口可自由调整大小
    settextcolor(RGB(148, 163, 184));
    settextstyle(14, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);
    outtextxy(sidebar_x, y, _T("💡 拖拽窗口边缘可自由调整大小"));
    y += 25;

    // 分割线
    setlinecolor(RGB(226, 232, 240));
    line(MAP_AREA_MAX + 10, y, SCREEN_WIDTH - 20, y);
    y += 15;

    // 结果展示区
    settextcolor(RGB(15, 23, 42));
    settextstyle(20, 0, _T("微软雅黑"), 0, 0, FW_BOLD, false, false, false);
    outtextxy(sidebar_x, y, _T("【智能乘车调度方案】")); 
    y += 25;

    settextstyle(18, 0, _T("微软雅黑"), 0, 0, FW_NORMAL, false, false, false);
    settextcolor(RGB(71, 85, 105));
    if (route_res.total_duration == INF) {
        outtextxy(sidebar_x, y, _T("无活动方案。请依次在地图上"));
        outtextxy(sidebar_x, y+20, _T("点击城市并点击“开始最优检索”。"));
    }
    else {
        TCHAR duration_str[100];
        _stprintf_s(duration_str, 100, _T("全程总耗时: %d小时%d分钟"), route_res.total_duration / 60, route_res.total_duration % 60);
        outtextxy(sidebar_x, y, duration_str);
        y += 20;

        TCHAR cost_str[100];
        _stprintf_s(cost_str, 100, _T("总旅行旅资: %.2f 元"), route_res.total_cost);
        outtextxy(sidebar_x, y, cost_str);
        y += 20;

        outtextxy(sidebar_x, y, _T("详细依次搭乘："));
        y += 15;
        for (size_t i = 0; i < route_res.full_schs.size() && i < 4; i++) {
            TCHAR step_info[150];
            TCHAR dep_time_str[30];
            TCHAR arr_time_str[30];
            MinToTimeStr(route_res.dep_times_absolute[i], dep_time_str, 30);
            MinToTimeStr(route_res.arr_times_absolute[i], arr_time_str, 30);

            int u_idx = route_res.full_path[i];
            int v_idx = route_res.full_path[i + 1];

            _stprintf_s(step_info, 150, _T("%s->%s: %s (%s开)"), G.vertices[u_idx].name, G.vertices[v_idx].name, route_res.full_schs[i]->no, dep_time_str);
            outtextxy(sidebar_x, y, step_info);
            y += 15;
        }
        if (route_res.full_schs.size() > 4) {
            outtextxy(sidebar_x, y, _T("...(省略后续中转步骤)..."));
        }
    }
}

// ----------------- 主函数 -----------------
int main() {
    InjectTestData();

    initgraph(1200, 800);
    // 使窗口可自由调整大小
    {
        HWND hwnd_init = GetHWnd();
        LONG style_init = GetWindowLong(hwnd_init, GWL_STYLE);
        SetWindowLong(hwnd_init, GWL_STYLE, style_init | WS_SIZEBOX | WS_MAXIMIZEBOX);
        SetWindowPos(hwnd_init, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
    }
    // 所有窗口调整完毕后同步实际客户区尺寸
    {
        RECT init_rect;
        GetClientRect(GetHWnd(), &init_rect);
        SCREEN_WIDTH = init_rect.right - init_rect.left;
        SCREEN_HEIGHT = init_rect.bottom - init_rect.top;
        MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;
    }

    setbkmode(TRANSPARENT);
    BeginBatchDraw();

    int start_node = -1;
    int end_node = -1;
    vector<int> vias;
    int vehicle = TYPE_FLIGHT;
    int decision = 1; 
    int start_hour = 11;
    int start_minute = 0;

    GlobalResult route_result;
    route_result.total_duration = INF;

    ExMessage msg;
    DWORD last_resize_time = 0;

    while (true) {
        Render(start_node, end_node, vias, vehicle, decision, start_hour, start_minute, route_result);
        FlushBatchDraw();

        // ---- 轮询检测窗口尺寸变化（EasyX 不转发 WM_EXITSIZEMOVE，故不用消息机制） ----
        RECT cur_rect;
        if (GetClientRect(GetHWnd(), &cur_rect)) {
            int cur_w = cur_rect.right - cur_rect.left;
            int cur_h = cur_rect.bottom - cur_rect.top;
            if ((cur_w != SCREEN_WIDTH || cur_h != SCREEN_HEIGHT) && cur_w >= 600 && cur_h >= 400) {
                // 鼠标按住时不重建（用户正在拖拽边缘），等松开后再处理
                if (GetKeyState(VK_LBUTTON) & 0x8000) { Sleep(16); continue; }
                DWORD now_tick = GetTickCount();
                if (now_tick - last_resize_time > 300) {  // 300ms 冷却，防拖拽中高频重建
                    last_resize_time = now_tick;

                    // 用 AdjustWindowRect 反算窗口总大小，确保客户区精确匹配
                    RECT want = { 0, 0, cur_w, cur_h };
                    AdjustWindowRect(&want, WS_OVERLAPPEDWINDOW, FALSE);
                    int total_w = want.right - want.left;
                    int total_h = want.bottom - want.top;

                    EndBatchDraw();
                    closegraph();
                    initgraph(total_w, total_h);

                    // 设置可拖拽样式
                    HWND hwnd2 = GetHWnd();
                    LONG style2 = GetWindowLong(hwnd2, GWL_STYLE);
                    SetWindowLong(hwnd2, GWL_STYLE, style2 | WS_SIZEBOX | WS_MAXIMIZEBOX);
                    SetWindowPos(hwnd2, NULL, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);

                    // ★ 所有窗口调整完毕后再同步客户区尺寸
                    {
                        RECT sync_rect;
                        GetClientRect(hwnd2, &sync_rect);
                        SCREEN_WIDTH = sync_rect.right - sync_rect.left;
                        SCREEN_HEIGHT = sync_rect.bottom - sync_rect.top;
                    }
                    MAP_AREA_MAX = SCREEN_WIDTH - SIDEBAR_WIDTH;
                    if (MAP_AREA_MAX < 200) MAP_AREA_MAX = 200;

                    setbkmode(TRANSPARENT);
                    BeginBatchDraw();
                    cleardevice();
                    route_result.total_duration = INF;
                    continue;
                }
            }
        }

        // ---- 处理鼠标输入 ----
        while (peekmessage(&msg, EM_MOUSE)) {
            if (msg.message == WM_LBUTTONDOWN) {
                int mx = msg.x;
                int my = msg.y;

                // A. 地图区城市节点点击（仅0-MAP_AREA_MAX范围）
                int clicked_node = -1;
                if (mx < MAP_AREA_MAX) {
                    for (int i = 0; i < G.vexnum; i++) {
                        if (IsInCircle(mx, my, G.vertices[i].x, G.vertices[i].y, 14)) {
                            clicked_node = i;
                            break;
                        }
                    }
                }

                if (clicked_node != -1) {
                    if (start_node == -1) {
                        start_node = clicked_node;
                    }
                    else if (end_node == -1) {
                        if (clicked_node != start_node) {
                            end_node = clicked_node;
                        }
                        else {
                            start_node = -1; 
                        }
                    }
                    else {
                        if (clicked_node == start_node) {
                            start_node = -1;
                        }
                        else if (clicked_node == end_node) {
                            end_node = -1;
                        }
                        else {
                            auto it = find(vias.begin(), vias.end(), clicked_node);
                            if (it != vias.end()) {
                                vias.erase(it); 
                            }
                            else {
                                vias.push_back(clicked_node); 
                            }
                        }
                    }
                    route_result.total_duration = INF; 
                }

                // B. 侧边栏按钮点击（MAP_AREA_MAX到800范围）
                int sb_x = MAP_AREA_MAX + 20;
                if (mx >= MAP_AREA_MAX) {
                    // 交通工具按钮
                    if (IsInRect(mx, my, sb_x, 140, sb_x+90, 170)) {
                        vehicle = TYPE_FLIGHT;
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x+100, 140, sb_x+190, 170)) {
                        vehicle = TYPE_TRAIN;
                        route_result.total_duration = INF;
                    }

                    // 决策类型按钮
                    if (IsInRect(mx, my, sb_x, 180, sb_x+90, 210)) {
                        decision = 1;
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x+100, 180, sb_x+190, 210)) {
                        decision = 2;
                        route_result.total_duration = INF;
                    }

                    // 时间调整按钮
                    if (IsInRect(mx, my, sb_x+140, 220, sb_x+165, 250)) {
                        start_hour = (start_hour + 1) % 24;
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x+175, 220, sb_x+190, 250)) {
                        start_hour = (start_hour + 23) % 24;
                        route_result.total_duration = INF;
                    }

                    // 功能按钮
                    if (IsInRect(mx, my, sb_x, 260, sb_x+190, 290)) {
                        if (start_node != -1 && end_node != -1) {
                            vias.clear();
                            vector<int> candidates;
                            for (int i = 0; i < G.vexnum; i++) {
                                if (i != start_node && i != end_node) candidates.push_back(i);
                            }
                            if (candidates.size() > 0) {
                                int count = rand() % 2 + 1;
                                std::random_device rd;
                                std::mt19937 g(rd());
                                std::shuffle(candidates.begin(), candidates.end(), g);
                                for (int i = 0; i < count && i < (int)candidates.size(); i++) {
                                    vias.push_back(candidates[i]);
                                }
                            }
                            route_result.total_duration = INF;
                        }
                    }
                    if (IsInRect(mx, my, sb_x, 295, sb_x+190, 325)) {
                        start_node = -1;
                        end_node = -1;
                        vias.clear();
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x, 330, sb_x+190, 360)) {
                        InteractiveEditNetwork();
                        route_result.total_duration = INF;
                    }
                    if (IsInRect(mx, my, sb_x, 365, sb_x+190, 395)) {
                        if (start_node != -1 && end_node != -1) {
                            int base_start_min = start_hour * 60 + start_minute;
                            route_result = SolveWithVias(start_node, end_node, base_start_min, decision, vehicle, vias);
                        }
                    }
                    //删除按钮
                
                    if (IsInRect(mx, my, sb_x, 400, sb_x+190, 430)) {
                        TCHAR input_name[30] = {0};
                        if (InputBox(input_name, 30, _T("请输入要删除的城市名称："), _T("删除节点"))) {
                            DeleteVertexByName(input_name);
                            // 删除后清空当前选择状态，防止索引错位引起崩溃
                            start_node = -1; end_node = -1; vias.clear();
                            route_result.total_duration = INF;
                        }
                    }
                }
            }
        }
        Sleep(16);
    }

    EndBatchDraw();
    closegraph();
    return 0;
}